# Day 5 — Departure from Madrid

An optional morning visit to the Las Rozas Factory Outlet is available before your private transfer to Madrid Airport.

## Las Rozas Factory Outlet *(optional)*
An optional visit to the Las Rozas Village outlet centre is available for those with later flights. The open-air complex hosts discounted European and international fashion brands in a relaxed village setting.

## Madrid Airport Transfer
Your private vehicle transfers you to Madrid Airport. Departure is recommended four hours before your flight to allow time for check-in and formalities.

---
**Hotel:** — · **Transport:** Private transfer to Madrid Airport

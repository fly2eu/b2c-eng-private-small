# Day 1 — Madrid & Toledo

Your driver meets you at Madrid Airport and takes you directly to Toledo, the ancient capital where Muslim, Jewish, and Christian scholars once translated Arabic texts into Latin. The afternoon is spent exploring the hilltop city on foot.

## Madrid Airport Arrival
Your driver greets you at Madrid Airport and escorts you to your private vehicle. The transfer to Toledo takes approximately one hour through the plains south of the capital.

## Toledo Panoramic Tour & Mirador del Valle
Your vehicle circles the hilltop city, pausing at the Mirador del Valle for a panoramic photograph. The viewpoint reveals Toledo's medieval skyline, fortified walls, and the Tagus River gorge curving below. The scale of the old city and its layered architecture are visible from this single vantage point.

## Zocodover Square & Street of Commerce
You walk through Zocodover Square, the historic centre of Toledo's public life, and continue along the Street of Commerce. The narrow lane is lined with artisan workshops and traditional storefronts that have traded here for centuries.

## Damascene Workshop
You visit a damascene workshop where artisans inlay gold and silver wire into blackened steel. The technique arrived in Toledo during the Islamic period and remains a living craft. You watch the process from raw metal to finished ornament.

## Mosque of Bab al-Mardum
You enter the Mosque of Bab al-Mardum, a 10th-century place of worship and one of Toledo's oldest surviving structures. Nine small domes, each crowned with a distinct geometric vault pattern, demonstrate the refinement of Umayyad architecture in central Iberia.

---
**Hotel:** Madrid · **Transport:** Private transfer from Madrid Airport to Toledo (1hr); return to Madrid

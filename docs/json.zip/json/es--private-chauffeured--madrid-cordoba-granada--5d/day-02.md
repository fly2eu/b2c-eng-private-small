# Day 2 — Madrid to Cordoba

Your vehicle departs Madrid and crosses the plains of La Mancha, passing windmills and olive groves on the four-hour journey south. The afternoon in Cordoba is devoted to the Great Mosque, the Roman Bridge, and the old quarters.

## La Mancha Landscape Drive
Your vehicle crosses the open plateau of La Mancha on the road south to Cordoba. Windmills stand on the ridges and the terrain shifts between olive groves, wheat fields, and vineyards. The landscape is the same that Cervantes immortalised in Don Quixote.

## Lunch in Cordoba
Lunch is served on arrival in Cordoba at a restaurant in the old quarter. The courtyard setting, with tiled walls and citrus trees, is characteristic of traditional Andalusian domestic architecture.

## Great Mosque of Cordoba *(included ticket)*
Your guide leads you into the Great Mosque of Cordoba, the spiritual centre of Al-Andalus for over three centuries. Inside, a forest of columns and double arches in alternating red and white stone extends in every direction. The visit traces the mosque's expansion through four successive Umayyad building campaigns.

## Bridge of Musa ibn Nusayr & Calahorra Tower
You cross the Roman Bridge over the Guadalquivir, pausing at the Calahorra Tower on the far bank. The bridge and tower together frame the most recognisable view of Cordoba, with the Great Mosque rising behind the city walls.

## Andalusi House
You visit the Andalusi House, a museum that recreates daily life in Islamic Cordoba. Exhibits cover calligraphy, astronomy instruments, and domestic objects, illustrating the intellectual and artistic culture of the caliphal period.

## Cordoba Old Quarters *(optional)*
Free time in the old quarters allows you to wander narrow lanes lined with whitewashed houses and flower-filled patios. Cordoba is known for its leather craft, silver filigree, and hand-painted ceramics.

---
**Hotel:** Cordoba · **Transport:** Private transfer from Madrid to Cordoba (4hr)

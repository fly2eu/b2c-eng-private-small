# Day 3 — Cordoba, Medinat Al-Zahra & Granada

The morning takes you to Medinat Al-Zahra, the palatial city of the Umayyad caliphs, before your vehicle follows the Route of the Caliphate through olive country to Granada. The evening is spent in the Albaicin quarter.

## Medinat Al-Zahra *(included ticket)*
Your vehicle brings you to Medinat Al-Zahra, the palatial city built by Caliph Abderrahman III in the 10th century, the peak of Islamic civilisation in Iberia. The archaeological site preserves carved stonework, water channels, and reception halls that once served as the administrative heart of the Umayyad Caliphate in the West.

## Route of the Caliphate
Your vehicle follows the historic Route of the Caliphate eastward toward Granada. The road passes Muslim watchtowers and ruined castles set among olive fields that stretch to the horizon. A stop among the groves allows you to take in the scale of the Andalusian countryside.

## Albaicin Quarter
You explore the Albaicin, Granada's old Muslim quarter perched on a hillside opposite the Alhambra. Winding cobbled streets lead past carmen houses with hidden gardens and viewpoints that frame the palace against the snow-capped Sierra Nevada.

## Grand Mosque of Granada
The Grand Mosque of Granada sits at the top of the Albaicin. Its garden terrace provides one of the finest panoramic views of the Alhambra in the city, with the palace complex spread across the opposite ridge.

## Moroccan Bazaar *(optional)*
Free time takes you through the Moroccan bazaar in the streets below the Albaicin. Shops sell lanterns, tea sets, leather goods, and spices imported from North Africa, giving this part of Granada a distinctly Maghrebi character.

---
**Hotel:** Granada · **Transport:** Private transfer from Cordoba to Medinat Al-Zahra; continue via Route of the Caliphate to Granada (2hr)

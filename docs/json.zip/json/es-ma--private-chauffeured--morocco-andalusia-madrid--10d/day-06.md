## Day 6 — Seville → Córdoba

You travel east from Seville to Córdoba, spending the day exploring the Great Mosque, the Roman Bridge, and the old quarters of the former caliphate capital.

**Mosque of Córdoba** *(ticket included)*
You enter the Great Mosque of Córdoba, begun in the eighth century under Abd al-Rahman I. Over 850 columns support a forest of red-and-white double arches extending in every direction. The mihrab, adorned with Byzantine gold mosaics, is one of the finest surviving examples of Islamic sacred art in the western world.

**Roman Bridge (Bridge of Musa ibn Nusayr)**
You walk across the sixteen-arch Roman Bridge spanning the Guadalquivir. The bridge provides a direct view back toward the mosque and the old city skyline, and has connected the two banks since the first century.

**Calahorra Tower**
You view the Calahorra Tower at the southern end of the bridge, a fortified gate of Islamic origin. The tower controlled access to the city from the south bank and now houses a museum on the coexistence of cultures in medieval Córdoba.

**Andalusi House**
You visit the Casa Andalusi, a twelfth-century house restored to evoke daily life during the Caliphate period. Displays of Moorish paper-making, calligraphy, and domestic objects illustrate the intellectual achievements of Al-Andalus.

**Old Quarters of Córdoba** *(free time)*
You have free time to wander the old quarters, where whitewashed houses with flower-filled patios line narrow lanes. Wrought-iron grilles and trailing jasmine frame doorways that open onto hidden courtyards.

*Your vehicle transfers you from Seville to Córdoba (approximately 1.5 hours).*

## Day 7 — Córdoba → Medinat al-Zahra → Granada

You visit the ruins of the Umayyad palatial city west of Córdoba, then travel the historic Route of the Caliphate through olive country to Granada.

**Medinat al-Zahra** *(ticket included)*
You visit Medinat al-Zahra, the vast tenth-century palatial city built by Caliph Abd al-Rahman III west of Córdoba. Partially excavated, the site reveals terraced gardens, reception halls with carved marble panels, and a grand basilical hall. At its height, the complex rivalled Constantinople and Baghdad in scale and splendour.

**Route of the Caliphate**
Your vehicle follows the Route of the Caliphate from Córdoba toward Granada, passing Muslim-era watchtowers and castle ruins that dot the hilltops along the way. The road winds through vast olive groves, and you stop briefly to take in the silver-green landscape that produces much of the world's olive oil.

**Albaicín Quarter**
You explore the Albaicín, Granada's ancient Moorish hillside quarter and UNESCO World Heritage Site. Winding cobblestone streets, whitewashed houses, and traditional carmenes preserve the urban fabric of the Nasrid period.

**Panoramic Alhambra Views**
From the Mirador de San Nicolás, you take in a sweeping panorama of the Alhambra palace complex framed by the snow-capped Sierra Nevada. This is one of the most celebrated viewpoints in all of Spain.

**Grand Mosque of Granada**
You visit the Grand Mosque of Granada in the heart of the Albaicín. The modern mosque features a courtyard garden with fountains and a terrace offering its own perspective of the Alhambra across the Darro valley.

**Moroccan Bazaar**
You browse the Moroccan Bazaar near the Albaicín, where shops along Calderería Nueva sell Moroccan tea sets, lanterns, leather goods, and spices. The narrow pedestrian street evokes the souks of North Africa in the heart of Granada.

*Your vehicle departs Córdoba for Medinat al-Zahra, then follows the Route of the Caliphate to Granada (approximately 2 hours from Córdoba).*

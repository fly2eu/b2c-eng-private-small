## Day 10 — Madrid

You have optional time for shopping before your private driver transfers you to Madrid Airport.

**Las Rozas Village Factory Outlet** *(optional)*
You have the option to visit Las Rozas Village, a designer outlet centre on the outskirts of Madrid offering over one hundred boutiques with discounted international brands.

**Madrid Airport Transfer**
Your driver collects you from your hotel and transfers you to Madrid Barajas Airport in good time for your departure flight. End of services.

*A private transfer brings you from your Madrid hotel to the airport, with an optional stop at Las Rozas Village en route.*

## Day 3 — Marrakesh → Rabat → Fez

You travel north to Rabat for a morning of imperial monuments, then continue east through the countryside to the ancient city of Fez.

**Transfer to Rabat**
Your vehicle departs Marrakesh early and heads north to Rabat, Morocco's administrative capital. The drive takes approximately four hours.

**Old Medina of Rabat**
You walk through Rabat's compact old medina, a quieter alternative to the souks of Marrakesh and Fez. Whitewashed walls with blue accents line orderly lanes that open onto small squares with local shops.

**Kasbah of the Udayas**
You enter the Kasbah of the Udayas through its monumental Almohad gate, one of the finest examples of twelfth-century Moorish architecture. Inside, an Andalusian garden overlooks the Bou Regreg River and the Atlantic beyond.

**Hassan Tower**
You stand before the Hassan Tower, the unfinished minaret of a twelfth-century mosque intended to be the largest in the western Islamic world. Construction halted at forty-four metres, and over two hundred stone columns mark the abandoned prayer hall.

**Mausoleum of Mohammed V**
You visit the Mausoleum of Mohammed V beside the Hassan Tower. The white marble interior houses the royal tombs and demonstrates the finest traditions of modern Moroccan craftsmanship in zellige, carved plaster, and mahogany woodwork.

**Transfer to Fez**
Your vehicle departs Rabat and heads east toward Fez through rolling agricultural countryside. The journey takes approximately two hours.

*Your vehicle transfers you from Marrakesh to Rabat (4 hours), then continues to Fez (2 hours) after the sightseeing.*

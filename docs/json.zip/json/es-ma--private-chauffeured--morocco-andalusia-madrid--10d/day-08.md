## Day 8 — Alhambra & Alpujarra Mountains

The morning is dedicated to the Alhambra, the crown jewel of Nasrid architecture, followed by an afternoon driving the route of Sultan Boabdil's last retreat into the Alpujarra Mountains.

**Alhambra** *(ticket included)*
You enter the Alhambra, the thirteenth- and fourteenth-century palace-fortress of the Nasrid dynasty. The Nasrid Palaces reveal room after room of impossibly detailed stucco carvings, muqarnas ceilings, and Arabic inscriptions drawn from poetry and Quranic verses. The Court of the Lions, with its twelve marble lion fountain, and the Hall of the Ambassadors represent the zenith of Islamic palatial architecture in Europe.

**Route of Sultan Boabdil — Alpujarra Mountains**
Your vehicle traces the route taken by Boabdil, the last Muslim sultan of Granada, into the Alpujarra Mountains after the fall of the city in 1492. You pass the Nasrid Bridge, the medieval Tower of Lanjarón, and terraced orchards of orange and olive trees fed by an irrigation system designed during the Muslim era. The mountain landscape is a living record of Andalusian agricultural engineering.

*Your vehicle and guide are at your disposal for the Alhambra visit in the morning and the Alpujarra excursion in the afternoon.*

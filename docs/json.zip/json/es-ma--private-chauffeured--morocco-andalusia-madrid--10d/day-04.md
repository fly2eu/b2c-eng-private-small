## Day 4 — Fez → Tangier

A full day in Fez — the city that sheltered Andalusian Muslim refugees — exploring its medieval medina, tanneries, and scholarly heritage before transferring to Tangier.

**Andalusian Quarter**
You walk through the Andalusian Quarter of Fez, founded by Muslim refugees expelled from Al-Andalus in 1609. The district retains its own architectural character, with narrow streets, neighbourhood fountains, and the Andalusian Mosque that gave the quarter its name.

**Andalusian Mosque**
You pause at the Andalusian Mosque, one of the oldest in Fez, established by Maryam al-Fihriyya's sister in the ninth century. The monumental carved gateway and green-tiled minaret are visible from the surrounding lanes of the quarter.

**Chouara Leather Tannery**
You view the Chouara tannery from a terrace above, looking down on dozens of stone vats filled with natural dyes — saffron, indigo, poppy, and cedar. Workers treat hides by hand using methods virtually unchanged since the medieval period, making this one of the oldest functioning tanneries in the world.

**Al-Qarawiyyin Mosque**
You visit the Al-Qarawiyyin, founded in 859 CE and regarded as one of the oldest continuously operating universities in the world. The mosque and its attached library house priceless manuscripts, and the courtyard features zellige fountains and carved stucco of exceptional refinement.

**Bab Bou Jeloud**
You pass through Bab Bou Jeloud, the ornate blue-and-green tiled gateway that serves as the main entrance to Fez el-Bali, the old walled city. The gate's horseshoe arch frames the minaret of the Bou Inania Madrasa beyond.

**Royal Palace of Fez**
You view the exterior of the Royal Palace, whose immense brass doors and zellige-framed entrance are among the most photographed sights in Fez. The palace complex extends over eighty hectares behind its walls, though the interior is closed to the public.

**Mausoleum of Moulay Idriss II**
You visit the zawiya of Moulay Idriss II, the founder of Fez and one of the most venerated figures in Moroccan history. The shrine is a centre of pilgrimage, and the surrounding streets are lined with stalls selling candles, incense, and traditional offerings.

**Zawiya of Sheikh Ahmed Tijani**
You stop at the zawiya of Sheikh Ahmed Tijani, the founder of the Tijaniyya Sufi order. The shrine draws pilgrims from across West Africa and features a richly decorated interior with zellige and carved cedarwood.

**Free Time & Shopping in Fez** *(optional)*
You have free time to explore the souks of Fez, renowned for their leather goods, brassware, ceramics, and hand-woven textiles. The medina contains over 9,000 narrow lanes and is the largest car-free urban area in the world.

**Transfer to Tangier**
Your vehicle departs Fez and heads northwest through the Rif foothills toward Tangier. The journey takes approximately five hours.

*Your vehicle and guide are at your disposal in Fez, then transfer you to Tangier (approximately 5 hours) in the late afternoon.*

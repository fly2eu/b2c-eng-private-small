## Day 2 — Marrakesh

A full day immersed in Marrakesh, from its grand palaces and gardens to the labyrinthine souks of the medina and the energy of its great central square.

**Bahia Palace** *(ticket included)*
You enter the Bahia Palace, a nineteenth-century masterpiece built for the Grand Vizier. Intricate zellige tilework, carved cedarwood ceilings, and tranquil courtyards planted with orange and jasmine trees fill a sprawling complex of interconnected halls and gardens.

**Menara Gardens**
You walk through the Menara Gardens, a twelfth-century royal olive grove surrounding a large reflecting pool. On clear days, the snow-capped Atlas Mountains create a dramatic backdrop behind the green-roofed pavilion.

**Saadian Tombs**
You visit the Saadian Tombs, a sixteenth-century royal necropolis sealed for centuries and rediscovered in 1917. The Hall of Twelve Columns features Italian Carrara marble and elaborate muqarnas plasterwork surrounding the tomb of Sultan Ahmad al-Mansur.

**Marrakesh Medina & Bazaar**
Your guide leads you through the narrow alleys of the old medina, where artisans work leather, copper, and textiles in workshops that have operated for generations. The souks are arranged by trade, each section dedicated to a single craft.

**Koutoubia Mosque**
You pause at the Koutoubia Mosque, the largest mosque in Marrakesh, whose seventy-seven-metre Almohad minaret has served as the city's landmark since the twelfth century. Its proportions inspired both the Giralda in Seville and the Hassan Tower in Rabat.

**Jemaa el-Fnaa**
You end the day at Jemaa el-Fnaa, the great central square that transforms as the sun sets. Storytellers, musicians, and food stalls fill the open space, creating a spectacle recognised by UNESCO as a masterpiece of intangible heritage.

*Your vehicle and guide are at your disposal throughout the day for the Marrakesh city tour.*

## Day 1 — Casablanca → Marrakesh

You arrive in Casablanca and visit one of the world's largest mosques before your private transfer carries you south to Marrakesh.

**Casablanca Airport Arrival**
Your driver meets you at Mohammed V International Airport and assists with your luggage. The transfer to the city centre is brief.

**Mosque of Hassan II**
You visit the Mosque of Hassan II, standing on a promontory over the Atlantic Ocean. Its 210-metre minaret makes it the tallest religious structure in Africa. The interior accommodates 25,000 worshippers beneath a retractable roof, and waves are visible through glass panels in the floor.

**Transfer to Marrakesh**
Your vehicle departs Casablanca and heads south through the Moroccan plains toward Marrakesh. The journey takes approximately three hours.

*A private transfer brings you from Casablanca Airport to the mosque, then continues to Marrakesh (approximately 3 hours).*

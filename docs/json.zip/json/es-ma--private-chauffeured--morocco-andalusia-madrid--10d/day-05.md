## Day 5 — Tangier → Tarifa → Seville

You cross the Strait of Gibraltar by ferry and arrive in Andalusia, where a guided tour of Seville reveals the city's rich Moorish legacy.

**Strait of Gibraltar Ferry**
You board a ferry at Tangier port and cross the Strait of Gibraltar to Tarifa. The crossing takes approximately one hour, with both the African and European coastlines visible at the narrowest point.

**Royal Alcázar of Seville** *(ticket included)*
You enter the Royal Alcázar, a UNESCO-listed palace complex originally built as a Moorish fort in the tenth century. The Mudéjar sections feature elaborate stucco arches, gilded domes, and courtyards with reflecting pools — some of the finest Islamic-influenced architecture in Europe.

**Giralda Tower**
You view the Giralda, originally constructed as the minaret of the Almohad mosque in the twelfth century. The lower two-thirds retain their original brickwork with sebka decorative panels, a direct architectural sibling of the Hassan Tower and the Koutoubia.

**Muslim Quarters of Seville**
You walk through the narrow lanes of the former Muslim quarters, where the medieval street plan survives largely intact. Whitewashed houses with interior courtyards and ornamental tiles reflect the domestic architecture of Al-Andalus.

**Plaza de España**
You visit the sweeping semicircular Plaza de España, built for the 1929 Ibero-American Exposition. Tiled alcoves represent each province of Spain, and ornamental bridges cross the canal at its base. The architecture blends Renaissance Revival with Moorish motifs.

**Guadalquivir River**
You stroll along the banks of the Guadalquivir River, which flows through the heart of Seville. The riverside promenade offers views of the Torre del Oro and the Triana neighbourhood across the water.

*Your vehicle brings you to Tangier port for the ferry. On arrival in Tarifa, a private transfer continues to Seville.*

## Day 9 — Granada → Toledo → Madrid

You depart Granada and travel north to the ancient walled city of Toledo before continuing to Madrid for an evening city tour.

**Mosque of Bab al-Mardum**
You visit the Mosque of Bab al-Mardum (Cristo de la Luz), a tenth-century mosque that is one of the oldest surviving Islamic buildings in Spain. Nine small domes, each with a different ribbed vault pattern, crown the compact square prayer hall in a design of remarkable geometric variety.

**Damascene Workshops of Toledo**
You browse the Damascene workshops of Toledo, where artisans inlay gold and silver wire into darkened steel using techniques inherited from the Moorish period. Swords, jewellery, plates, and decorative objects are produced by hand.

**Zocodover Square**
You pass through Zocodover Square, the historic commercial centre of Toledo whose name derives from the Arabic suq al-dawabb (livestock market). The plaza has served as the city's main gathering place for centuries.

**Royal Palace of Madrid**
You visit the Royal Palace, the official residence of the Spanish monarchy and the largest functioning royal palace in Europe by floor area. The site was originally occupied by a Moorish fortress, and the current building's state rooms display centuries of royal art and furnishings.

**Santiago Bernabéu Stadium**
You stop at the Santiago Bernabéu, the home ground of Real Madrid. The recently renovated arena seats over 80,000 spectators beneath a retractable roof and is one of the most iconic football venues in the world.

**Puerta de Alcalá**
You pass the Puerta de Alcalá, a neoclassical triumphal arch commissioned by Charles III in 1778. The five-arched granite gateway stands at the edge of the Retiro Park.

**Puerta del Sol**
You arrive at Puerta del Sol, the geographic centre of Spain and the origin point from which all national road distances are measured. The bustling semicircular plaza is home to the famous clock tower.

*Your vehicle departs Granada for Toledo (approximately 4 hours), then continues to Madrid after the Toledo visits.*

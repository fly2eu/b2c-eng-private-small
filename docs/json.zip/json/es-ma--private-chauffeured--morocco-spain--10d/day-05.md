## Day 5 — Seville → Córdoba → Granada

You travel east from Seville through the heart of Al-Andalus, visiting the Great Mosque of Córdoba before continuing to Granada and the Albaicín quarter.

**Mosque of Córdoba** *(ticket included)*
You enter the Great Mosque of Córdoba, begun in the eighth century under Abd al-Rahman I. Over 850 columns of jasper, onyx, and marble support a forest of red-and-white double arches that create a mesmerising visual rhythm extending in every direction. The mihrab, with its gold mosaic work gifted by a Byzantine emperor, remains one of the finest examples of Islamic sacred art in the Western world.

**Roman Bridge (Bridge of Musa ibn Nusayr)**
You walk across the sixteen-arch Roman Bridge spanning the Guadalquivir, a structure that has connected the two banks of the city since the first century. The bridge offers a direct view back toward the mosque and the old city skyline.

**Calahorra Tower**
You view the Calahorra Tower at the southern end of the Roman Bridge, a fortified gate of Islamic origin that was later expanded. The tower controlled access to the city from the south bank and now houses a museum on the coexistence of cultures in medieval Córdoba.

**Andalusi House**
You visit the Casa Andalusi, a twelfth-century house restored to evoke daily life during the Caliphate period. Displays of Moorish paper-making techniques, calligraphy, and domestic objects illustrate the intellectual and artistic achievements of Al-Andalus.

**Albaicín Quarter**
You explore the Albaicín, Granada's ancient Moorish residential quarter, a UNESCO World Heritage Site of winding cobblestone streets, whitewashed houses, and carmenes — traditional walled gardens. The hillside district preserves the urban fabric of the Nasrid period.

**Panoramic Alhambra Views**
From the Mirador de San Nicolás in the Albaicín, you take in a panoramic view of the Alhambra palace complex set against the snow-capped Sierra Nevada. This is one of the most celebrated vistas in Spain, particularly striking in the late afternoon light.

**Grand Mosque of Granada**
You visit the Grand Mosque of Granada, opened in 2003 in the heart of the Albaicín. The mosque features a garden courtyard with fountains and a terrace that offers its own perspective of the Alhambra across the valley.

*Your vehicle departs Seville for Córdoba (approximately 1.5 hours), then continues to Granada after the Córdoba visits.*

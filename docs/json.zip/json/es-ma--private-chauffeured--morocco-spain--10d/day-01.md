## Day 1 — Casablanca → Marrakesh

You arrive in Casablanca and visit one of the largest mosques in the world before your private transfer carries you south to Marrakesh.

**Casablanca Airport Arrival**
Your driver meets you at Mohammed V International Airport and assists with luggage. The transfer to the first stop takes only a few minutes.

**Mosque of Hassan II**
You visit the Mosque of Hassan II, one of the largest mosques in the world, standing on a promontory overlooking the Atlantic Ocean. Its minaret rises 210 metres, making it the tallest religious structure in Africa. The interior accommodates up to 25,000 worshippers beneath a retractable roof that opens to the sky.

**Transfer to Marrakesh**
Your vehicle departs Casablanca and heads south through the Moroccan plains toward Marrakesh. The journey takes approximately three hours.

*A private transfer brings you from Casablanca Airport to the city centre for your mosque visit, then continues to Marrakesh (approximately 3 hours).*

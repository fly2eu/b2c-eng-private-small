## Day 2 — Marrakesh → Rabat

A full morning exploring the palaces, gardens, and souks of Marrakesh before your vehicle carries you north to the capital city of Rabat.

**Bahia Palace**
You step into the Bahia Palace, a nineteenth-century masterpiece of Moroccan craftsmanship. Intricate zellige tilework, carved cedarwood ceilings, and tranquil courtyards filled with orange and jasmine trees reveal the ambitions of its builder, Grand Vizier Si Moussa. The palace sprawls across eight hectares of gardens and interconnected halls.

**Menara Gardens**
You walk through the Menara Gardens, a twelfth-century royal olive grove surrounding a large reflecting pool. On clear days, the snow-capped Atlas Mountains form a striking backdrop behind the green-roofed pavilion at the water's edge.

**Saadian Tombs**
You visit the Saadian Tombs, a sixteenth-century royal necropolis sealed for centuries and rediscovered in 1917. The Hall of Twelve Columns features Italian Carrara marble and elaborate muqarnas plasterwork surrounding the tomb of Sultan Ahmad al-Mansur.

**Marrakesh Medina & Bazaar**
Your guide leads you through the narrow alleys of the old medina, where artisans work leather, copper, and textiles in workshops that have operated for generations. The souks are arranged by trade, each section specialising in a single craft.

**Koutoubia Mosque** *(free time)*
You pause at the Koutoubia Mosque, the largest mosque in Marrakesh, whose seventy-seven-metre minaret has served as the city's landmark since the twelfth century. The minaret's proportions inspired both the Giralda in Seville and the Hassan Tower in Rabat.

**Jemaa el-Fnaa** *(free time)*
You have free time at Jemaa el-Fnaa, the vast central square that transforms throughout the day. By afternoon, storytellers, musicians, and food stalls fill the open space, creating a scene recognised by UNESCO as a masterpiece of intangible heritage.

*Your vehicle departs Marrakesh after the city tour and transfers you to Rabat (approximately 4 hours).*

## Day 10 — Barcelona

You have free time in the morning before your private transfer brings you to Barcelona Airport for your departure flight.

**Free Time in Barcelona** *(optional)*
The morning is yours to enjoy at leisure. You may revisit a favourite neighbourhood, pick up last-minute souvenirs, or relax at your hotel before departure.

**Barcelona Airport Transfer**
Your driver collects you from your hotel and transfers you to Barcelona El Prat Airport in good time for your departure flight. End of services.

*A private transfer brings you from your Barcelona hotel to the airport.*

## Day 3 — Rabat → Tangier

You explore the historical heart of Morocco's capital before continuing north along the Atlantic coast to the port city of Tangier.

**Old Medina of Rabat**
You walk through Rabat's compact old medina, a quieter and more orderly counterpart to the souks of Marrakesh. Whitewashed walls and blue-accented doorways line the narrow streets, which open onto small squares with local shops and cafes.

**Kasbah of the Udayas**
You enter the Kasbah of the Udayas through the monumental Almohad gate, one of the finest examples of twelfth-century Moorish architecture in Morocco. Inside, an Andalusian garden with fountains and citrus trees overlooks the mouth of the Bou Regreg River and the Atlantic beyond.

**Hassan Tower**
You stand before the Hassan Tower, the unfinished minaret of a twelfth-century mosque that was intended to be the largest in the world. Construction halted at forty-four metres after the death of Sultan Yaqub al-Mansur, and over two hundred stone columns mark where the prayer hall would have stood.

**Mausoleum of Mohammed V**
You visit the Mausoleum of Mohammed V, set on the esplanade beside the Hassan Tower. The white marble interior houses the tombs of King Mohammed V and his sons, and the building showcases the finest traditions of modern Moroccan craftsmanship in its zellige, carved plaster, and mahogany woodwork.

*Your vehicle transfers you from Rabat to Tangier (approximately 3 hours) after the morning sightseeing.*

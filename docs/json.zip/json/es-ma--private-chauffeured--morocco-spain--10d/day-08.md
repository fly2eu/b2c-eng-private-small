## Day 8 — Madrid → Zaragoza → Barcelona

You leave Madrid and travel northeast, stopping in Zaragoza to visit a remarkable eleventh-century Islamic palace before continuing to Barcelona on the Mediterranean coast.

**Aljafería Palace**
You visit the Aljafería Palace, an eleventh-century fortified Islamic palace built during the Taifa period. Known historically as Qasr al-Surur (Palace of Joy), it is the only substantially preserved Taifa-era palace in Spain. The intricate interlacing arches of the northern portico and the small mosque with its octagonal prayer room represent a unique chapter in the architecture of Al-Andalus.

*Your vehicle departs Madrid in the morning, stops in Zaragoza for the palace visit, then continues to Barcelona.*

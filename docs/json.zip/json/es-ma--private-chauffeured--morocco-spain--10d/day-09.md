## Day 9 — Barcelona

A full day in Barcelona takes you from Gaudí's unfinished basilica to the Gothic quarter and a panoramic viewpoint over the Mediterranean city.

**Sagrada Familia** *(photo stop)*
You make a photo stop at the Sagrada Familia, Antoni Gaudí's still-unfinished basilica that has been under construction since 1882. The exterior facades depict the Nativity and Passion in extraordinary sculptural detail, and the soaring towers are visible from across the city.

**Camp Nou** *(optional)*
You have the option to tour Camp Nou, the home stadium of FC Barcelona and the largest football ground in Europe. The tour covers the pitch, the presidential box, the press room, and the club museum.

**Montjuïc Panoramic View**
You ascend Montjuïc hill for a sweeping panoramic view over Barcelona, the port, and the Mediterranean coast. The hillside park also features gardens, the 1992 Olympic facilities, and the National Art Museum of Catalonia.

**La Roca Village Factory Outlet**
You visit La Roca Village, a designer outlet shopping centre located approximately forty minutes from central Barcelona. Over one hundred boutiques offer discounted fashion, accessories, and homeware brands.

**Barri Gòtic (Gothic Quarter)**
You walk through the Gothic Quarter, Barcelona's oldest neighbourhood, where medieval lanes wind between Roman walls, fourteenth-century churches, and small squares filled with street musicians. The area preserves traces of the city's Roman and medieval past.

**La Boquería Market**
You visit La Boquería, Barcelona's famous covered food market on La Rambla. Stalls display fresh seafood, cured meats, tropical fruits, spices, and freshly pressed juices under the market's iron and stained-glass entrance arch.

*Your vehicle and guide are at your disposal throughout the day for the Barcelona city tour, including the excursion to La Roca Village.*

## Day 6 — Granada → Toledo → Madrid

The morning is dedicated to the Alhambra, the pinnacle of Nasrid architecture, before your vehicle carries you north through La Mancha to Madrid.

**Alhambra** *(ticket included)*
You enter the Alhambra, the thirteenth- and fourteenth-century palace-fortress of the Nasrid dynasty. The Nasrid Palaces reveal room after room of impossibly detailed stucco carvings, muqarnas ceilings, and Arabic inscriptions drawn from poetry and Quranic verses. The Court of the Lions, with its twelve marble lion fountain, and the Hall of the Ambassadors represent the zenith of Islamic palatial architecture in Europe.

*A private transfer brings you from Granada to Madrid (approximately 4.5 hours) after the Alhambra visit.*

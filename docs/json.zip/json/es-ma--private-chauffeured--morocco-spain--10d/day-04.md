## Day 4 — Tangier → Tarifa → Seville

You cross the Strait of Gibraltar by ferry and arrive in Spain, where a guided tour of Seville reveals the city's deep Moorish heritage.

**Strait of Gibraltar Ferry**
You board a ferry at Tangier port and cross the Strait of Gibraltar to Tarifa on the southern tip of Spain. The crossing takes approximately one hour, with views of both the African and European coastlines.

**Royal Alcazar of Seville** *(ticket included)*
You enter the Royal Alcazar, a UNESCO-listed palace complex originally built as a Moorish fort in the tenth century. The Mudéjar sections commissioned by Pedro I in the fourteenth century feature some of the most accomplished Islamic-influenced architecture in Europe, with elaborate stucco arches, gilded domes, and serene courtyards with reflecting pools.

**Giralda Tower**
You view the Giralda, the iconic bell tower of Seville Cathedral that was originally constructed as the minaret of the Almohad mosque in the twelfth century. Its lower two-thirds retain the original brickwork with sebka decorative panels, a direct architectural sibling of the Hassan Tower in Rabat and the Koutoubia in Marrakesh.

**Muslim Quarters of Seville**
You walk through the narrow lanes of the former Muslim quarters, where the medieval street plan survives largely intact. Whitewashed houses with interior courtyards and ornamental tiles reflect the domestic architecture that characterised Al-Andalus.

**Plaza de Espana**
You visit the sweeping semicircular Plaza de Espana, built for the 1929 Ibero-American Exposition. The plaza's tiled alcoves represent each province of Spain, and a canal crossed by ornamental bridges curves along its base. The architecture blends Renaissance Revival with Moorish decorative elements.

**Guadalquivir River**
You pass along the banks of the Guadalquivir River, which flows through the heart of Seville. The riverside promenade offers views of the Torre del Oro and the Triana neighbourhood across the water.

*Your vehicle brings you to Tangier port for the ferry crossing. On arrival in Tarifa, a private transfer continues to Seville.*

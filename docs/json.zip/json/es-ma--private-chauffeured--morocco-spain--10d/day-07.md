## Day 7 — Madrid

A full day exploring the Spanish capital, from the grand Royal Palace to the bustling plazas and boulevards of the city centre.

**Royal Palace of Madrid**
You visit the Royal Palace, the official residence of the Spanish monarchy and the largest functioning royal palace in Europe by floor area. The interior tour passes through lavishly decorated state rooms, the throne room, the royal armoury, and the palace pharmacy.

**Santiago Bernabéu Stadium**
You stop at the Santiago Bernabéu, the home ground of Real Madrid and one of the most iconic football stadiums in the world. The recently renovated arena seats over 80,000 spectators beneath a retractable roof.

**Plaza de España**
You visit Madrid's Plaza de España, a large public square anchored by the Cervantes monument featuring statues of Don Quixote and Sancho Panza. The recently renovated gardens and fountains provide a pleasant setting for a stroll.

**Puerta de Alcalá**
You pass by the Puerta de Alcalá, a neoclassical triumphal arch commissioned by Charles III in 1778. The five-arched granite gateway stands at the edge of the Retiro Park and is one of Madrid's most photographed landmarks.

**Puerta del Sol**
You arrive at Puerta del Sol, the geographic centre of Spain and the origin point from which all national road distances are measured. The bustling semicircular plaza is home to the famous clock tower and the Bear and Strawberry Tree statue.

**Paseo del Prado**
You stroll along the Paseo del Prado, the tree-lined boulevard that forms the cultural spine of Madrid. The avenue passes the Prado Museum, the Neptune and Cibeles fountains, and the Royal Botanical Garden.

*Your vehicle and guide are at your disposal throughout the day for the Madrid city tour.*

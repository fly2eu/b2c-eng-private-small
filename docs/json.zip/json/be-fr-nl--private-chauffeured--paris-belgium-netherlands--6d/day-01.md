## Day 1 — Paris

Your journey begins with an evening arrival in the French capital.

**Paris Orly Airport Arrival**
A private transfer brings you from Orly Airport to your hotel in the city centre. Your driver navigates the evening traffic while you take in your first glimpses of Parisian boulevards through the window.

**Hotel Check-In**
You check in to your centrally located hotel and have the rest of the evening at leisure. An early night sets the tone for a full day of exploration ahead.

*A private transfer brings you from Orly Airport to your hotel in central Paris.*

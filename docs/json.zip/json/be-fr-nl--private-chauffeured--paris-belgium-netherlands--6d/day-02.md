## Day 2 — Paris

Your vehicle carries you across the French capital as you visit its most celebrated landmarks. From the artistic heights of Montmartre to the iron silhouette of the Eiffel Tower, each stop reveals a different facet of Paris.

**Montmartre**
Your driver drops you at the foot of Montmartre, the hilltop village that still carries the spirit of the artists who once lived here. Winding staircases lead past portrait painters and tiny cafes tucked into limestone facades.

**Sacre-Coeur Basilica**
Crowning the summit of Montmartre, this Romano-Byzantine basilica gleams white against the Paris skyline. You step inside to find a vast golden mosaic overhead and, from the terrace outside, a panorama stretching across the entire city.

**Arc de Triomphe**
Your vehicle brings you to the Place Charles de Gaulle where the Arc de Triomphe commands the junction of twelve radiating avenues. Commissioned by Napoleon in 1806, the monument honours those who fought for France, with intricate relief sculptures covering its pillars.

**Champs-Elysees**
From the Arc you stroll down the Champs-Elysees, one of the world's most celebrated avenues. Tree-lined and nearly two kilometres long, it stretches toward the Place de la Concorde, flanked by flagship stores and grand terraces.

**Notre-Dame Cathedral**
A private transfer brings you to the Ile de la Cite to stand before Notre-Dame, the Gothic masterpiece that has anchored the heart of Paris since the twelfth century. Its flying buttresses, rose windows, and sculptural portals represent the height of medieval craftsmanship.

**Louvre Museum**
You enter through the glass pyramid into the world's largest art museum. Home to the Mona Lisa, the Winged Victory of Samothrace, and roughly thirty-five thousand works on display, even a focused visit reveals centuries of artistic achievement.

**Eiffel Tower**
The day culminates at the Eiffel Tower, rising three hundred and thirty metres above the Champ de Mars. You take in the iron lattice structure up close, and as evening approaches the tower begins its sparkling light display across the Seine.

**Seine Canal Cruise (optional)**
You may choose to end the day with a cruise along the Seine. The boat glides past illuminated landmarks on both banks, offering a tranquil perspective on the city after a full day of sightseeing.

*Your private vehicle is at your disposal throughout the day for transfers between Paris landmarks.*

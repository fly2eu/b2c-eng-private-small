## Day 6 — Paris

Your final morning in Paris allows time for some last-minute shopping before your driver brings you to the airport for your onward journey.

**La Vallee Village**
Your driver takes you to a designer outlet village on the outskirts of Paris, where open-air lanes connect boutiques from European and international fashion houses. The relaxed setting and landscaped walkways make for a pleasant final morning activity.

**Transfer to CDG Airport**
A private transfer brings you to Charles de Gaulle Airport for your departure flight. Allow at least two hours before your scheduled departure for check-in and security.

*A private transfer brings you to CDG Airport for your departure flight.*

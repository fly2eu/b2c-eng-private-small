# Day 1 — Madrid & Toledo

Your driver meets you at Madrid Airport for a halal lunch and a panoramic city tour before heading south to Toledo, where Islamic scholarship once passed into Europe.

## Madrid Airport Arrival & Halal Lunch
Your driver greets you at Madrid Airport and takes you directly to a halal restaurant in the city. The meal provides a relaxed start to the tour before the afternoon programme begins.

## Panoramic Madrid City Tour
Your vehicle traces a route through Madrid's principal squares and landmarks. You pass Plaza de España, Plaza de Oriente, the grand arcades of Plaza Mayor, the bustling Puerta del Sol, and the fountains of Neptuno and Cibeles. The drive continues past the monumental Puerta de Alcalá and the Santiago Bernabéu Stadium.

## Santiago Bernabéu Stadium
The panoramic route passes the Santiago Bernabéu, home of Real Madrid. The exterior of the recently renovated stadium is visible from the road as your vehicle continues through the northern districts.

## Toledo Panoramic Tour
Your vehicle descends into Toledo, the city where Islamic, Jewish, and Christian scholars once worked side by side to translate Arabic scientific and philosophical texts into Latin. A panoramic tour circles the hilltop city, revealing its fortified walls, the Tagus River gorge below, and the layered history visible in every facade.

## Mosque of Cristo de la Luz (Bab al-Mardum)
You visit the Mosque of Bab al-Mardum, a 10th-century Islamic place of worship and one of the oldest surviving structures in Toledo. Its nine small domes, each with a distinct geometric vault pattern, demonstrate the sophistication of Umayyad architecture in central Spain.

---
**Hotel:** Madrid · **Transport:** Private transfer from Madrid Airport; Madrid to Toledo (1hr); return to Madrid

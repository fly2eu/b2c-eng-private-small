# Day 3 — Córdoba to Seville

The morning takes you to the ruins of Medinat Al-Zahra before your vehicle continues to Seville for the Royal Alcázar and an evening stroll along the Guadalquivir River.

## Medinat Al-Zahra *(included ticket)*
Your vehicle takes you to Medinat Al-Zahra, the palatial city of Caliph Abderrahman III. The archaeological site and its museum preserve carved stonework, water channels, and architectural fragments from what was once the administrative and ceremonial heart of the Umayyad Caliphate in Iberia.

## Royal Alcázar of Seville *(included ticket)*
You visit the Royal Alcázar, where Christian kings commissioned Muslim craftsmen to build a palace in the Mudéjar tradition. Intricate stucco, carved ceilings, and geometric tilework cover every surface. The formal gardens extend beyond the palace with fountains and pavilions.

## Giralda Tower
The Giralda Tower, originally the minaret of Seville's main mosque, rises above the city skyline. Its Almohad-era brickwork and geometric decoration remain clearly visible. You pause here for photographs.

## Barrio de Santa Cruz (Muslim Quarters)
You walk through the Barrio de Santa Cruz, the former Muslim quarter of Seville. Narrow lanes open onto hidden plazas shaded by orange trees, with tiled courtyards visible through ornate iron gates.

## Guadalquivir River Evening Walk *(optional)*
An evening stroll along the banks of the Guadalquivir River takes you past the Torre del Oro and the illuminated bridges. The promenade is a popular gathering spot as the city cools in the evening air.

---
**Hotel:** Seville · **Transport:** Private transfer from Córdoba to Seville (1.5hr)

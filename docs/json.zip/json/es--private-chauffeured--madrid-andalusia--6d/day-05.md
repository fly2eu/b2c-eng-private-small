# Day 5 — Granada to Madrid

The morning is devoted to the Alhambra before your vehicle departs for Madrid, with a halal buffet lunch en route and a panoramic evening drive through the capital.

## Alhambra *(included ticket)*
You spend the morning inside the Alhambra, walking through the Nasrid Palaces where Arabic inscriptions — prayers, Qur'anic verses, and poetry — cover every wall and ceiling in carved plaster and tile. The Court of the Lions, the Hall of the Ambassadors, and the Generalife gardens each demonstrate a distinct facet of Nasrid artistic achievement.

## Halal Buffet Lunch *(included)*
A halal buffet lunch is served at a roadside restaurant during the transfer from Granada to Madrid. The stop breaks the journey and provides a range of local and international dishes.

## Panoramic Madrid Evening Tour
Your vehicle traces an evening route through Madrid, passing the Santiago Bernabéu Stadium, the Royal Palace, Cibeles Fountain, Puerta de Alcalá, and Puerta del Sol. The illuminated monuments take on a different character after dark.

---
**Hotel:** Madrid · **Transport:** Private transfer from Granada to Madrid (4hr) with lunch stop

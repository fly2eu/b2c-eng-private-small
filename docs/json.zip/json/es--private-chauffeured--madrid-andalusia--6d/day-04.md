# Day 4 — Seville to Ronda to Granada

Your vehicle heads inland to the clifftop city of Ronda before continuing east to Granada. The evening is spent in the Albaicín quarter with panoramic views of the Alhambra.

## Ronda
Your vehicle brings you to Ronda, a city split in two by the El Tajo gorge. You walk across the Muslim-era bridge and along the cliff-edge paths with panoramic views of the valley floor far below. The Muslim city walls and fortifications remain visible along the old quarter, and the city is noted as the birthplace of the Sufi master Ibn Abbas Al-Rundi.

## Albaicín Quarter
After arriving in Granada, you explore the Albaicín, the old Muslim quarter perched on a hillside opposite the Alhambra. Winding streets lead past carmen houses, hidden gardens, and viewpoints framing the palace against the Sierra Nevada mountains.

## Grand Mosque of Granada
The Grand Mosque of Granada occupies a prominent position at the top of the Albaicín. Its garden terrace provides one of the finest panoramic views of the Alhambra available in the city.

## Granada City Centre & Moroccan Bazaar *(optional)*
Free time in the city centre takes you past the Moroccan bazaar, Plaza Nueva, and the banks of the Darro River. Shops sell lanterns, tea sets, leather goods, and spices imported from North Africa.

---
**Hotel:** Granada · **Transport:** Private transfer Seville to Ronda (2hr), Ronda to Granada (3hr)

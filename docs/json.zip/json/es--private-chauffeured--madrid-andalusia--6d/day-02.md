# Day 2 — Madrid to Córdoba

A four-hour private transfer brings you south to Córdoba, the capital of Al-Andalus for over three centuries. The afternoon is devoted to the Great Mosque, the Roman Bridge, and the Museum of Al-Andalus.

## Great Mosque of Córdoba *(included ticket)*
Your guide leads you through the Great Mosque of Córdoba, capital of Al-Andalus for more than 300 years. Inside, a forest of columns and double arches in red and white stone stretches in every direction. The visit traces the mosque's evolution through successive Umayyad enlargements.

## Roman Bridge & Calahorra Tower
You cross the Roman Bridge over the Guadalquivir, pausing at the Calahorra Tower on the far bank. The bridge and tower together offer the most recognisable view of Córdoba, with the mosque rising behind the city walls.

## Traditional Andalusian Lunch
Lunch is served at a traditional Andalusian house restaurant in the old quarter. The courtyard setting, with tiled walls and potted plants, is typical of Córdoba's domestic architecture.

## Museum of Al-Andalus
The evening visit takes you to the Museum of Al-Andalus, housed inside the Calahorra Tower. Exhibits cover the contributions of scholars such as Ibn Rushd (Averroes) and Maimonides, illustrating the intellectual achievements of Islamic Córdoba during its golden age.

## Córdoba Shopping *(optional)*
Free time in the evening allows you to browse the shops of the old quarter. Córdoba is known for its leather craft, silver filigree jewellery, and hand-painted ceramics.

---
**Hotel:** Córdoba · **Transport:** Private transfer from Madrid to Córdoba (4hr)

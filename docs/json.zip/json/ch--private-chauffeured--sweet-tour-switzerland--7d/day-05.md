# Day 5 — A Golden Train, Alpine Cheese and a Fairy-Tale Castle

One of Switzerland's most celebrated rail journeys carries you through rolling pastures and lakeside vistas to the French-speaking countryside. After exploring a renowned cheese factory and a hilltop castle, your vehicle sweeps through the Swiss capital before returning to Interlaken.

---

## GoldenPass Express
You board the panoramic GoldenPass Express for a two-hour-and-twenty-five-minute journey that ranks among the finest rail experiences in Europe. Oversized windows frame a constantly shifting tableau of emerald meadows, mirror-still lakes and distant glaciers as the train glides westward to Montbovon.

## La Maison du Gruyère
At this modern demonstration dairy you follow the entire journey of Gruyère cheese, from fresh morning milk to the vast ageing cellars where thousands of wheels mature in silence. Interactive displays and the rich aroma of the ripening rooms bring the centuries-old craft to life.

## Gruyères Castle
Perched on a small hilltop above the cobbled village, this thirteenth-century castle presides over a sweeping panorama of pre-Alpine peaks and patchwork farmland. Inside, richly decorated halls and a collection of medieval artefacts trace eight centuries of the Counts of Gruyères.

## Maison Cailler
Two kilometres from Gruyères village in Broc, the Maison Cailler takes you through the 200-year story of Switzerland's oldest chocolate brand. The self-guided journey moves through immersive rooms tracing the craft from its Aztec origins to Cailler's modern atelier, ending in a generous tasting room where you sample the full range of milk, dark and praline creations.

## Bern Panoramic Drive
Your driver navigates through the Swiss capital, passing its UNESCO-listed medieval arcades, the Bundeshaus parliament building and the distinctive green loop of the River Aare far below. It is a scenic introduction to a city you may wish to return to at leisure.

---

**Overnight:** Interlaken

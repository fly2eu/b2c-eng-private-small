# Day 6 — Waterfalls, Cliff Walks and a 360-Degree Summit

The penultimate day reaches for the sky. From the valley of seventy-two waterfalls you ascend by cable car to nearly three thousand metres, where a revolving platform serves up one of the most far-reaching panoramas in the Alps. Your vehicle then returns you to Zurich for the final night.

---

## Lauterbrunnen Valley
Sheer cliff walls rise on either side of this glacier-carved valley, sending seventy-two waterfalls tumbling hundreds of metres in ribbons of white. Staubbach Falls, the most famous of them, free-falls nearly three hundred metres right beside the village, filling the air with a fine, cool mist.

## Schilthorn Summit
A series of cable cars lifts you to 2,970 metres, where the Skyline Walk viewing platform extends into thin air above a sheer drop. The Thrill Walk, bolted to the cliff face, adds an exhilarating edge. At the revolving summit you take in a full circle of peaks — Eiger, Mönch, Jungfrau, Mont Blanc and, on clear days, the distant Black Forest.

## Transfer to Zurich
Your private vehicle departs the Bernese Oberland and follows the motorway north through the Swiss Mittelland. The two-hour drive offers a last look at rolling green countryside before reaching your Zurich hotel for the evening.

---

**Overnight:** Zurich

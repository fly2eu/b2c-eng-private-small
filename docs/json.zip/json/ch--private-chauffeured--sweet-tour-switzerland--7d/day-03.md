# Day 3 — City Landmarks, Master Chocolatiers and the Road to Interlaken

A final guided walk through Zurich's architectural highlights precedes a scenic transfer south. In Lucerne you visit a master chocolatier's workshop for hands-on tasting, before your vehicle continues through Alpine foothills to Interlaken.

---

## Zurich Guided Walking Tour
A two-hour walk with a local guide reveals the landmarks that define Zurich — its twin-towered Grossmünster, the narrow Augustinergasse, and the sweeping lakefront promenade. You hear stories of the city's transformation from Roman trading post to global financial centre.

## Max Chocolatier Masterclass
Inside this acclaimed Lucerne atelier, a master chocolatier guides you through a ninety-minute tasting of handcrafted ganaches and single-origin bars. You then step behind the counter to temper, fill and decorate your own chocolate piece to take home — a sweet, hands-on souvenir of the day.

## Transfer to Interlaken
Your private vehicle winds south from Lucerne along the shore of Lake Brienz, passing through lush green valleys framed by snow-dusted peaks. The drive is as much a sightseeing experience as a transfer, delivering you to your Interlaken hotel by early evening.

---

**Overnight:** Interlaken

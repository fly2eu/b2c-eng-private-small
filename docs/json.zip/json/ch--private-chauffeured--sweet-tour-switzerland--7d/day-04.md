# Day 4 — Alpine Panoramas and a Chocolate Workshop

Today belongs entirely to Interlaken and the mountains that encircle it. A funicular ride delivers you to a dramatic glass viewing platform high above the valley, while the afternoon is spent crafting your own chocolate creations in a hands-on workshop.

---

## Harder Kulm
The vintage funicular climbs steeply to 1,322 metres, where the Two Lakes Bridge juts out over the void with a glass-floored viewing platform. From here you gaze down at the turquoise waters of Lake Thun and Lake Brienz simultaneously, while the mighty trio of Eiger, Mönch and Jungfrau fills the southern horizon.

## Funky Chocolate Club Workshop
In this lively seventy-five-minute session you learn the art of tempering, moulding and decorating Swiss chocolate from scratch. Working at your own station, you create a personalised selection of bars and truffles — all of which you wrap up and take with you as an edible memento.

---

**Overnight:** Interlaken

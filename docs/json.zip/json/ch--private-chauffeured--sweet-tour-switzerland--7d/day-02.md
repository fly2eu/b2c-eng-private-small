# Day 2 — Chocolate, Cascades and Medieval Streets

The morning unfolds on a guided walk through Zurich's finest chocolate addresses, from boutique ateliers to historic confectioners. After lunch your vehicle heads north to the thundering Rhine Falls, before returning through one of Switzerland's best-preserved medieval towns.

---

## Zurich Chocolate Walking Tour
A two-and-a-half-hour guided stroll leads you through Zurich's most celebrated chocolate shops and specialty boutiques. You sample pralines and truffles at each stop, weaving through Paradeplatz and the cobbled lanes of the old town as your guide shares the story of Swiss chocolate-making.

## Rhine Falls
Europe's most powerful waterfall stretches 150 metres wide, sending plumes of mist into the air beside the medieval walls of Laufen Castle. You descend to the viewing platforms for an up-close encounter with the roaring cascade, feeling the spray on your skin as thousands of cubic metres of water thunder past each second.

## Rhine Falls Boat Ride
A short boat excursion carries you across the basin to the central rock that splits the falls. Standing on the platform at its summit, you are surrounded on every side by cascading water — a perspective that reveals the full scale and power of the Rhine.

## Stein am Rhein
On the return drive your vehicle pauses in this perfectly preserved medieval town. Half-timbered houses line the Rathausplatz, their facades decorated with vibrant frescoes dating back centuries. It is a quiet, photogenic stop that feels untouched by time.

---

**Overnight:** Zurich

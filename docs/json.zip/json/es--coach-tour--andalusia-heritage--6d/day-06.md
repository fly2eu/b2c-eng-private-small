# Day 6 — Departure from Málaga

The coach departs Granada for Málaga Airport, arriving by 11:00 am for departing flights.

## Airport Transfer
The group boards the coach for the transfer from Granada to Málaga Airport. Arrival is scheduled for 11:00 am, allowing time for check-in and departures.

---
**Hotel:** — · **Transport:** AC coach from Granada to Málaga Airport

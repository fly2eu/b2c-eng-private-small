# Day 5 — Alpujarra Mountains

The group journeys into the Alpujarra Mountains, where the last Muslims of Al-Andalus lived and practiced their faith for over 150 years after the fall of Granada. A traditional village visit and mountain lunch round out the day.

## Alpujarra Mountains
The coach climbs into the Alpujarra range on the southern slopes of the Sierra Nevada. These remote valleys sheltered the last Muslim communities of Al-Andalus, who continued to practise Islam for more than 150 years after the conquest of Granada in 1492. The terraced hillsides, flat-roofed whitewashed villages, and irrigation channels all bear the imprint of their Moorish builders.

## Pampaneira Village
The group stops in Pampaneira, one of three villages clinging to the Poqueira gorge. Traditional flat-roofed houses, handwoven carpets, and a small chocolate factory are among the attractions. The architecture preserves Berber building techniques brought from North Africa centuries ago.

## Mountain Lunch *(included)*
Lunch is served at a restaurant with panoramic views over the Alpujarra valley. The setting looks out across terraced hillsides and deep gorges to the distant Mediterranean coast.

## Alpujarra Shopping *(optional)*
Free time is available for browsing local shops selling handwoven rugs, ceramics, honey, and mountain herbs. The locally made carpets follow weaving traditions passed down through generations.

---
**Hotel:** Granada · **Transport:** AC coach round trip from Granada to Alpujarra Mountains

# Day 3 — Seville to Granada

The morning showcases Seville's Mudéjar masterpieces before the coach departs for Granada. The evening brings the group into the Albaicín quarter with its panoramic views of the Alhambra.

## Royal Alcázar of Seville *(included ticket)*
The group visits the Royal Alcázar, a Christian palace constructed by Muslim craftsmen in the Mudéjar style. Intricate stucco work, carved wooden ceilings, and geometric tilework fill every surface. The gardens beyond the palace walls are equally elaborate, with fountains, pavilions, and clipped hedges arranged in formal patterns.

## Giralda Tower
The Giralda Tower rises above the Seville skyline as the former minaret of the city's main mosque, built in 1182 during the Almohad period. The group pauses here for a photo stop, observing the distinctive brickwork and geometric patterns that mark its Islamic origins.

## Albaicín Quarter
After arrival in Granada, the group explores the Albaicín, the old Muslim quarter perched on a hillside opposite the Alhambra. The winding streets are lined with traditional carmen houses, hidden gardens, and viewpoints that frame the Alhambra palace against the Sierra Nevada mountains.

## Grand Mosque of Granada
The Grand Mosque of Granada sits at the top of the Albaicín quarter, offering panoramic views of the Alhambra from its garden terrace. Built in 2003, it is one of the first mosques constructed in Granada since the end of Muslim rule in 1492.

---
**Hotel:** Granada · **Transport:** AC coach from Seville to Granada (3hr)

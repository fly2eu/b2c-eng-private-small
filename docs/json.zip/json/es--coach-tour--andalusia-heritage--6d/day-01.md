# Day 1 — Málaga to Córdoba

The group arrives at Málaga Airport and boards the air-conditioned coach for the journey north to Córdoba. A lunchtime arrival allows for an optional halal meal before the afternoon programme begins in the historic centre.

## Málaga Airport Pickup
The group meets at Málaga Airport and boards the air-conditioned coach. The transfer to Córdoba takes approximately one and a half hours through the Andalusian countryside.

## Halal Restaurant Lunch *(optional)*
An optional halal lunch is available upon arrival in Córdoba. The restaurant serves traditional local dishes prepared according to halal standards.

## Great Mosque of Córdoba *(included ticket)*
The group visits the Great Mosque of Córdoba, one of the finest examples of Islamic architecture in Europe. Inside, a forest of 856 columns supports double arches in red and white stone, creating a visual rhythm that extends in every direction. A guided tour explains the mosque's construction during the Umayyad period and its significance as the spiritual heart of Al-Andalus.

## Bridge of Musa ibn Nusayr
The group crosses the Roman Bridge spanning the Guadalquivir River, historically associated with the Muslim commander Musa ibn Nusayr. The bridge offers views of the mosque and the city skyline reflected in the water below.

## Calahorra Tower
Standing at the southern end of the Roman Bridge, the Calahorra Tower served as a defensive fortification during the Islamic period. The group pauses here for photographs with the mosque and bridge in the background.

## Córdoba Old Quarters *(optional)*
Free time in the old quarters allows the group to wander the narrow whitewashed streets at their own pace. Local shops sell leather goods, ceramics, and traditional Andalusian crafts.

---
**Hotel:** Córdoba · **Transport:** AC coach from Málaga Airport to Córdoba (1.5hr)

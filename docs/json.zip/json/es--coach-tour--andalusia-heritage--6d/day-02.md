# Day 2 — Córdoba to Seville

The morning is devoted to the ruins of Medinat Al-Zahra before the coach continues to Seville. The afternoon brings the group to one of Spain's most iconic public spaces and the former Muslim quarters.

## Medinat Al-Zahra *(included ticket)*
The group visits Medinat Al-Zahra, the palatial city commissioned by the Umayyad Caliph during the 10th century. At its height, it represented the peak of Islamic civilisation in the Iberian Peninsula. A guided tour covers the archaeological remains and the on-site museum, which displays carved stonework, ceramics, and architectural fragments recovered from the site.

## Plaza de España
The group arrives at Plaza de España, a sweeping semicircular plaza bordered by a canal and decorated with tiled alcoves representing each Spanish province. The blend of Renaissance Revival and Moorish architectural elements makes it one of the most photographed locations in Seville.

## Seville Muslim Quarters *(optional)*
Free time in the former Muslim quarters of Seville reveals narrow streets lined with orange trees, tiled courtyards, and small artisan shops. The group is free to explore and shop at their own pace.

---
**Hotel:** Seville · **Transport:** AC coach from Córdoba to Seville (1.5hr)

## Day 5 — Sarajevo Departure

Your final morning in Sarajevo allows time for a last stroll through the old town and a parting coffee before your driver brings you to the airport.

**Morning Coffee & Bascarsija Stroll**
You return to Bascarsija for a final Bosnian coffee and a morning walk through the bazaar. The coppersmiths are already at work, their rhythmic hammering echoing through the lanes. This is the time to pick up handcrafted souvenirs — engraved coffee sets, kilim textiles, or ceramic bowls.

**Souvenir Shopping**
The old bazaar lanes are filled with artisan workshops where you can find hand-hammered copper dzezvas, embroidered textiles, and locally made jewellery. Each piece carries the mark of Bosnian craftsmanship passed down through generations.

**Airport Transfer**
A private transfer brings you to Sarajevo International Airport for your departure flight. The drive from the old town takes roughly twenty minutes along the river.

*A private transfer brings you to Sarajevo Airport for your departure flight.*

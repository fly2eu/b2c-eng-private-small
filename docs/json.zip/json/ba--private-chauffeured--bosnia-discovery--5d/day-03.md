## Day 3 — Sarajevo Relaxation & Nature

A gentler day in and around Sarajevo. You choose between the tranquil parklands at the source of the Bosna River or a cable car ascent to the mountain that watched over the 1984 Winter Olympics.

**Vrelo Bosne Park (optional)**
Your driver brings you to the western edge of Sarajevo where the Bosna River emerges from underground in a series of clear-water springs. A tree-lined promenade leads through the park, and wooden footbridges cross the braided channels. Swans glide across the pools and the mountain air carries the scent of damp earth and fresh leaves.

**Trebevic Mountain Cable Car (optional)**
Alternatively, you ride the rebuilt cable car from the old town up to Trebevic Mountain, site of the 1984 Winter Olympic bobsled track. At the top, the panorama over the terracotta rooftops of Sarajevo and the surrounding valley is one of the finest in the Balkans. The abandoned bobsled run, now covered in graffiti art, adds a haunting layer of recent history.

**Tunnel of Hope (optional)**
An optional visit takes you to the Tunnel of Hope, the underground passage dug beneath the airport runway during the 1992-1995 siege. The museum preserves a section of the eight-hundred-metre tunnel and tells the story of how it served as Sarajevo's lifeline, carrying food, medicine, and supplies into the besieged city.

**Sarajevo Coffee Ritual**
You settle into a traditional kahva, the Bosnian coffee ceremony. Served in a copper dzezva with a sugar cube and rahat lokum on the side, the ritual is unhurried and social. The old town cafes offer cushioned seating with views onto the bustling lanes.

*Your driver is available for transfers to Vrelo Bosne (approximately 12 km from centre) and back. Cable car departs from the old town.*

# Day 2 — Marrakesh to Rabat

The morning explores the palaces and gardens of Marrakesh before your vehicle heads north to the capital, Rabat.

## Bahia Palace
You visit the Bahia Palace, a 19th-century masterpiece of Moroccan domestic architecture. Rooms open onto courtyards tiled in zellige mosaics, with painted cedar ceilings and stucco arches framing gardens planted with jasmine and citrus trees.

## Menara Gardens
The Menara Gardens surround a large reflecting pool backed by an Almohad-era pavilion. On clear days, the snow-capped Atlas Mountains appear behind the pavilion, creating one of the most iconic views in Marrakesh.

## Marrakesh Medina & Bazaar
You enter the medina through one of the historic gates and follow the narrow souks where artisans sell leather goods, brass lanterns, carpets, and spices. The covered markets branch in every direction, each specialising in a different trade.

## Koutoubia Mosque & Jemaa el-Fnaa *(optional)*
Free time near the Koutoubia Mosque, whose 12th-century minaret dominates the Marrakesh skyline and served as the model for the Giralda in Seville. The adjacent Jemaa el-Fnaa square fills with food stalls, storytellers, and musicians as the day progresses.

## Transfer to Rabat
Your vehicle departs Marrakesh for the four-hour drive north to Rabat, Morocco's administrative capital. The route passes through the agricultural heartland of the Haouz plain.

---
**Hotel:** Rabat · **Transport:** Private transfer from Marrakesh to Rabat (4hr)

# Day 5 — Seville to Córdoba to Granada

The morning takes you to Córdoba for the Great Mosque and Roman Bridge before continuing east to Granada, where the evening is spent in the Albaicín quarter.

## Great Mosque of Córdoba *(included ticket)*
Your guide leads you through the Great Mosque of Córdoba, where a forest of columns and double arches stretches in every direction. The red and white stonework creates a distinctive visual rhythm that has influenced architects for a millennium.

## Bridge of Musa ibn Nusayr & Calahorra Tower
You cross the Roman Bridge over the Guadalquivir and pause at the Calahorra Tower on the far bank. Together they provide the classic view of Córdoba with the mosque rising above the city walls.

## Albaicín Quarter
After an afternoon transfer to Granada, you explore the Albaicín, the historic Muslim quarter on a hillside facing the Alhambra. Winding streets lead past carmen houses, hidden gardens, and viewpoints framing the palace against the Sierra Nevada.

## Grand Mosque of Granada
The Grand Mosque of Granada sits at the top of the Albaicín, its garden terrace offering one of the finest panoramic views of the Alhambra. It is one of the first mosques built in Granada since 1492.

---
**Hotel:** Granada · **Transport:** Private transfer Seville to Córdoba, then Córdoba to Granada

# Day 4 — Tangier to Tarifa to Seville

You board the ferry across the Strait of Gibraltar from Tangier to Tarifa, then your vehicle continues to Seville for an afternoon of Mudéjar architecture and historic quarters.

## Strait of Gibraltar Ferry
You board the ferry at Tangier port for the crossing of the Strait of Gibraltar. The voyage to Tarifa takes approximately one hour, with views of the African and European coastlines converging at the narrowest point of the strait.

## Transfer Tarifa to Seville
After disembarking in Tarifa, your vehicle continues north to Seville. The drive of approximately two and a half hours passes through the rolling hills and whitewashed villages of western Andalusia.

## Royal Alcázar of Seville *(included ticket)*
You visit the Royal Alcázar, where Christian kings employed Muslim craftsmen to create a palace in the Mudéjar tradition. Stucco, carved ceilings, and geometric tilework fill every hall. The formal gardens extend beyond the palace with fountains and pavilions arranged in Islamic-influenced patterns.

## Giralda Tower
The Giralda Tower was originally the minaret of Seville's Almohad-era mosque. Its brickwork and geometric decoration mirror the Hassan Tower you visited in Rabat — both were designed by the same dynasty of builders.

## Seville Muslim Quarters & Plaza de España
You explore the former Muslim quarters of Seville, with their narrow streets, orange trees, and tiled courtyards. The walk continues to Plaza de España, a sweeping semicircular plaza decorated with ceramic alcoves representing each Spanish province.

---
**Hotel:** Seville · **Transport:** Ferry Tangier to Tarifa; private transfer Tarifa to Seville (2.5hr)

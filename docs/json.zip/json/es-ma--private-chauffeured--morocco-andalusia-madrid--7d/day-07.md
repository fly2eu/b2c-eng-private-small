# Day 7 — Departure from Madrid

An optional morning shopping visit is available before your private transfer to Madrid Airport.

## Las Rozas Factory Outlet *(optional)*
An optional visit to the Las Rozas Village outlet centre is available for those with later flights. The open-air complex hosts discounted European and international fashion brands.

## Madrid Airport Transfer
Your private vehicle transfers you to Madrid Airport in time for your departing flight.

---
**Hotel:** — · **Transport:** Private transfer to Madrid Airport

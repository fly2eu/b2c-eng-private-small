# Day 1 — Casablanca to Marrakesh

Your driver meets you at Casablanca Airport. After a stop at the Hassan II Mosque, your vehicle proceeds south through the plains to Marrakesh.

## Casablanca Airport Arrival
Your driver greets you at Casablanca Mohammed V Airport and loads your luggage into the waiting vehicle. The journey into the city is short, passing through the commercial districts of Morocco's largest metropolis.

## Mosque of Hassan II
You visit the Mosque of Hassan II, one of the largest mosques in the world, built partly over the Atlantic Ocean. Its 210-metre minaret is the tallest religious structure in Africa. The exterior terraces and courtyard offer views across the ocean, and guided interior visits may be available depending on prayer schedules.

## Transfer to Marrakesh
Your vehicle departs Casablanca for the three-hour drive south to Marrakesh. The route crosses the fertile Chaouia plains before the Atlas Mountains come into view on the approach to the city.

---
**Hotel:** Marrakesh · **Transport:** Private transfer from Casablanca Airport to Marrakesh (3hr)

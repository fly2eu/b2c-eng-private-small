# Day 3 — Rabat to Tangier

The morning covers the historic sites of Rabat — from the fortified Kasbah to the unfinished mosque of Hassan Tower — before your vehicle continues north to Tangier on the Strait of Gibraltar.

## Rabat Old Medina
You walk through Rabat's old medina, a compact quarter of whitewashed houses with blue-painted doors and shutters. The medina sits above the mouth of the Bou Regreg River and retains a quieter atmosphere than its larger counterparts in Fez and Marrakesh.

## Kasbah of the Udayas
The Kasbah of the Udayas occupies a rocky promontory overlooking the Atlantic. You enter through the ornamental Almohad gate and walk through the Andalusian Gardens within the walls, where bougainvillea and citrus trees surround a central fountain.

## Hassan Tower
Hassan Tower stands as the unfinished minaret of what was intended to be the largest mosque in the western Islamic world. Begun in 1195 under the Almohad dynasty, the construction halted with the death of Sultan Yacoub al-Mansour. The surrounding columns mark the footprint of the never-completed prayer hall.

## Mausoleum of Muhammad V
Adjacent to Hassan Tower, the Mausoleum of Muhammad V houses the tombs of King Muhammad V and his sons. The interior features Carrara marble floors, a carved cedar ceiling, and zellige tilework executed by Moroccan master craftsmen.

## Rabat Bazaar *(optional)*
Free time in the bazaar allows you to browse stalls selling embroidered textiles, Rabat-style carpets, and traditional Moroccan pottery before departure.

## Transfer to Tangier
Your vehicle departs Rabat for the three-hour drive north to Tangier. The route follows the Atlantic coast before turning inland through the hills of the Rif.

---
**Hotel:** Tangier · **Transport:** Private transfer from Rabat to Tangier (3hr)

# Day 6 — Granada to Madrid

The morning is devoted to the Alhambra before your vehicle departs for Madrid. An evening panoramic tour of the capital rounds out the day.

## Alhambra *(included ticket)*
You spend the morning inside the Alhambra, walking through the Nasrid Palaces where Arabic inscriptions — prayers, Qur'anic verses, and poetry — cover every surface in carved plaster and tile. The Court of the Lions, the Hall of the Ambassadors, and the Generalife gardens each demonstrate a distinct dimension of Nasrid artistry.

## Transfer to Madrid
Your vehicle departs Granada for the four-and-a-half-hour drive north to Madrid. The route crosses the high plateau of La Mancha before descending into the capital.

## Panoramic Madrid Tour
Your vehicle traces an evening route through Madrid, passing the Royal Palace, the Santiago Bernabéu Stadium, Puerta de Alcalá, and Puerta del Sol. The illuminated monuments provide a dramatic first impression of the Spanish capital.

---
**Hotel:** Madrid · **Transport:** Private transfer from Granada to Madrid (4.5hr)

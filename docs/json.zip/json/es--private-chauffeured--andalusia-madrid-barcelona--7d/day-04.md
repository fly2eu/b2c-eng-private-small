# Day 4 — Alhambra, Toledo & Madrid

The morning is devoted to the Alhambra before your vehicle heads north to Toledo for a panoramic tour and the Mosque of Bab al-Mardum. The day ends in Madrid.

## Alhambra *(included ticket)*
You spend the morning inside the Alhambra, walking through the Nasrid Palaces founded by Muhammad al-Ahmar. Arabic inscriptions — prayers, Qur'anic verses, and poetry — cover every wall and ceiling in carved plaster and tile. The Court of the Lions, the Hall of the Ambassadors, and the Generalife gardens each reveal a distinct facet of Nasrid artistic mastery.

## Toledo Panoramic Tour & Mirador del Valle
Your vehicle circles the hilltop city, pausing at the Mirador del Valle for a panoramic photograph. The viewpoint reveals Toledo's medieval skyline, fortified walls, and the Tagus River gorge curving below.

## Zocodover Square & Damascene Workshop
You walk through Zocodover Square and visit a damascene workshop where artisans inlay gold and silver wire into blackened steel. The technique arrived in Toledo during the Islamic period and remains a living craft passed through generations.

## Mosque of Bab al-Mardum
You enter the Mosque of Bab al-Mardum, a 10th-century place of worship and one of Toledo's oldest surviving structures. Nine small domes, each with a distinct geometric vault pattern, demonstrate the sophistication of Umayyad architecture in central Iberia.

---
**Hotel:** Madrid · **Transport:** Private transfer from Granada to Toledo (4hr); Toledo to Madrid (1hr)

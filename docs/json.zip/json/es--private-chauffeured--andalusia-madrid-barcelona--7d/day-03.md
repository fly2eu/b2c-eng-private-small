# Day 3 — Seville to Granada

Your vehicle heads east through the plains of La Mancha on the four-hour journey to Granada. The evening is spent exploring the Albaicin quarter, the Grand Mosque, and the Moroccan bazaar.

## La Mancha Landscape Drive
Your vehicle crosses the open plateau of La Mancha on the road east to Granada. The terrain shifts between olive groves, wheat fields, and vineyards under a wide sky. The landscape evokes the timeless character of central Spain.

## Albaicin Quarter
You explore the Albaicin, Granada's old Muslim quarter set on a hillside opposite the Alhambra. Winding cobbled streets lead past carmen houses with hidden gardens and viewpoints that frame the palace against the Sierra Nevada.

## Grand Mosque of Granada
The Grand Mosque of Granada occupies a prominent position at the top of the Albaicin. Its garden terrace provides one of the finest panoramic views of the Alhambra, with the palace complex spread across the opposite ridge.

## Moroccan Bazaar & City Centre *(optional)*
Free time takes you through the Moroccan bazaar and the city centre around Plaza Nueva. Shops sell lanterns, tea sets, leather goods, and spices imported from North Africa, giving this part of Granada a distinctly Maghrebi atmosphere.

---
**Hotel:** Granada · **Transport:** Private transfer from Seville to Granada (4hr)

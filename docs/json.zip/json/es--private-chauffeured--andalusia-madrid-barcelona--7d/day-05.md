# Day 5 — Madrid & Transfer to Barcelona

The morning features a panoramic drive through the capital's principal landmarks before your vehicle transfers you to Barcelona for the second half of your journey through Spain.

## Panoramic Madrid Tour
Your vehicle traces a route through the capital, passing the Santiago Bernabeu Stadium, the Royal Palace, Cibeles Fountain, Puerta de Alcala, and Puerta del Sol. The drive provides an overview of Madrid's grand avenues and monumental squares.

## Puerta del Sol Shopping *(optional)*
Free time at Puerta del Sol allows you to browse the shops along Gran Via and the surrounding pedestrian streets. The area is the commercial heart of the capital, with Spanish and international retailers lining every block.

## Transfer to Barcelona
Your vehicle departs Madrid for Barcelona. The transfer covers the breadth of central Spain, arriving in Catalonia by evening.

---
**Hotel:** Barcelona · **Transport:** Private transfer from Madrid to Barcelona

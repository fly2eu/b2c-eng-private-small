# Day 1 — Malaga to Cordoba

Your guide meets you at Malaga Airport and your vehicle heads north to Cordoba, the capital of Al-Andalus for over three centuries. The afternoon is devoted to the Great Mosque, the Roman Bridge, and the old quarters.

## Malaga Airport Arrival
Your guide greets you at Malaga Airport and escorts you to your private vehicle. The transfer north to Cordoba takes approximately two hours through the Andalusian countryside.

## Great Mosque of Cordoba *(included ticket)*
Your guide leads you into the Great Mosque of Cordoba, the spiritual centre of Al-Andalus for more than 300 years. A forest of columns and double arches in alternating red and white stone stretches in every direction. The visit traces the mosque's evolution through successive Umayyad enlargements.

## Bridge of Musa ibn Nusayr & Calahorra Tower
You cross the Roman Bridge over the Guadalquivir, pausing at the Calahorra Tower on the far bank. The bridge and tower together frame the most recognisable view of Cordoba, with the Great Mosque rising behind the old city walls.

## Andalusi House
You visit the Andalusi House, a museum recreating daily life in Islamic Cordoba. Exhibits include calligraphy, astronomy instruments, and domestic objects that illustrate the intellectual and artistic culture of the caliphal period.

## Cordoba Old Quarters *(optional)*
Free time in the old quarters allows you to wander narrow lanes lined with whitewashed houses and flower-filled patios. Cordoba is celebrated for its leather craft, silver filigree, and hand-painted ceramics.

---
**Hotel:** Cordoba · **Transport:** Private transfer from Malaga Airport to Cordoba (2hr)

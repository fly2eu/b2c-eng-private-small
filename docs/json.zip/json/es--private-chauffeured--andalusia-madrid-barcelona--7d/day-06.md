# Day 6 — Barcelona

A full day in Barcelona takes you from the Sagrada Familia to the hilltop views of Mont Juic, through the Gothic Quarter, and into the sensory spectacle of La Boqueria market.

## Sagrada Familia
Your vehicle pauses at the Sagrada Familia for a photo stop. Gaudi's unfinished basilica rises above the Eixample district, its organic stone facades and soaring towers unlike any other building in Europe.

## Camp Nou *(optional)*
Your vehicle brings you to Camp Nou, the home ground of FC Barcelona. Entry to the stadium museum and tour is available as an optional add-on for those interested in the club's history and the scale of the arena.

## Mont Juic Panoramic View
Your vehicle ascends Mont Juic for a panoramic view over the city, the port, and the Mediterranean coastline. The hilltop vantage point places Barcelona's grid-pattern streets, harbour, and mountain backdrop into a single sweeping frame.

## La Roca Village Factory Outlet *(optional)*
A visit to La Roca Village outlet centre provides time for shopping at discounted European and international fashion brands. The open-air village layout makes for a comfortable browsing experience.

## Barrio Gotico
You walk through the Barrio Gotico, Barcelona's medieval core. Narrow lanes open onto hidden plazas surrounded by Gothic stonework, and the route passes the remains of Roman walls and columns embedded in the later medieval fabric.

## La Boqueria Market
You enter La Boqueria, Barcelona's famous covered market on La Rambla. Stalls are piled with fresh fruit, seafood, nuts, spices, and Catalan specialities. The colours and aromas make this one of the most photogenic markets in Europe.

---
**Hotel:** Barcelona · **Transport:** Private vehicle within Barcelona

# Day 2 — Cordoba, Medinat Al-Zahra & Seville

The morning takes you to Medinat Al-Zahra before your vehicle continues to Seville for the Royal Alcazar, the Giralda Tower, and an evening stroll through the Muslim quarters.

## Medinat Al-Zahra *(included ticket)*
Your vehicle brings you to Medinat Al-Zahra, the palatial city of Caliph Abderrahman III. The archaeological site and its museum preserve carved stonework, water channels, and reception halls from what was once the ceremonial heart of the Umayyad Caliphate in the West.

## Royal Alcazar of Seville *(included ticket)*
You visit the Royal Alcazar, where Christian kings commissioned Muslim craftsmen to build a palace in the Mudejar tradition. Intricate stucco, carved ceilings, and geometric tilework cover every surface. The formal gardens extend beyond the palace walls with fountains and shaded pavilions.

## Giralda Tower
The Giralda Tower, originally the minaret of Seville's main mosque built in 1182, rises above the city skyline. Its Almohad-era brickwork and geometric decoration remain clearly visible on the exterior. You pause here for photographs.

## Muslim Quarters & Plaza de Espana
You walk through the former Muslim quarters of Seville, where narrow lanes open onto hidden plazas shaded by orange trees. The route continues to Plaza de Espana, a sweeping semicircular plaza decorated with ceramic tilework representing each Spanish province.

---
**Hotel:** Seville · **Transport:** Private transfer from Cordoba to Seville (1.5hr)

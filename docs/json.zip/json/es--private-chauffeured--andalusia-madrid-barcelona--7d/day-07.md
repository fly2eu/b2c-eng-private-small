# Day 7 — Departure from Barcelona

Free time in the morning allows for final shopping or sightseeing before your private transfer to Barcelona Airport.

## Barcelona Free Time *(optional)*
The morning is free for independent exploration or last-minute shopping along La Rambla and the surrounding streets. Your guide can suggest nearby points of interest based on your preferences.

## Barcelona Airport Transfer
Your private vehicle transfers you to Barcelona Airport. Departure is recommended four hours before your flight to allow time for check-in and formalities.

---
**Hotel:** — · **Transport:** Private transfer to Barcelona Airport

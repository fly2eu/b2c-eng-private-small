# Day 4 — Crossing into Switzerland — Bern

Your vehicle crosses the Swiss border and continues to Bern, the federal capital. The UNESCO-listed old town features medieval arcades, the Zytglogge clock tower, and views over the turquoise Aare River.

## Road Trip to Bern
Your vehicle departs Colmar and heads south into Switzerland. The drive takes approximately two hours, crossing the Rhine and passing through gentle green hills before reaching the Swiss capital.

## Bern Old Town
You explore Bern's UNESCO World Heritage old town, strolling beneath six kilometres of covered stone arcades. The medieval Zytglogge clock tower, the Federal Parliament building, and the Bear Park along the Aare River are key stops on the walking route.

---
**Hotel:** Bern · **Transport:** Private vehicle from Colmar to Bern (~2hr)
# Day 2 — Icons of Paris

Your vehicle takes you on a full-day tour of the French capital's most celebrated landmarks. From the iron silhouette of the Eiffel Tower to the artistic streets of Montmartre, the day covers Paris's essential highlights at a comfortable pace.

## Eiffel Tower
Your first stop is the Eiffel Tower, the wrought-iron landmark that defines the Paris skyline. From the esplanade you take in sweeping views across the Seine and the Champ de Mars gardens stretching below.

## Arc de Triomphe & Champs-Élysées
Your vehicle brings you to the Arc de Triomphe standing at the western end of the Champs-Élysées. A stroll down the famous boulevard passes luxury boutiques, grand cafés, and tree-lined pavements stretching toward Place de la Concorde.

## Notre-Dame Cathedral
On the Île de la Cité, you visit Notre-Dame Cathedral, a masterpiece of Gothic architecture dating to the 12th century. The restored façade displays intricate stone carvings, flying buttresses, and the iconic twin bell towers.

## Sacré-Cœur Basilica & Montmartre
Your vehicle drops you at the foot of the Montmartre hill for the walk up to Sacré-Cœur Basilica. The white-domed church offers panoramic views over the rooftops of Paris, and the surrounding artist quarter retains its bohemian charm with portrait painters and quaint lanes.

## Louvre Museum (Exterior)
The day concludes with a photo stop at the Louvre, the world's largest art museum. The glass pyramid entrance and the elegant Renaissance façades of the former royal palace make for memorable photographs in the evening light.

## Seine River Cruise *(optional)*
An optional boat cruise glides along the Seine, passing illuminated bridges, the Musée d'Orsay, and the Eiffel Tower from water level. The one-hour journey offers a different perspective on the city's monuments.

## Louvre Museum Entry *(optional)*
For those wishing to explore the interior, an optional entry ticket grants access to the Louvre's vast collection spanning Egyptian antiquities, Renaissance paintings, and classical sculptures.

## Disneyland Paris *(optional)*
An optional full-day visit to Disneyland Paris is available for families and thrill-seekers. The theme park features rides, live shows, and character parades set across themed lands.

---
**Hotel:** Paris · **Transport:** Private vehicle for city touring
# Day 1 — Arrival in Paris

Your vehicle meets you at the airport for a private transfer into the city. The evening is free to settle into the hotel and rest ahead of a full day of Parisian sightseeing.

## Airport Transfer to Paris Hotel *(included)*
Your private vehicle collects you from the arrivals hall and transfers you directly to your hotel in central Paris. The drive takes approximately one hour depending on traffic conditions.

---
**Hotel:** Paris · **Transport:** Private vehicle from airport to Paris hotel
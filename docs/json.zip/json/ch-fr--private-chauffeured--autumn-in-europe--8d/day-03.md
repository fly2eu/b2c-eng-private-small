# Day 3 — Road Trip to Alsace

Your vehicle departs Paris and heads east toward the Alsace region. The journey passes through the French countryside before arriving in Colmar, one of the most picturesque towns in eastern France.

## Scenic Drive to Colmar
Your private vehicle follows the route east from Paris through rolling French countryside. The drive covers approximately 500 kilometres and takes around five hours with comfort stops along the way.

## Colmar Old Town
You explore the charming Alsatian town of Colmar on foot, wandering through cobblestoned streets lined with half-timbered houses painted in pastel shades. The Little Venice quarter, with its canals and flower-draped bridges, is a highlight for photography.

---
**Hotel:** Colmar · **Transport:** Private vehicle from Paris to Colmar (~5hr)
# Day 5 — Zurich or Lucerne City Day

Your vehicle heads north to the Lake Zurich or Lake Lucerne region for a day of city sightseeing. Both cities offer waterfront promenades, historic old towns, and panoramic mountain backdrops.

## Zurich City Sightseeing
You stroll through Zurich's Altstadt, passing the twin towers of Grossmünster church, the elegant Bahnhofstrasse shopping avenue, and the lakeside promenade. The compact old town blends medieval guild houses with contemporary galleries and boutiques.

## Lucerne City Sightseeing
Alternatively, you visit Lucerne with its iconic Chapel Bridge, the oldest covered wooden bridge in Europe. The waterfront promenade along Lake Lucerne frames views of Mount Pilatus and Rigi, and the painted gables of the old town add to the charm.

---
**Hotel:** Lucerne · **Transport:** Private vehicle for city touring
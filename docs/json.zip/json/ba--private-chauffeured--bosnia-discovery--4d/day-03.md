## Day 3 — Mostar

The highlight of the journey. Your vehicle heads south through dramatic river gorges to reach Mostar, where a sixteenth-century bridge arcs gracefully over emerald waters. The return brings you past a clifftop monastery and, if you choose, thundering waterfalls hidden in the forest.

**Sarajevo to Mostar Drive**
Your vehicle departs early and follows the Neretva River southward for roughly one hundred and thirty kilometres. The road passes through Konjic, a small town with an elegant Ottoman bridge, and Jablanica, where remnants of a destroyed railway bridge recall a celebrated Second World War battle. The scenery tightens into gorges as you approach Herzegovina.

**Stari Most (Old Bridge)**
You arrive at Mostar's iconic Stari Most, the reconstructed sixteenth-century Ottoman bridge that soars twenty-four metres above the turquoise Neretva River. Originally built in 1566, destroyed in 1993, and painstakingly rebuilt by 2004, the bridge is a UNESCO World Heritage Site and a symbol of reconciliation. Divers leap from its apex into the river below while onlookers gather on the cobbled banks.

**Mostar Old Town**
You explore the narrow cobbled lanes on either side of the bridge, where Ottoman-era stone houses have been converted into artisan shops, coppersmiths, and open-air restaurants. The Koski Mehmed Pasha Mosque offers a minaret climb with a bird's-eye view of the bridge and the river below.

**Blagaj Tekke**
A short drive south of Mostar brings you to the Blagaj Tekke, a sixteenth-century Dervish monastery built directly into the cliff face where the Buna River emerges from underground. The turquoise water surges from a cave mouth at the base of a two-hundred-metre vertical rockface, creating one of the most dramatic settings for any building in the Balkans.

**Kravica Waterfalls (optional)**
An optional detour takes you to the Kravica Waterfalls, a wide curtain of water that drops roughly twenty-five metres into a natural amphitheatre of tufa rock and emerald pools. The setting feels tropical despite being deep in the Herzegovinian countryside, and the pools invite a moment of quiet contemplation.

**Return to Sarajevo**
Your driver returns you to Sarajevo by evening, following the Neretva gorge northward. The return journey takes approximately two and a half hours, with the fading light casting long shadows across the canyon walls.

*A full-day excursion: approximately 130 km south to Mostar with scenic stops, then 130 km back. Total driving around 4-5 hours.*

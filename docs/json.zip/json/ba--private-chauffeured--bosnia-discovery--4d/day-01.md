## Day 1 — Sarajevo

Your driver meets you at Sarajevo Airport and transfers you to the old town. The Ottoman-era heart of the city draws you in with its copper workshops, stone fountains, and the aroma of grilled cevapi.

**Sarajevo Airport Transfer**
A private transfer brings you from Sarajevo International Airport to your hotel near the old town. The drive takes roughly twenty minutes along the Miljacka River, passing the National Library and the Latin Bridge on the way in.

**Bascarsija Old Town**
You step into Bascarsija, the Ottoman-era bazaar quarter that has served as Sarajevo's commercial and cultural heart since the fifteenth century. Narrow lanes radiate from the central square, lined with coppersmiths hammering ornate plates and jewellers displaying filigree work. The atmosphere is dense with history and the rhythm of daily trade.

**Sebilj Fountain**
At the heart of Bascarsija stands the Sebilj, a wooden Ottoman-style fountain built in the nineteenth century. Legend says that anyone who drinks from it will return to Sarajevo. Pigeons swirl overhead as locals and visitors gather around this beloved meeting point.

**Gazi Husrev-beg Mosque**
You visit the largest historical mosque in Bosnia, built in 1531 under Ottoman patronage. Its stone courtyard, domed prayer hall, and adjacent madrasa form one of the finest examples of Ottoman architecture in the Balkans. The interior is serene, with calligraphic decoration adorning the walls.

**Cevapi Dinner**
The day ends at a traditional cevabdzinica where hand-formed beef and lamb cevapi arrive sizzling on a platter alongside warm somun flatbread, raw onion, and kajmak cream. The setting is simple and unpretentious — wooden benches, tiled walls, and decades of local reputation.

*A private transfer brings you from Sarajevo Airport to your hotel in the old town (approximately 20 minutes).*

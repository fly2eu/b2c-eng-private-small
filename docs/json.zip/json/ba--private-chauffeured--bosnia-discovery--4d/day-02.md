## Day 2 — Travnik & Jajce

Your vehicle departs early for a full day exploring two of central Bosnia's most compelling towns. Fortresses, turquoise springs, and a waterfall that tumbles into the centre of a town — the Bosnian heartland surprises at every turn.

**Sarajevo to Travnik Transfer**
A private transfer brings you roughly ninety kilometres northwest from Sarajevo to Travnik, the former seat of Bosnian viziers. The road winds through forested hills and past small rural villages, arriving in about ninety minutes.

**Travnik Fortress**
You climb to the medieval fortress that overlooks the town from a wooded hillside. The ramparts offer panoramic views of Travnik's minarets and red-roofed houses nestled in the valley below. Dating to the fifteenth century, the fortress served as a seat of Ottoman governors for over a hundred and fifty years.

**Plava Voda Springs**
Just outside the town centre, the Plava Voda springs emerge from beneath a rocky hillside in vivid shades of blue and green. Wooden terraces and traditional restaurants line the stream, making this one of the most picturesque natural gathering places in Bosnia. The water is ice-cold and crystal clear.

**Jajce Waterfall**
Your driver brings you further northwest to Jajce, where the Pliva River drops twenty-two metres over a travertine ledge right at the point where it meets the Vrbas River. The waterfall sits at the edge of the old town, making it one of the few urban waterfalls of its scale in Europe.

**Pliva Lakes & Mlincici Mills**
A short drive above the waterfall brings you to the Pliva Lakes, a pair of emerald reservoirs fed by the river. On the shore, a cluster of tiny wooden watermills known as mlincici stand on stilts over the rushing water, once used to grind grain and now one of Bosnia's most iconic images.

**Return to Sarajevo**
Your driver returns you to Sarajevo by evening, retracing the route through the Bosnian hills. The journey back takes roughly two and a half hours, arriving in time for a relaxed evening in the city.

*A full-day excursion: approximately 90 km to Travnik, then 55 km to Jajce, and 160 km back to Sarajevo. Total driving around 4-5 hours.*

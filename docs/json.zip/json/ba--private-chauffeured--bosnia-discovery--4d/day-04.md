## Day 4 — Nature Morning & Departure

A final morning allows time to visit one of Sarajevo's natural escapes before your driver brings you to the airport. The city bids farewell with mountain views, fresh air, and one last Bosnian coffee.

**Vrelo Bosne Park (optional)**
If time allows, your driver brings you to the western edge of Sarajevo where the Bosna River emerges from underground in a series of clear-water springs. A tree-lined promenade leads through the park, and wooden footbridges cross the braided channels. Swans glide across the pools and the mountain air carries the scent of damp earth and fresh leaves.

**Trebevic Mountain Cable Car (optional)**
Alternatively, a quick ride on the rebuilt cable car from the old town to Trebevic Mountain gives you a final panoramic farewell. The terracotta rooftops of Sarajevo spread out below, framed by the surrounding valley and mountain ridges.

**Morning Coffee & Bascarsija Stroll**
You return to Bascarsija for a final Bosnian coffee and a morning walk through the bazaar. The coppersmiths are already at work, their rhythmic hammering echoing through the lanes. This is the time to pick up handcrafted souvenirs — engraved coffee sets, kilim textiles, or ceramic bowls.

**Airport Transfer**
A private transfer brings you to Sarajevo International Airport for your departure flight. The drive from the old town takes roughly twenty minutes along the river.

*Optional morning nature visit, then a private transfer to Sarajevo Airport for departure.*

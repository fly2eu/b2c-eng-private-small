# Day 4 — Interlaken, Lauterbrunnen Valley & Jungfraujoch

The group travels deep into the Bernese Oberland for the tour's most dramatic day. The glacial Lauterbrunnen valley with its 72 waterfalls serves as the gateway to the rack railway ascent to Jungfraujoch — the highest railway station in Europe — where the Aletsch Glacier and a world of ice await at 3,454 metres above sea level.

## Transfer to Interlaken *(included)*
The coach departs Zurich early and drives south through the Bernese Oberland, arriving in Interlaken — the gateway town set between Lake Thun and Lake Brienz — after approximately two hours. The group transfers to the mountain railway for the ascent into the Alps.

## Lauterbrunnen Valley
The group enters the Lauterbrunnen valley, one of the most spectacular glacial troughs in the Swiss Alps. Sheer cliff faces up to 300 metres high rise on both sides as the valley narrows, and 72 waterfalls plunge from the high plateau above. The most celebrated is Staubbach Falls, which drops nearly 300 metres in a single free-fall ribbon before dispersing into a veil of mist above the valley floor — one of the tallest free-falling waterfalls in Europe.

## Jungfraujoch — Top of Europe *(included)*
The group ascends by rack railway to Jungfraujoch at 3,454 metres, the highest railway station on the European continent. From the Sphinx Observation Deck, the vast Aletsch Glacier — the longest in the Alps at 23 kilometres — stretches south in a sweeping river of ice towards the Italian border. Inside the mountain, the Ice Palace presents a series of chambers and passageways carved entirely from ancient glacier ice, with ice sculptures illuminated by coloured lighting. The group has approximately two to three hours at the summit before the descent.

---
**Hotel:** Interlaken · **Transport:** AC coach Zurich → Interlaken (130km, ~2hr), rack railway Interlaken → Lauterbrunnen → Jungfraujoch → Interlaken

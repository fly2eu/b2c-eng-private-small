# Day 5 — Lindt Chocolate, Colmar & Strasbourg

The morning returns to Zurich for the Lindt Home of Chocolate before the coach crosses into the Alsace region of France. The half-timbered canal district of Colmar and the pink sandstone cathedral of Strasbourg fill the afternoon, with an overnight in this historic Alsatian capital on the French-German border.

## Lindt Home of Chocolate, Zurich *(included)*
The group visits the Lindt Home of Chocolate near Zurich for a full interactive museum experience. The nine-metre-tall chocolate fountain containing 1,500 kilograms of continuously flowing melted chocolate anchors the central atrium, while the surrounding exhibits trace the history of Swiss chocolate from the tropical cocoa bean through roasting, conching, and tempering to the finished product. The museum shop provides ample opportunity to select Swiss chocolate to take home.

## Colmar — Petite Venise
The group arrives in Colmar, the Alsatian town whose colourful half-timbered houses and flower-decked canal district are said to have inspired the village designs for Disney's Beauty and the Beast. The Petite Venise quarter follows a branch of the Lauch river, where pastel-painted tanners' and fishermen's houses lean over the water beneath window boxes overflowing with geraniums. The scene has changed little in several centuries and the narrow lanes connecting the canal banks reward slow exploration on foot.

## Strasbourg — Notre-Dame Cathedral
The group arrives in Strasbourg and visits the Notre-Dame Cathedral, a masterpiece of Gothic architecture built from the pink Vosges sandstone that gives the façade a warm, reddish glow. The colour of the stone shifts noticeably through the day as the angle and quality of light changes — a quality unique to Strasbourg Cathedral among the great Gothic churches of Europe. The single spire rises 142 metres and was the tallest structure in the world for 227 years after its completion.

## Petite France District
The group explores the Petite France quarter, where the most beautifully preserved 16th-century timber-framed houses in Strasbourg line the canals of the River Ill. The buildings' overhanging upper floors, carved wooden beams, and window boxes full of flowers create one of the most visited streetscapes in France. Lock towers and the Ponts Couverts mark the boundary of this former tanner's and mill workers' district, now part of a UNESCO World Heritage Site.

---
**Hotel:** Strasbourg · **Transport:** AC coach Interlaken → Zurich (130km, ~2hr), Zurich → Colmar → Strasbourg (230km, ~2.5hr)

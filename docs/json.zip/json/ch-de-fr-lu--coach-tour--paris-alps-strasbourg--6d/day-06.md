# Day 6 — Strasbourg Morning & Return to Paris

The group enjoys a final morning in Strasbourg exploring the Petite France streets and the cathedral before the coach makes the return journey to Paris. The drive provides comfortable buffer time for the group's evening departures from the French capital.

## Strasbourg Morning — Petite France & Cathedral
The group has a final morning to explore Strasbourg at leisure. The canal-side lanes of Petite France are at their most atmospheric in the morning light, before the main tourist crowds arrive, and the pink Vosges sandstone of the Notre-Dame Cathedral glows warmly in the early sun. The group has approximately two hours of free time to revisit favourite spots, browse the Alsatian craft shops, or simply sit at a café table and watch the city come to life.

## Transfer Strasbourg to Paris *(included)*
The coach departs Strasbourg mid-morning for Paris, a journey of approximately four hours covering around 490 kilometres on the motorway through the Champagne countryside. The tour manager provides a review of the tour's highlights during the journey. The coach arrives in Paris with ample buffer time before the group's evening flights or other departures, with drop-off at the airport or a central Paris location agreed with the tour manager.

---
**Hotel:** — · **Transport:** AC coach Strasbourg → Paris (490km, ~4hr)

# Day 3 — Stuttgart to the Black Forest & Zurich

The coach departs Stuttgart and joins Germany's oldest scenic driving route through the Black Forest before crossing into Switzerland. The day ends in Zurich, where the old town and the promenade of Lake Zurich offer a graceful introduction to the country.

## Black Forest High Road (B500)
The coach joins the B500 Black Forest High Road, Germany's oldest designated scenic route, established in 1933. The 60-kilometre stretch winds through dense spruce and fir forests at elevations above 1,000 metres, crests high ridgelines with sweeping views down to the Rhine Valley and across to the Vosges Mountains in France, and negotiates a series of hairpin turns that make the drive itself one of the day's highlights. The tour leader provides commentary on the forest's ecology and cultural significance as the landscape unfolds.

## Zurich Old Town & Lake Promenade
The group arrives at the northern tip of Lake Zurich, where Switzerland's largest city combines a well-preserved medieval old town with one of Europe's most prosperous financial centres. The group explores the Altstadt's narrow lanes lined with guild houses, the twin towers of the Grossmünster, and the Fraumünster with its Marc Chagall windows, before walking the lakeside promenade where the still water reflects the distant Alpine foothills.

## Lindt Home of Chocolate *(optional)*
An optional visit to the Lindt Home of Chocolate near Zurich introduces the group to the history of Swiss chocolate-making through an interactive museum. The centrepiece is a nine-metre-tall chocolate fountain containing 1,500 kilograms of continuously flowing melted chocolate, and the extensive shop offers a wide selection of Lindt products to take home.

---
**Hotel:** Zurich · **Transport:** AC coach Stuttgart → Black Forest High Road → Zurich (230km, ~3hr including scenic detour)

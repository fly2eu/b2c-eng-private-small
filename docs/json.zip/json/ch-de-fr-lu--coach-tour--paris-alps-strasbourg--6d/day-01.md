# Day 1 — Arrival in Paris — Eiffel Tower, Seine & Montmartre

The group arrives in Paris and immediately sets out to explore three of the city's most iconic experiences. The iron lattice of the Eiffel Tower, the bookstall-lined banks of the Seine, and the artists' hilltop quarter of Montmartre together paint an unforgettable introduction to the French capital.

## Eiffel Tower
The group visits the Eiffel Tower, Paris's defining iron landmark standing 324 metres tall on the Champ de Mars. Designed by Gustave Eiffel and completed in 1889 for the World's Fair, the tower's intricate lattice structure — assembled from 18,038 pieces of puddled iron — remains one of the most ambitious engineering achievements of the 19th century. The surrounding Champ de Mars gardens provide the best vantage point for photographs of the full structure.

## Seine River — Bouquinistes Stalls
The group strolls along the UNESCO-listed banks of the Seine, where the famous bouquinistes — open-air booksellers operating from dark green metal boxes fixed to the riverside parapets — have traded their books, prints, and maps since the 16th century. The walk passes riverside views of Notre-Dame Cathedral, the Pont Neuf, and the Louvre façade reflected in the water, with the gentle sound of the river providing a peaceful contrast to the surrounding city.

## Montmartre
The coach climbs to Montmartre, the hilltop neighbourhood that retains the intimate feel of a village within the city. The group walks the cobbled streets past the artists' square at Place du Tertre, where painters and portraitists display their work beneath the open sky as they have done for over a century. At the summit, the white-domed Sacré-Cœur Basilica commands a sweeping panorama across the Parisian rooftops extending to the horizon.

---
**Hotel:** Paris · **Transport:** AC coach from Paris airport, local city touring

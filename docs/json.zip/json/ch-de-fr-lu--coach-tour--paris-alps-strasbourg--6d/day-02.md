# Day 2 — Paris to Luxembourg City to Stuttgart

The group departs Paris and drives east to Luxembourg City, where the fortified old town perches dramatically above deep river gorges. The afternoon continues into Germany, ending the day in Stuttgart with a visit to one of the world's great automotive museums.

## Transfer Paris to Luxembourg City *(included)*
The coach departs Paris for Luxembourg City, a journey of approximately three and a half hours covering around 370 kilometres through the Champagne region and into the Grand Duchy. The tour leader provides commentary on the history of Luxembourg as the coach enters the city and the dramatic silhouette of the fortified plateau comes into view.

## Chemin de la Corniche
The group walks the Chemin de la Corniche, a pedestrian promenade that hugs the old city walls and has been called the most beautiful balcony in Europe. The path looks out over the deep Alzette valley and the lower town of Le Grund far below, with the ramparts of the old fortifications stretching away along the cliff edge in both directions. The view is particularly striking in clear weather when the forested gorge below is lit by full sunlight.

## Le Grund & Bock Casemates
The group descends to Le Grund, the picturesque lower town tucked within a river bend at the foot of the sandstone cliffs. Nearby, the Bock Casemates — a 23-kilometre network of underground tunnels carved into the rock over centuries of fortification — once sheltered thousands of civilians and soldiers. The sections accessible to visitors reveal the extraordinary scale of the tunnel system that made Luxembourg one of the most heavily fortified cities in Europe.

## Mercedes-Benz Museum or Porsche Museum, Stuttgart *(included)*
The group arrives in Stuttgart and visits either the Mercedes-Benz Museum or the Porsche Museum. The Mercedes-Benz Museum presents the full evolution of the automobile from its invention through to the present day, with rare vintage models displayed across nine floors within a striking double-helix building. The Porsche Museum offers a design-focused journey through decades of iconic sports cars, racing heritage, and German engineering innovation in a purpose-built modernist gallery.

---
**Hotel:** Stuttgart · **Transport:** AC coach Paris → Luxembourg City (370km, ~3.5hr), Luxembourg City → Stuttgart (320km, ~3hr)

# Day 6 — Zaanse Schans, Amsterdam and Departure

The final morning begins with a visit to the open-air windmill village of Zaanse Schans before the group heads into central Amsterdam for a farewell walk through the city's canal-lined streets and historic squares. The tour concludes with a transfer to Schiphol Airport.

## Zaanse Schans
The group visits Zaanse Schans, an open-air heritage village on the banks of the Zaan River. Working windmills, traditional green wooden houses, and artisan workshops recreate life in the Dutch Golden Age. The group watches demonstrations of clog-making, cheese production, and the operation of a working sawmill. Approximately one and a half hours are allocated for the visit.

## Jordaan Neighbourhood
The group explores the Jordaan, one of Amsterdam's most characterful neighbourhoods. Narrow streets and tree-lined canals are bordered by 17th-century merchants' houses, independent galleries, and cosy brown cafés. The walk provides a quieter contrast to the busier city centre.

## Dam Square & Museum Quarter
The group visits Dam Square, the city's central plaza, overlooked by the Royal Palace and the National Monument. Free time is available to walk through the surrounding streets or visit the nearby Museum Quarter, home to the Rijksmuseum and Van Gogh Museum.

## Optional Canal Boat Cruise *(optional)*
An optional canal boat cruise takes the group along Amsterdam's UNESCO-listed canal ring. The covered glass-top boat passes beneath low bridges and alongside leaning gabled houses, providing a perspective of the city that is impossible from street level.

## Transfer to Schiphol Airport *(included)*
The coach transfers the group to Amsterdam Schiphol Airport for departing flights. The journey takes approximately thirty minutes from the city centre.

---
**Hotel:** — · **Transport:** AC coach from Zaandam to Amsterdam (~20km), Amsterdam to Schiphol Airport

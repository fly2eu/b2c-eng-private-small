# Day 4 — Leisure Day in the Ardennes

A relaxed day in and around Bouillon gives the group time to enjoy the natural surroundings of the Belgian Ardennes. Activities range from visiting the hilltop castle to walking through the river valley, with an optional scenic coach drive through the forested hills.

## Bouillon Castle
The group visits Bouillon Castle, a medieval fortress perched on a rocky ridge above a bend in the Semois River. Dating back to the 8th century and once held by Godfrey of Bouillon, the castle offers panoramic views across the valley and the forested hills beyond. A guided tour explains its role in the Crusades and later European conflicts.

## Ardennes Nature Walk
The group follows a riverside path along the Semois, winding through dense woodland and past rocky outcrops. The gentle terrain is suitable for all fitness levels, and the walk takes approximately one to one and a half hours at a leisurely pace.

## Optional Kayaking on the Semois *(optional)*
An optional kayaking excursion is available on the Semois River. The calm, slow-moving water makes this suitable for beginners, and the route passes beneath overhanging trees and limestone cliffs. Life jackets and equipment are provided.

## Optional Ardennes Scenic Drive *(optional)*
An optional scenic coach drive loops through the surrounding Ardennes countryside, passing through small villages, open meadows, and dense beech and oak forests. The drive covers no more than 50 kilometres and includes short photo stops along the way.

---
**Hotel:** Bouillon · **Transport:** Local driving only (≤50km)

# Day 1 — Paris Arrival and City Sightseeing

The group arrives at the airport or station in Paris and boards the air-conditioned coach for an introductory tour of the French capital. The afternoon takes in the city's most iconic landmarks, from the hilltop heights of Montmartre to the iron silhouette of the Eiffel Tower.

## Paris Airport/Station Pickup *(included)*
The group meets at the designated arrival point — Charles de Gaulle Airport or Gare du Nord — and boards the air-conditioned coach. A tour leader welcomes the group and outlines the programme for the days ahead.

## Montmartre & Sacré-Cœur Basilica
A guided walking tour leads the group through the cobbled streets of Montmartre, the hilltop neighbourhood long associated with artists and writers. At the summit, the white-domed Sacré-Cœur Basilica commands a sweeping panorama across the Parisian rooftops. The group has approximately ninety minutes to explore the artists' square at Place du Tertre and take in the views.

## Arc de Triomphe & Champs-Élysées
The coach descends to the western end of the Champs-Élysées, where the Arc de Triomphe stands at the centre of the Place Charles de Gaulle roundabout. The group pauses for photographs of the arch and takes a leisurely stroll along a section of the tree-lined avenue, passing luxury boutiques and grand café terraces.

## Notre-Dame Cathedral
The group visits the Île de la Cité to see Notre-Dame Cathedral, a masterpiece of French Gothic architecture. The exterior façade, with its twin towers, rose windows, and carved stone figures, is viewed from the plaza. Approximately one hour is allocated for the visit and surrounding area.

## Louvre Exterior
The coach passes the Louvre Museum, and the group stops for a brief photo opportunity at the iconic glass pyramid in the courtyard. The palace façade and the Tuileries Garden beyond provide a scenic backdrop.

## Eiffel Tower Photo Stop
The day concludes at the Trocadéro esplanade, directly opposite the Eiffel Tower. The group has approximately one hour for photographs from the best vantage point in the city, with the tower framed by the fountains and gardens of the Palais de Chaillot.

## Optional Canal Cruise or Disneyland Paris *(optional)*
An optional Seine river canal cruise is available in the evening, gliding past illuminated landmarks along the waterfront. Alternatively, an optional excursion to Disneyland Paris can be arranged for those who prefer a theme-park experience.

---
**Hotel:** Paris · **Transport:** AC coach, local Paris driving (~30-50km)

# Day 2 — Paris to Brussels and the Ardennes

The group departs Paris early and crosses into Belgium for a half-day in Brussels. After exploring the capital's grand squares and European quarter, the coach continues south through the forested Ardennes to the riverside town of Bouillon.

## Transfer to Brussels *(included)*
The group boards the coach in Paris for the transfer to Brussels, a journey of approximately three and a half hours covering 310 kilometres through the flat farmland of northern France and into Belgium.

## Grand Place
The group visits the Grand Place, Brussels' central square and a UNESCO World Heritage Site. Ornate guild houses with gilded façades surround the cobblestone plaza on all sides. A guided tour explains the history of the square, from medieval marketplace to its destruction and reconstruction in the late 17th century. Approximately one hour is allocated.

## Manneken Pis
A short walk from the Grand Place brings the group to the Manneken Pis, the small bronze fountain statue that has become one of Brussels' best-known symbols. The group pauses here for photographs before continuing through the surrounding streets.

## Atomium & EU Parliament Quarter
The coach drives to the Atomium, the futuristic structure built for the 1958 World Expo, representing an iron crystal magnified 165 billion times. The group views the structure from the park below. The route continues past the European Parliament and Commission buildings in the EU quarter, with commentary from the tour leader on the institutions housed within.

## Transfer to Bouillon *(included)*
The coach departs Brussels and heads south through the Belgian Ardennes, a journey of approximately two and a half hours covering 185 kilometres. The landscape shifts from urban to densely forested hills as the group arrives in the riverside town of Bouillon.

---
**Hotel:** Bouillon · **Transport:** AC coach from Paris to Brussels (310km, 3.5hr), Brussels to Bouillon (185km, 2.5hr)

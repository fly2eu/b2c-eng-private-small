# Day 5 — Giethoorn Village and Onward to Amsterdam

The group leaves Belgium behind and crosses into the Netherlands, arriving at the car-free village of Giethoorn in the province of Overijssel. After a boat tour through its thatched-roof waterways, the coach continues west to Amsterdam for the final night of the tour.

## Transfer to Giethoorn *(included)*
The coach departs Bouillon for the journey north into the Netherlands, covering approximately 380 kilometres in four and a half hours. The route crosses the flat Dutch landscape of polders and canals before arriving in the village of Giethoorn.

## Giethoorn Boat Tour *(included)*
The group boards a traditional flat-bottomed boat — known as a whisper boat for its silent electric motor — and glides along the narrow canals that serve as Giethoorn's main streets. Thatched-roof farmhouses line the waterways, connected by over 170 wooden bridges. The tour lasts approximately one hour, with commentary on the village's history as a peat-digging settlement.

## Giethoorn Walking Tour
After disembarking, the group explores Giethoorn on foot, crossing arched wooden bridges and wandering along footpaths that run beside the canals. Free time is available to visit local craft shops and enjoy refreshments at a canalside café. Approximately one and a half hours are allocated for the walking tour.

## Transfer to Amsterdam/Zaandam *(included)*
The coach continues west from Giethoorn to the Amsterdam area, covering approximately 120 kilometres in one and a half hours. The group checks in at the hotel in Amsterdam or nearby Zaandam for the evening.

---
**Hotel:** Amsterdam/Zaandam · **Transport:** AC coach from Bouillon to Giethoorn (380km, 4.5hr), Giethoorn to Amsterdam/Zaandam (120km, 1.5hr)

# Day 3 — Bruges and Ghent: Medieval Flanders

A full-day excursion takes the group north to two of Flanders' finest medieval cities. The morning is spent among the canals and cobblestones of Bruges, followed by an afternoon exploring the grand churches and waterfront of Ghent, before returning to Bouillon for the evening.

## Transfer to Bruges *(included)*
The coach departs Bouillon early for the drive north to Bruges, covering approximately 255 kilometres in two and a half to three hours through the Belgian countryside.

## Bruges Old Town
The group explores Bruges on foot, beginning at the Markt square with its towering belfry and continuing along the willow-lined canals that thread through the old centre. The guided walking tour passes gabled merchant houses, the Church of Our Lady, and the Béguinage courtyard. Approximately two and a half hours are allocated for sightseeing, with free time for visiting the many chocolate and lace shops that line the pedestrianised streets.

## Transfer to Ghent *(included)*
The coach covers the short 50-kilometre journey from Bruges to Ghent in approximately one hour, passing through the flat Flemish polder landscape.

## Ghent Old Town
A guided tour takes the group through Ghent's atmospheric old centre, where three medieval towers — Saint Bavo's Cathedral, the Belfry, and Saint Nicholas' Church — dominate the skyline. The walk continues along the Graslei waterfront, once the city's bustling medieval harbour, now lined with step-gabled guild houses. Approximately one and a half hours are allocated for the visit.

## Return to Bouillon *(included)*
The coach returns south to Bouillon, a journey of approximately three hours covering 205 kilometres through the Ardennes forest.

---
**Hotel:** Bouillon · **Transport:** AC coach round trip: Bouillon → Bruges (255km, 2.5-3hr), Bruges → Ghent (50km, 1hr), Ghent → Bouillon (205km, 3hr)

# Day 6 — Cappadocia: Fairy Chimneys, Underground City & Pottery

The group spends a full day among Cappadocia's surreal volcanic landscape. An optional pre-dawn balloon flight gives way to rock fortresses, dramatic valleys, a centuries-old pottery town, and a descent into the multi-level tunnels of Kaymaklı Underground City.

## Hot Air Balloon Flight *(optional — USD 150–200)*
An optional pre-dawn balloon flight rises above the Cappadocian valleys as the first light touches the fairy chimneys and rock-cut churches below. Hundreds of balloons ascend simultaneously in the cool morning air, creating one of the most iconic scenes in all of Türkiye. The flight lasts approximately one hour.

## Uçhisar Fort
The group visits Uçhisar Fort, the highest point in Cappadocia and the dominant rock citadel of the region. The fort is honeycombed with rooms, passageways, and lookout points carved directly into the volcanic tuff, and its summit offers a panoramic sweep over the entire fairy chimney landscape.

## Love Valley
The group walks through Love Valley, where towering columns of volcanic tuff rise dramatically from the valley floor shaped by millions of years of wind and erosion. The guide explains the geological forces behind Cappadocia's extraordinary scenery as the path winds between the pale stone pillars.

## Avanos Pottery Workshop
The group visits a traditional pottery workshop in Avanos, a town famous for centuries of ceramic craft using the distinctive red clay of the Kızılırmak River. A master potter demonstrates the kick-wheel technique, and participants have the chance to shape their own piece of Cappadocian clay.

## Kaymaklı Underground City *(included ticket)*
The group descends into Kaymaklı Underground City, an ancient subterranean refuge extending eight levels below the Cappadocian plain. Narrow tunnels connect chambers that once served as living quarters, stables, kitchens, churches, and storage rooms for communities sheltering from invasion. Entrance is included.

## Evening Walk & Shopping *(optional)*
Free time in the evening allows the group to browse local shops for handwoven carpets, onyx stone carvings, Cappadocian ceramics, and traditional textiles. The illuminated cave hotels and fairy chimneys create a distinctive atmosphere for a night stroll.

---
**Hotel:** Cappadocia · **Transport:** Coach for regional touring · **Meals:** Breakfast, Lunch, Dinner

# Day 3 — Galata, Ortaköy Sunset & Transfer to Bursa

The morning takes the group across the Golden Horn into the Beyoğlu district for panoramic tower views and the lively energy of İstiklal Street. A sunset pause at the picturesque Ortaköy waterfront provides a fitting farewell to Istanbul before the coach heads south to Bursa, the first Ottoman capital.

## Galata Tower *(included ticket)*
The group ascends the medieval Galata Tower, a 67-metre stone landmark that has presided over the Golden Horn since 1348. The observation balcony at the summit delivers a 360-degree panorama of Istanbul's domes, minarets, and waterways stretching to the Sea of Marmara.

## Taksim Square & İstiklal Street
The group walks along İstiklal Street, Istanbul's vibrant pedestrian boulevard stretching 1.4 kilometres between Taksim Square and the historic Tünel funicular. Elegant late-Ottoman consulate buildings, independent bookshops, art galleries, and the nostalgic red heritage tram line the route.

## Ortaköy at Sunset
The group pauses at Ortaköy, a picturesque neighbourhood on the European shore of the Bosphorus. The ornate 19th-century Ortaköy Mosque frames the great suspension bridge behind it as the sun descends over the water, creating one of Istanbul's most photographed views.

## Transfer to Bursa
The coach departs Istanbul and heads south to Bursa, the first capital of the Ottoman Empire. The journey crosses the Sea of Marmara region and takes approximately two and a half hours on the motorway.

---
**Hotel:** Bursa · **Transport:** Coach Istanbul → Bursa (~2.5hr) · **Meals:** Breakfast, Lunch, Dinner

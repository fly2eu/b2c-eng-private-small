# Day 2 — Istanbul: Ancient Hippodrome to the Bosphorus

The group spends a full day in Sultanahmet, the historic district where Byzantine and Ottoman civilisations converged around a single extraordinary square. Included visits to Hagia Sophia and a Bosphorus cruise bookend a day of layered history, vivid markets, and shimmering waterways.

## Hippodrome
The group gathers at the ancient Hippodrome, once the thundering venue for chariot races at the very heart of Byzantine Constantinople. Three towering obelisks — Egyptian, Greek, and Roman — still stand along its central spine as silent witnesses to four centuries of imperial spectacle.

## Sultanahmet Square
The group walks through Sultanahmet Square, the historic centre where the Ottoman and Byzantine empires left their most enduring marks on the same patch of ground. The Blue Mosque and Hagia Sophia face each other across this open plaza, forming one of the most architecturally significant public spaces in the world.

## Hagia Sophia *(included ticket)*
The group enters Hagia Sophia, a masterpiece of world architecture revered across centuries as a place of worship and a symbol of human achievement. The vast dome appears to hover above the nave on a ring of forty arched windows, flooding the interior with shifting light. Ancient marble columns, golden mosaics, and sweeping calligraphy panels speak to the building's remarkable continuity as a sacred site across nearly 1,500 years.

## Egyptian Market (Spice Bazaar)
The group explores the Egyptian Market, one of Istanbul's oldest and most aromatic covered bazaars. Stalls brim with mountains of spices, dried fruits, Turkish delight, roasted nuts, and fragrant teas in a setting that has barely changed since the Ottoman era.

## Bosphorus Cruise *(included)*
The group boards a boat for an included cruise along the Bosphorus, the narrow strait that separates Europe from Asia. Ornate Ottoman waterfront mansions, rugged medieval fortresses, and the great suspension bridges of Istanbul pass on either side as the vessel glides between two continents.

---
**Hotel:** Istanbul · **Transport:** Coach for city transfers · **Meals:** Breakfast, Lunch, Dinner

# Day 5 — Across the Anatolian Plateau to Cappadocia

The coach crosses the wide Anatolian steppe, pausing at a cultural centre celebrating Turkic heritage and the ethereal white salt flats of Tuz Gölü before descending into the volcanic landscape of Cappadocia. The evening welcomes the group with an included traditional Turkish Night Show.

## Turkic World Science, Culture and Arts Centre
The group visits the Turkic World Science, Culture and Arts Centre in Eskişehir, a cultural institution dedicated to the shared heritage, languages, and arts of Turkic peoples across Central Asia and Anatolia. Exhibitions trace the history and contributions of Turkic civilisations from ancient migrations to the present day.

## Sazova Park & Fairy Tale Castle *(optional)*
An optional stop at Sazova Park lets the group explore a large family park centred on a storybook castle modelled on European fairytale architecture. The grounds include a science centre, planetarium, and zoo spread across landscaped gardens.

## Tuz Gölü (Salt Lake)
The group stops at Tuz Gölü, the second largest lake in Türkiye and one of the most striking natural spectacles in Anatolia. The vast white salt flats stretch unbroken to the horizon, creating a mirror-like surface that reflects the sky in brilliant tones. Thousands of flamingos gather along the shallow pink-tinged shallows during the warmer months.

## Turkish Night Show *(included)*
The group attends an included Turkish Night Show bringing together traditional Anatolian folk dances, live music, and whirling dervish ceremonies. The performances celebrate the diverse regional cultures of Türkiye through colourful costumes and rhythmic movement.

---
**Hotel:** Cappadocia · **Transport:** Coach Eskişehir → Tuz Gölü → Cappadocia · **Meals:** Breakfast, Lunch, Dinner

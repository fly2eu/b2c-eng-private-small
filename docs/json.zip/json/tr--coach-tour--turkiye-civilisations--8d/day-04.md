# Day 4 — Ottoman Bursa & Colourful Eskişehir

The group traces the early centuries of the Ottoman Empire through Bursa's Silk Road caravanserai, a monumental Grand Mosque, and a panoramic mountain cable car. The afternoon continues to Eskişehir, where restored Ottoman timber houses and the Porsuk River give the city a distinctive European-Ottoman character.

## Koza Han — Ottoman Silk Market *(included)*
The group visits Koza Han, a beautifully preserved Ottoman silk caravanserai built in 1491 by Sultan Bayezid II at the terminus of the ancient Silk Road. The arcaded two-storey courtyard, centred on a small mosque and reflecting pool, once hummed with the trade of Bursa's famous silk, and artisan merchants continue that tradition today.

## Ulu Mosque (Grand Mosque of Bursa) *(included)*
The group enters Ulu Mosque, an early Ottoman masterpiece built between 1396 and 1399 under Sultan Bayezid I. Twenty domes cover the vast prayer hall, and the interior walls carry calligraphy panels considered among the most significant in the Islamic world. A central ablution fountain beneath an open oculus brings natural light deep into the building.

## Bursa Panorama Museum *(included ticket)*
The group visits the Bursa Panorama Museum, which presents a sweeping 360-degree painted panorama of the Ottoman conquest of Bursa in 1326. The immersive installation places the viewer inside the historical scene, with detailed figures, battle formations, and the city's early landscape brought vividly to life.

## Uludağ Mountain Cable Car *(included)*
The group rides the Uludağ cable car, ascending over lush green valleys toward the peaks of northwestern Türkiye's highest mountain. The gondolas offer panoramic views across Bursa and the plains of the Marmara region stretching to the horizon.

## Odunpazarı Historical Houses
The group walks through Odunpazarı, Eskişehir's beautifully restored historic district of 16th-to-19th-century Ottoman timber houses. Vivid facades painted in deep reds, blues, and ochres line narrow cobblestone streets, creating one of the most charming heritage quarters in central Anatolia.

## Porsuk River City Tour
The group strolls along the Porsuk River waterfront, a tree-lined promenade of pedestrian bridges, gardens, and open-air seating areas that gives Eskişehir a relaxed, European atmosphere. The city's large student population brings a creative energy to the riverbanks.

## Gondola Ride on Porsuk River *(optional)*
An optional gondola ride along the Porsuk River offers a leisurely way to take in the city from the water. The flat-bottomed boats glide under illuminated bridges and past riverside gardens.

---
**Hotel:** Eskişehir · **Transport:** Coach Bursa → Eskişehir (~1.5hr) · **Meals:** Breakfast, Lunch, Dinner

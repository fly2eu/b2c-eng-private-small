# Day 1 — Arrival in Istanbul

The group arrives at Istanbul Airport and boards the brand-new air-conditioned coach for the transfer to the hotel. The evening is free to rest and settle in before a full programme of exploration begins the following morning.

## Airport Transfer to Istanbul Hotel *(included)*
The group meets at Istanbul Airport arrivals and is welcomed by the Turkish and Malayalam-speaking guide. The comfortable coach transfers everyone to the hotel in the historic centre, taking approximately one hour depending on traffic, with the guide on hand to assist with luggage and check-in.

---
**Hotel:** Istanbul · **Transport:** Coach from Istanbul Airport · **Meals:** Dinner

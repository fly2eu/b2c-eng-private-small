# Day 7 — Drive to the Capital: Ankara

The coach heads west toward Ankara, with a possible second stop at Tuz Gölü for any group members who missed it on Day 5. The afternoon explores Ankara's most significant monuments and a beautifully restored Ottoman quarter before an overnight in the capital.

## Tuz Gölü (Salt Lake) *(if not visited Day 5 — optional)*
Groups that did not stop at Tuz Gölü on Day 5 pause here on the drive toward Ankara. The vast salt flats and their mirror-like surface make a compelling interlude on the journey west across the plateau.

## Anıtkabir — Mausoleum of Atatürk
The group visits Anıtkabir, the monumental hilltop mausoleum of Mustafa Kemal Atatürk, founder of the Turkish Republic, completed in 1953. The ceremonial Lion Road lined with carved stone statues leads to the columned Hall of Honour, and the adjacent museum covers Atatürk's life and the Turkish War of Independence with extensive displays and artefacts.

## Presidential Palace Complex (Beştepe) — Exterior
The coach passes the Beştepe Presidential Palace Complex, the official residence and administrative centre of the President of Türkiye, opened in 2014. The grand exterior and manicured grounds are viewed from the road.

## Hamamönü Historic Quarter
The group walks through Hamamönü, a lovingly restored historic quarter where traditional Ottoman timber-frame houses line a gently sloping street. Small workshops, galleries, and cafés occupy the ground floors, and the smell of Turkish coffee drifts from open doorways.

## City Tour of Ankara
The coach provides a guided tour of Ankara, passing the broad boulevards and Republican-era civic buildings of the modern capital. The guide covers the city's transformation from a small Anatolian town into the administrative and political heart of the Turkish Republic.

---
**Hotel:** Ankara · **Transport:** Coach Cappadocia → Ankara (~3hr) · **Meals:** Breakfast, Lunch, Dinner

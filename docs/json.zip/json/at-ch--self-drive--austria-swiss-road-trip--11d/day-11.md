## Day 11 — Zürich

Your road trip through Austria and Switzerland reaches its conclusion. You return the rental car and head to the airport with memories of imperial cities, alpine peaks, and lakeside promenades.

**Zürich Airport Departure**
You return the rental car at Zürich Airport and proceed to your departure terminal. Allow at least two hours before your scheduled flight for check-in and security.

*You return the rental car at Zürich Airport and catch your departure flight.*

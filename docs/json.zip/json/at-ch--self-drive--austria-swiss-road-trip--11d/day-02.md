## Day 2 — Vienna

A full day exploring the Habsburg capital. You trace the grand Ringstrasse boulevard, step inside imperial palaces, and lose yourself in the Gothic intricacy of the city's cathedral.

**Ringstrasse Boulevard**
You begin along the Ringstrasse, the monumental circular boulevard that replaced the old city walls in the mid-nineteenth century. Grand institutions line both sides — the Parliament, the University, the Burgtheater — each competing for attention with elaborate neo-classical and neo-Gothic facades.

**Schönbrunn Palace**
You drive to the former summer residence of the Habsburgs, a UNESCO World Heritage Site with over fourteen hundred rooms. The palace gardens stretch in geometric precision toward the Gloriette hilltop pavilion, and the state rooms inside reveal the opulence of an empire that once spanned half of Europe.

**Vienna State Opera**
Back on the Ringstrasse, the Vienna State Opera stands as one of the world's premier opera houses. Its Renaissance Revival exterior and lavish interior have hosted premieres and performances since 1869. You admire the facade and the grand staircase within.

**St. Stephen's Cathedral**
The soaring south tower of Stephansdom dominates the Vienna skyline at one hundred and thirty-six metres. You step inside the Gothic nave to see the intricately carved pulpit and the colourful chevron-patterned roof tiles that have become the city's most recognisable symbol.

**Vienna Old Town Evening**
The evening is yours to wander the cobbled lanes of the Innere Stadt. Traditional coffeehouses beckon with marble-topped tables and pastry cabinets, and the pedestrianised Graben and Kohlmarkt streets come alive under soft lamplight.

*Vienna is compact enough to explore on foot today, with a short drive to Schönbrunn Palace and back.*

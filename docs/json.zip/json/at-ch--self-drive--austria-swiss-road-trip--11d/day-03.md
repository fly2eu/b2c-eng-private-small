## Day 3 — Vienna to Salzburg

Today's route winds westward through the Austrian countryside, skirting the shores of Lake Mondsee before delivering you to the baroque splendour of Salzburg.

**Vienna to Salzburg Drive**
You set out on the A1 motorway heading west, covering roughly two hundred and ninety-seven kilometres in about three hours. The road passes through the rolling hills of Lower Austria, and a detour to Lake Mondsee rewards you with turquoise waters framed by alpine peaks — a location famously used in The Sound of Music.

**Salzburg Old Town**
You arrive in Salzburg and explore its UNESCO-listed old town on the south bank of the Salzach River. Baroque churches, narrow medieval lanes, and elegant squares unfold beneath the imposing silhouette of the Hohensalzburg Fortress on the hilltop above.

*You drive 297 km from Vienna to Salzburg (approximately 3 hours) via the A1, with an optional stop at Lake Mondsee.*

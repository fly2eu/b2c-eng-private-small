## Day 5 — Salzburg to Interlaken

The longest drive of the trip takes you across the Austrian-Swiss border and deep into the Bernese Oberland. By evening you find yourself nestled between two lakes with the Alps towering overhead.

**Salzburg to Interlaken Drive**
You take the wheel for a roughly five-hundred-and-twenty-five-kilometre journey westward, crossing into Switzerland via Innsbruck or the Arlberg Pass. The drive takes around six and a half hours and traverses some of Europe's most dramatic alpine scenery, with snow-capped peaks flanking the road on both sides.

**Interlaken Evening Promenade**
You arrive in Interlaken, the resort town set on a narrow strip of land between Lake Thun and Lake Brienz. An evening stroll along the Höheweg promenade reveals the Jungfrau massif glowing pink in the last light of the day.

*You drive 525 km from Salzburg to Interlaken (approximately 6.5 hours). Purchase a Swiss motorway vignette at the border.*

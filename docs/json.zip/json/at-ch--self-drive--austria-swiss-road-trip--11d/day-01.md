## Day 1 — Vienna

Your road trip begins with an arrival at Vienna International Airport.

**Vienna Airport Arrival**
You arrive at Vienna International Airport and collect your rental vehicle. The drive into the city centre takes approximately thirty minutes along well-signed motorways, delivering you to your hotel in the heart of the First District.

*You collect your rental car at Vienna Airport and drive to your hotel in the city centre (approximately 30 minutes).*

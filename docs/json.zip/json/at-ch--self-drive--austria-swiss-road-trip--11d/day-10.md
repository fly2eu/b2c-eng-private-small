## Day 10 — Zürich

You choose between a spectacular panoramic train ride through the Alps or a relaxed final full day in Zürich. Either way, the Swiss landscape has one more grand gesture to offer.

**Bernina Express Day Trip (optional)**
You drive to Chur and board the Bernina Express, a panoramic train that traverses the Alps from Chur to Tirano in Italy. The UNESCO-listed route crosses sixty-five bridges and passes through fifty-five tunnels, reaching an elevation of over two thousand metres at the Bernina Pass before descending into the palm-lined streets of Tirano. You return the same way, arriving back in Zürich by evening.

**Zürich Leisure Day (optional)**
If you prefer a gentler pace, the day is yours to revisit favourite spots, explore galleries in the Zürich West district, or take a lake cruise. The Kunsthaus Zürich and the Rietberg Museum are both excellent options for art enthusiasts.

*Optional Bernina Express: drive to Chur (approximately 1.5 hours), then panoramic train to Tirano and back. Otherwise, a free day in Zürich.*

# Day 4 — Granada

The full day is dedicated to the Alhambra, the best-preserved medieval Muslim palace in the world. The evening is free to explore the Moroccan bazaar in the city centre.

## Alhambra *(included ticket)*
You spend the morning inside the Alhambra, Spain's most visited monument and the finest surviving example of medieval Islamic palatial architecture. Your guide takes you through the Nasrid Palaces, founded by Muhammad al-Ahmar, where Arabic inscriptions cover every wall and ceiling — prayers, Qur'anic verses, and poetry carved into plaster and tile. The Court of the Lions, the Hall of the Ambassadors, and the Generalife gardens each reveal a different dimension of Nasrid artistry.

## Optional Villa Lunch *(optional)*
An optional lunch is available at an open-air villa near the Alhambra. The setting provides views of the surrounding gardens and the Sierra Nevada peaks beyond.

## Moroccan Bazaar *(optional)*
The streets around the city centre host a lively Moroccan bazaar selling tea sets, lanterns, leather goods, and spices. You are free to browse and shop during the evening at leisure.

---
**Hotel:** Granada · **Transport:** Local transfers within Granada

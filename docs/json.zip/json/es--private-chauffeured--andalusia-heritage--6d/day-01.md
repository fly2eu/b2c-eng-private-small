# Day 1 — Málaga to Córdoba

Your vehicle meets you at Málaga Airport and proceeds north to Córdoba, arriving in time for lunch. The afternoon programme takes you through the historic centre of Córdoba, beginning at the Great Mosque.

## Málaga Airport Pickup
Your private vehicle awaits at Málaga Airport arrivals. The driver loads your luggage and departs for Córdoba, a journey of approximately one and a half hours through the Andalusian interior.

## Halal Restaurant Lunch *(optional)*
An optional halal lunch is available upon arrival in Córdoba. The restaurant offers traditional Andalusian dishes prepared according to halal standards.

## Great Mosque of Córdoba *(included ticket)*
Your guide leads you into the Great Mosque of Córdoba, one of Europe's most important examples of Islamic architecture. A forest of 856 columns supports double arches in alternating red and white stone, creating a mesmerising visual rhythm. The guided visit explains the mosque's Umayyad origins and its role as the spiritual centre of Al-Andalus.

## Bridge of Musa ibn Nusayr
You walk across the Roman Bridge spanning the Guadalquivir, historically linked to the Muslim commander Musa ibn Nusayr. The bridge provides unobstructed views of the mosque and the city skyline reflected in the water below.

## Calahorra Tower
At the southern end of the Roman Bridge stands the Calahorra Tower, an Islamic-era defensive fortification. A brief photo stop here captures the mosque and bridge together in one frame.

## Córdoba Old Quarters *(optional)*
Free time in the old quarters allows you to explore the narrow whitewashed streets at your own pace. Local shops sell leather goods, ceramics, and traditional Andalusian crafts.

---
**Hotel:** Córdoba · **Transport:** Private transfer from Málaga Airport to Córdoba (1.5hr)

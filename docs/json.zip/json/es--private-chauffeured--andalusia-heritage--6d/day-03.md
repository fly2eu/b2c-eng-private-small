# Day 3 — Seville to Granada

The morning showcases Seville's Mudéjar masterpieces before your vehicle departs for Granada. The evening brings you into the Albaicín quarter with its panoramic views of the Alhambra.

## Royal Alcázar of Seville *(included ticket)*
You visit the Royal Alcázar, a Christian palace constructed by Muslim craftsmen in the Mudéjar style. Intricate stucco work, carved wooden ceilings, and geometric tilework adorn every surface. The gardens beyond the palace walls feature fountains, pavilions, and clipped hedges arranged in formal patterns.

## Giralda Tower
The Giralda Tower rises above the Seville skyline as the former minaret of the city's main mosque, constructed in 1182 during the Almohad period. You pause here for photographs, observing the distinctive brickwork and geometric patterns that mark its Islamic origins.

## Albaicín Quarter
After arriving in Granada, you explore the Albaicín, the old Muslim quarter set on a hillside facing the Alhambra. Winding streets pass traditional carmen houses, hidden gardens, and viewpoints that frame the palace against the Sierra Nevada mountains.

## Grand Mosque of Granada
The Grand Mosque of Granada sits at the top of the Albaicín quarter, offering panoramic views of the Alhambra from its garden terrace. Completed in 2003, it is one of the first mosques built in Granada since the end of Muslim rule in 1492.

---
**Hotel:** Granada · **Transport:** Private transfer from Seville to Granada (3hr)

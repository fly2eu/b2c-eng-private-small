# Day 5 — Alpujarra Mountains

Your vehicle takes you into the Alpujarra Mountains, where the last Muslims of Al-Andalus preserved their faith for over 150 years after the fall of Granada. A village visit and mountain lunch complete the day.

## Alpujarra Mountains
Your vehicle climbs into the Alpujarra range on the southern slopes of the Sierra Nevada. These remote valleys sheltered the last Muslim communities of Al-Andalus, who continued to practise Islam for more than 150 years after the conquest of Granada in 1492. Terraced hillsides, flat-roofed whitewashed villages, and ancient irrigation channels all bear the imprint of their Moorish builders.

## Pampaneira Village
You stop in Pampaneira, one of three villages perched above the Poqueira gorge. Traditional flat-roofed houses, handwoven carpets, and a small chocolate factory are among the highlights. The architecture preserves Berber building techniques brought from North Africa centuries ago.

## Mountain Lunch *(included)*
Lunch is served at a restaurant with panoramic views over the Alpujarra valley. The setting looks out across terraced hillsides and deep gorges toward the distant Mediterranean coast.

## Alpujarra Shopping *(optional)*
Free time is available for browsing local shops selling handwoven rugs, ceramics, honey, and mountain herbs. The locally made carpets follow weaving traditions passed down through generations.

---
**Hotel:** Granada · **Transport:** Private vehicle round trip from Granada to Alpujarra Mountains

# Day 2 — Córdoba to Seville

Your vehicle departs for the ruins of Medinat Al-Zahra before continuing to Seville. The afternoon brings you to Plaza de España and the former Muslim quarters for shopping and exploration.

## Medinat Al-Zahra *(included ticket)*
Your vehicle takes you to Medinat Al-Zahra, the palatial city built by the Umayyad Caliph during the 10th century. At its peak, it stood as the crown jewel of Islamic civilisation on the Iberian Peninsula. Your guide walks you through the archaeological remains and the on-site museum, where carved stonework, ceramics, and architectural fragments tell the story of this lost city.

## Plaza de España
You arrive at Plaza de España, a sweeping semicircular plaza bordered by a canal and decorated with tiled alcoves representing each Spanish province. The architectural blend of Renaissance Revival and Moorish elements makes it one of Seville's most photographed landmarks.

## Seville Muslim Quarters *(optional)*
Free time in the former Muslim quarters of Seville reveals narrow streets lined with orange trees, tiled courtyards, and small artisan shops. You are free to explore and shop at your own pace.

---
**Hotel:** Seville · **Transport:** Private transfer from Córdoba to Seville (1.5hr)

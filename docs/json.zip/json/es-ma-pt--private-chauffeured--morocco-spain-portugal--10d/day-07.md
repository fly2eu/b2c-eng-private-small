## Day 7 — Seville → Córdoba → Granada

You travel east through the heart of Al-Andalus, visiting the Great Mosque of Córdoba before continuing to Granada's historic Albaicín quarter.

**Mosque of Córdoba** *(ticket included)*
You enter the Great Mosque of Córdoba, begun in the eighth century and expanded over three centuries into a vast hypostyle hall. Over 850 columns of jasper, onyx, and marble support distinctive red-and-white double arches. The mihrab, adorned with Byzantine gold mosaics, remains one of the most refined examples of Islamic sacred art in the western world.

**Muslim Quarters of Córdoba**
You walk through the narrow streets of the old Muslim quarters, where whitewashed houses with flower-filled patios preserve the character of medieval Córdoba. Wrought-iron grilles and trailing jasmine frame doorways that open onto hidden courtyards.

**Albaicín Quarter**
You explore the Albaicín, Granada's ancient Moorish hillside quarter and a UNESCO World Heritage Site. Winding cobblestone alleys, whitewashed houses, and traditional carmenes — walled gardens — preserve the urban fabric of the Nasrid period.

**Grand Mosque of Granada**
You visit the Grand Mosque of Granada, a modern mosque in the heart of the Albaicín opened in 2003. The courtyard garden with fountains and the terrace offer a distinctive perspective of the Alhambra across the Darro valley.

**Panoramic Alhambra Views**
From the Mirador de San Nicolás, you take in a panoramic view of the Alhambra palace complex set against the snow-capped Sierra Nevada. This is one of the most celebrated viewpoints in Spain.

*Your vehicle departs Seville for Córdoba (approximately 1.5 hours), then continues to Granada after the visits.*

## Day 3 — Rabat → Tangier

You explore the historical landmarks of Morocco's capital city before continuing north to the Mediterranean port of Tangier.

**Kasbah of the Udayas**
You enter the Kasbah of the Udayas through its grand Almohad gateway, one of the finest examples of twelfth-century Moorish monumental architecture. Inside, an Andalusian-style garden with fountains and citrus trees overlooks the mouth of the Bou Regreg River.

**Old Bazaar of Rabat**
You browse the old bazaar near the kasbah, where vendors sell traditional Moroccan carpets, leather goods, ceramics, and spices from narrow shopfronts lining the quiet lanes.

**Hassan Tower**
You stand before the Hassan Tower, the unfinished minaret of a mosque that was to be the largest in the western Islamic world. The forty-four-metre tower and its field of over two hundred stone columns mark the abandoned project of Sultan Yaqub al-Mansur from the late twelfth century.

**Mausoleum of Mohammed V**
You visit the Mausoleum of Mohammed V on the Hassan Tower esplanade. The white marble and green-tiled roof structure houses the royal tombs and showcases exceptional zellige, carved plaster, and cedarwood craftsmanship.

*Your vehicle transfers you from Rabat to Tangier (approximately 3 hours) after the morning sightseeing.*

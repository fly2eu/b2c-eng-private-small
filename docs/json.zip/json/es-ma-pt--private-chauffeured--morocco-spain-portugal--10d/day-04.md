## Day 4 — Tangier → Tarifa → Seville

You cross the Strait of Gibraltar by ferry, stop for lunch on the Spanish coast, and arrive in Seville for an afternoon tour of the city's most iconic landmarks.

**Strait of Gibraltar Ferry**
You board a ferry at Tangier port for the crossing to Tarifa on the southern tip of Spain. The voyage takes approximately one hour, with the coasts of Africa and Europe visible simultaneously at the narrowest point of the strait.

**Lunch Stop in Algeciras**
You stop in the port city of Algeciras for a midday break. The town offers a range of restaurants serving fresh seafood and Andalusian cuisine along its harbourfront.

**Plaza de España**
You visit the sweeping semicircular Plaza de España, built for the 1929 Exposition. Tiled alcoves represent each Spanish province, and ornamental bridges cross the canal at its base. The architecture blends Renaissance Revival with Moorish decorative motifs.

**Jardines de Murillo**
You walk through the Jardines de Murillo, a narrow public garden bordering the walls of the Alcázar. Palm trees, tiled benches, and a central fountain provide a shaded retreat in the heart of the old city.

**Muslim Quarters of Seville**
You explore the former Muslim quarters, where the medieval street plan survives in narrow lanes, whitewashed houses, and interior courtyards adorned with azulejo tiles and trailing bougainvillea.

**Giralda Tower** *(photo stop)*
You make a photo stop at the Giralda, the bell tower of Seville Cathedral that was originally the Almohad mosque's minaret. Its lower section retains the twelfth-century brickwork and sebka lattice patterns characteristic of North African architecture.

**Torre del Oro** *(photo stop)*
You view the Torre del Oro from the riverside, a thirteenth-century Almohad watchtower on the banks of the Guadalquivir. The twelve-sided tower once anchored a chain stretched across the river to control maritime access to the city.

*Your vehicle brings you to Tangier port for the ferry. On arrival in Tarifa, a private transfer takes you via Algeciras to Seville.*

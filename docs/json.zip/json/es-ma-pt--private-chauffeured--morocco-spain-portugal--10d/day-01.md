## Day 1 — Casablanca → Marrakesh

You arrive at Casablanca Airport and pause at the city's iconic waterfront mosque before your private transfer brings you south to Marrakesh.

**Casablanca Airport Pick-Up**
Your driver meets you at Mohammed V International Airport arrivals and assists with your luggage. The transfer to the city centre is brief.

**Mosque of Hassan II** *(exterior)*
You view the exterior of the Mosque of Hassan II from its oceanfront esplanade. The mosque's minaret rises 210 metres above the Atlantic, making it the tallest religious structure on the continent. The building sits partially over the sea on a reclaimed platform, with waves visible through a glass floor section in the prayer hall.

*A private transfer brings you from Casablanca Airport through the city for a brief mosque stop, then continues to Marrakesh (approximately 3 hours).*

## Day 8 — Granada → Madrid

The morning is devoted to the Alhambra and Generalife Gardens, the summit of Nasrid architecture, before your vehicle carries you north to Madrid.

**Alhambra Palaces and Generalife Gardens** *(ticket included)*
You enter the Alhambra, the thirteenth- and fourteenth-century fortress-palace of the Nasrid dynasty. The Nasrid Palaces reveal room after room of intricate stucco carving, muqarnas ceilings, and Arabic inscriptions drawn from poetry and Quranic verses. Afterwards, you walk through the Generalife Gardens — the summer retreat of the sultans — where water channels, cypress hedges, and terraced flower beds cascade down the hillside.

*A private transfer brings you from Granada to Madrid (approximately 4.5 hours) after the Alhambra visit.*

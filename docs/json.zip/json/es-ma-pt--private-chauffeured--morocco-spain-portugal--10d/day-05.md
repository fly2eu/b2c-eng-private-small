## Day 5 — Seville → Sintra → Lisbon

You travel west from Seville into Portugal, visiting the colourful hilltop Pena Palace in Sintra before settling into Lisbon for the evening.

**Transfer to Portugal**
Your vehicle departs Seville in the morning and crosses into Portugal, heading toward the Atlantic coast. The drive to the Sintra-Lisbon area takes approximately five hours.

**Pena Palace**
You visit the Pena Palace, a nineteenth-century Romanticist castle perched atop a hill in the Sintra mountains. Its vibrantly painted terraces, Moorish arches, Manueline carvings, and Islamic-style domes create one of the most distinctive silhouettes in European architecture. The surrounding park descends through dense forest planted with exotic species from around the world.

*A private transfer brings you from Seville to Sintra, then continues to your Lisbon hotel.*

## Day 6 — Lisbon → Seville

A full day exploring the Portuguese capital's riverfront monuments, historic squares, and grand monastery before returning east to Seville.

**Belém Tower**
You visit the Belém Tower, a UNESCO-listed sixteenth-century fortification standing at the edge of the Tagus River. Built in the Manueline style, the tower features intricately carved limestone balconies, watchtowers, and a terrace overlooking the estuary from which Portuguese explorers set sail.

**Rossio Square**
You stroll through Rossio Square, the historic heart of Lisbon since the Middle Ages. The distinctive wave-patterned Portuguese pavement, Baroque fountains, and the columned facade of the National Theatre frame one of the city's most animated gathering places.

**Jerónimos Monastery**
You enter the Jerónimos Monastery, a UNESCO World Heritage masterpiece of Manueline architecture in the Belém district. The cloisters feature elaborately carved limestone arches with maritime motifs, and the church interior soars beneath fan-vaulted ceilings supported by slender octagonal pillars.

**Monument to the Discoveries**
You view the Monument to the Discoveries on the Belém waterfront, a fifty-two-metre stone sculpture shaped like a ship's prow. Thirty-three figures from Portugal's Age of Exploration line both sides, led by Henry the Navigator. A compass rose map inlaid in the pavement marks the routes of Portuguese maritime expeditions.

**Shopping in Lisbon** *(optional)*
You have free time for shopping in central Lisbon. The Baixa and Chiado districts offer a mix of international brands and traditional Portuguese shops selling ceramics, leather goods, and cork products.

**Central Mosque of Lisbon**
You visit the Central Mosque of Lisbon, the largest mosque in Portugal. The modern building serves the city's Muslim community and features a simple, dignified prayer hall and cultural centre.

*Your vehicle and guide are at your disposal in Lisbon, then transfer you back to Seville in the late afternoon (approximately 5 hours).*

## Day 2 — Marrakesh → Rabat

You discover the mosques, palaces, and souks of Marrakesh before your vehicle carries you north to Morocco's administrative capital.

**Koutoubia Mosque**
You begin at the Koutoubia Mosque, the largest mosque in Marrakesh. Its seventy-seven-metre Almohad minaret, dating to the twelfth century, set the proportional template later copied by the Giralda in Seville and the Hassan Tower in Rabat.

**Bahia Palace**
You enter the Bahia Palace, built in the late nineteenth century for the Grand Vizier. Rooms and courtyards are adorned with painted cedarwood ceilings, zellige mosaic floors, and carved stucco walls. The gardens are planted with jasmine, orange, and banana trees.

**Spice Pharmacy in the Old Medina**
You visit a traditional spice pharmacy in the old medina, where an herbalist explains the uses of argan oil, saffron, cumin, and dozens of dried herbs and remedies displayed in woven baskets and glass jars.

**Jemaa el-Fnaa** *(free time)*
You have free time at Jemaa el-Fnaa, Marrakesh's vast central square. By day, orange juice vendors and henna artists line the perimeter; by evening, food stalls and musicians transform it into a spectacle recognised by UNESCO as a masterpiece of intangible heritage.

*Your vehicle departs Marrakesh after the city tour and transfers you to Rabat (approximately 4 hours).*

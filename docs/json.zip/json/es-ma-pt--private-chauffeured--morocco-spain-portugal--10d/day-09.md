## Day 9 — Madrid & Toledo

You make a day trip to the ancient city of Toledo and return to Madrid for stadium visits and factory outlet shopping.

**Toledo Panoramic Viewpoint**
You stop at the Mirador del Valle for a panoramic view of Toledo, the ancient walled city that rises from a bend in the Tagus River. The skyline reveals the Alcázar, the cathedral, and centuries of layered architecture.

**Toledo City Centre**
You explore the narrow medieval streets of Toledo's city centre, where Christian, Muslim, and Jewish heritage coexist within the old walls. The city was a major centre of learning and translation during the Islamic period.

**Shopping in Toledo** *(optional)*
You have free time to browse Toledo's renowned Damascene workshops, where artisans produce steel inlaid with gold and silver using techniques passed down from the Moorish period. Swords, jewellery, and decorative plates are among the specialities.

**Santiago Bernabéu Stadium**
You stop at the Santiago Bernabéu, the home ground of Real Madrid and one of Europe's most iconic football stadiums. The recently renovated arena seats over 80,000 spectators beneath a retractable roof.

**Las Rozas Village Factory Outlet**
You visit Las Rozas Village, a designer outlet centre on the outskirts of Madrid. Over one hundred boutiques offer discounted international fashion, accessories, and lifestyle brands in an open-air village setting.

*Your vehicle takes you to Toledo in the morning (approximately 1 hour from Madrid), then returns to Madrid for the afternoon visits.*

## Day 4 — Salzburg

A full day in Mozart's birthplace. You stroll through manicured gardens, visit the composer's childhood home, and ride the funicular up to the medieval fortress that crowns the city.

**Mirabell Gardens**
You begin on the north bank at Mirabell Gardens, a formal baroque garden dating to the early seventeenth century. Geometric flowerbeds, marble statues, and the ornate Pegasus fountain frame a postcard view of the fortress and the old town skyline beyond.

**Mozart's Birthplace**
You cross to Getreidegasse, the old town's main shopping lane, and enter the yellow townhouse where Wolfgang Amadeus Mozart was born in 1756. The museum displays original instruments, family portraits, and letters that trace the prodigy's early years in Salzburg.

**Hohensalzburg Fortress**
You ride the Festungsbahn funicular up to the Hohensalzburg Fortress, one of the largest and best-preserved medieval castles in Europe. The state rooms, the marionette museum, and the panoramic terrace overlooking the city and the surrounding Alps all reward the ascent.

**Sound of Music Countryside (optional)**
An optional afternoon drive takes you through the meadows and lake districts south of Salzburg that served as filming locations for The Sound of Music. Your driver navigates rolling green hills, church spires, and crystal-clear lakes on this one of Austria's most photogenic routes.

**Salzach Riverfront Evening**
As the sun dips behind the mountains, you return to the riverfront where the fortress and the domes of the old town glow in the fading light. The embankment promenade offers a quiet end to a full day.

*Salzburg is compact and best explored on foot today. Your driver is available for the optional countryside loop (roughly 50 km).*

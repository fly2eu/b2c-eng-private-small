## Day 7 — Lauterbrunnen Valley & Interlaken

Your vehicle brings you into the valley of seventy-two waterfalls before returning to Interlaken for a panoramic ascent above the town. The Bernese Oberland reveals yet another side of its staggering beauty.

**Staubbach Falls**
Your driver brings you into the Lauterbrunnen Valley where a ribbon of water plunges nearly three hundred metres from the cliff edge above at Staubbach Falls. The mist catches the morning light and the sheer rock walls on either side give the valley a cathedral-like scale.

**Trümmelbach Falls**
A short transfer further into the valley brings you to the Trümmelbach Falls, a series of ten glacier-fed waterfalls hidden inside the mountain. You ride a tunnel lift and walk through illuminated caverns where twenty thousand litres of water per second thunder through spiralling rock formations.

**Harder Kulm**
Back in Interlaken, you ride the funicular up to Harder Kulm at one thousand three hundred and twenty-two metres. The viewing platform extends out over the cliff edge with Lake Thun on one side, Lake Brienz on the other, and the Eiger, Mönch, and Jungfrau directly ahead.

**Paragliding or Lake Cruise (optional)**
For the adventurous, a tandem paraglide from Harder Kulm offers a bird's-eye descent over the town. Alternatively, a leisurely cruise on Lake Thun or Lake Brienz provides a gentler perspective on the surrounding mountains from the water.

*Your driver brings you to Lauterbrunnen (approximately 15 km from Interlaken) and back.*

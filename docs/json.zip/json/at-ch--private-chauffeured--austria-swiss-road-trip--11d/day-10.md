## Day 10 — Zürich

You choose between a spectacular panoramic train ride through the Alps or a relaxed final full day in Zürich. Either way, the Swiss landscape has one more grand gesture to offer.

**Bernina Express Day Trip (optional)**
Your driver takes you to Chur where you board the Bernina Express, a panoramic train that traverses the Alps from Chur to Tirano in Italy. The UNESCO-listed route crosses sixty-five bridges and passes through fifty-five tunnels, reaching an elevation of over two thousand metres at the Bernina Pass before descending into the palm-lined streets of Tirano. You return the same way and your driver collects you at Chur by evening.

**Zürich Leisure Day (optional)**
If you prefer a gentler pace, the day is yours to revisit favourite spots, explore galleries in the Zürich West district, or take a lake cruise. The Kunsthaus Zürich and the Rietberg Museum are both excellent options for art enthusiasts.

*Optional Bernina Express: your driver takes you to Chur (approximately 1.5 hours), then you take the panoramic train to Tirano and back. Otherwise, a free day in Zürich.*

## Day 1 — Vienna

Your journey begins with an arrival at Vienna International Airport.

**Vienna Airport Transfer**
A private transfer brings you from Vienna International Airport to your hotel in the First District. Your driver navigates the thirty-minute journey while you take in your first views of the Austrian capital through the window.

*A private transfer brings you from Vienna Airport to your hotel in the city centre (approximately 30 minutes).*

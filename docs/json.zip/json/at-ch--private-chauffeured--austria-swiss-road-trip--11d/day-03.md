## Day 3 — Vienna to Salzburg

Your vehicle departs Vienna and heads westward through the Austrian countryside, skirting the shores of Lake Mondsee before delivering you to the baroque splendour of Salzburg.

**Vienna to Salzburg Transfer**
A private transfer takes you roughly two hundred and ninety-seven kilometres west along the A1 motorway, a journey of about three hours. Your driver may stop at Lake Mondsee, where turquoise waters framed by alpine peaks create a scene famously used in The Sound of Music.

**Salzburg Old Town**
You arrive in Salzburg and explore its UNESCO-listed old town on the south bank of the Salzach River. Baroque churches, narrow medieval lanes, and elegant squares unfold beneath the imposing silhouette of the Hohensalzburg Fortress on the hilltop above.

*A private transfer brings you 297 km from Vienna to Salzburg (approximately 3 hours) via the A1, with an optional stop at Lake Mondsee.*

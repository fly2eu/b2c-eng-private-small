# Day 6 — Luxembourg City → Moret-sur-Loing

A morning in Luxembourg City uncovers one of Europe's most dramatically situated capitals: cliff-edge promenades, a fortified old town rising above a wooded gorge, and tunnels carved deep into the sandstone beneath the city walls. The afternoon drive south into France ends in Moret-sur-Loing, a medieval walled town on the banks of the Loing that provided Alfred Sisley with a lifetime of Impressionist inspiration.

## Chemin de la Corniche
The group walks the Chemin de la Corniche, a raised promenade that follows the top of the old city walls above the deep valley of the Alzette. Regarded as Europe's most beautiful balcony, the path offers sweeping panoramic views over the Grund quarter far below and the wooded cliffs rising on the opposite bank. The medieval ramparts, church spires, and green valley visible from this vantage point make it one of the most compelling urban viewpoints in all of Europe.

## The Grund
The group descends to the Grund, Luxembourg City's lower town, which occupies the floor of the Alzette valley directly beneath the plateau on which the upper city stands. Narrow lanes, old stone mill buildings, and the Neumünster Abbey complex give the neighbourhood a tranquil, unhurried character that contrasts sharply with the formal streets above. It is one of the most picturesque corners of any European capital.

## Bock Casemates
The group visits the Bock Casemates, a 23-kilometre network of tunnels and galleries cut into the sandstone cliffs over several centuries of fortification. These passages once sheltered troops, horses, bakeries, and slaughterhouses within the rock itself, and they form part of the UNESCO World Heritage inscription that covers the old town and its fortifications. The group walks through a section of the tunnels, with openings in the cliff face providing dramatic views across the valley.

## Moret-sur-Loing Old Town
The coach arrives in Moret-sur-Loing, a small medieval town still enclosed within its original stone walls on the banks of the Loing River. The 12th-century stone bridge, the riverside mills, and the fortified town gates were the primary subjects of Impressionist painter Alfred Sisley, who settled here in 1880 and painted the town and its surroundings until his death in 1899. A short evening stroll through the historic centre reveals why this quiet town captivated him for so long.

---
**Hotel:** Moret-sur-Loing · **Transport:** Luxury coach Luxembourg City → Moret-sur-Loing (~350km, ~4hr)

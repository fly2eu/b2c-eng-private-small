# Day 1 — Arrival in Paris

The group arrives in Paris and begins exploring the French capital's most celebrated landmarks. The Eiffel Tower, the Seine riverside, and the hilltop neighbourhood of Montmartre set the tone for a seven-day journey through five countries.

## Eiffel Tower
The group visits the Eiffel Tower, the iron lattice structure that has stood as the defining symbol of Paris since 1889. At 324 metres it remains the city's tallest building, and the esplanade at its base provides the group with unobstructed views and ample opportunity for photographs from every angle.

## Seine River Quays
The group walks along the quays of the Seine, where the bouquinistes — Paris's iconic open-air dealers in second-hand books and vintage prints — line the riverside for several kilometres in their distinctive green wooden stalls. The walkway forms part of the city's UNESCO World Heritage zone and offers a gentle, unhurried introduction to Parisian life.

## Montmartre
The group visits Montmartre, the hilltop quarter north of the city that has retained a distinct village character despite sitting at the heart of one of the world's great capitals. Narrow cobbled streets, the artists' square at Place du Tertre, and sweeping views over the Paris rooftops reward a stroll through the neighbourhood. The white dome of the Sacré-Cœur Basilica at the summit provides a dramatic backdrop for the end of the day.

---
**Hotel:** Paris · **Transport:** Arrival transfer; luxury coach for city touring

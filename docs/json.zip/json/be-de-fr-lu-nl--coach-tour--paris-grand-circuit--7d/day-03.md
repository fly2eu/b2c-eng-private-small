# Day 3 — Bruges to Amsterdam

The coach heads north into the Netherlands for an afternoon and evening in Amsterdam, one of Europe's most architecturally distinctive capitals. The day reveals the extraordinary feats of engineering and urban planning that shaped the city during the Dutch Golden Age.

## Amsterdam Old Centre & Canal Ring
The group explores the Grachtengordel, Amsterdam's 17th-century concentric ring of canals and a UNESCO World Heritage Site. The characteristic canal houses were built to lean forward and tilt to the side, a deliberate design feature that allowed goods to be hoisted through upper-floor openings without striking the façades. Beneath the city, millions of wooden piles support the buildings on the marshy subsoil: the Royal Palace on Dam Square alone rests on 13,659 of them.

## Royal Palace on Dam Square
The group visits Dam Square and takes in the Royal Palace, constructed in the mid-17th century as Amsterdam's City Hall and one of the supreme examples of Dutch Classicist architecture. The building stands at the historical centre of the city, and the open square around it gives the group a clear view of the façade and its proportions.

## Prinsengracht & Evening City Walk
The group walks along the Prinsengracht canal, where elm trees line the towpaths and houseboats are moored along the water's edge in a scene characteristic of Amsterdam at its most relaxed. The evening continues through the main squares and shopping streets, with free time for the group to explore the city's neighbourhoods before overnight.

---
**Hotel:** Amsterdam · **Transport:** Luxury coach Bruges → Amsterdam (~250km, ~3hr)

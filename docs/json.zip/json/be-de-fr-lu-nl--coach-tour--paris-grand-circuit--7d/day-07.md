# Day 7 — Moret-sur-Loing → Paris (Departure)

The final morning is spent in Moret-sur-Loing, exploring the medieval details that made this small riverside town one of the most painted places in 19th-century France. The short drive back to Paris completes the grand circuit through five countries, bringing the group full circle to where the journey began.

## Porte de Bourgogne
The group visits the Porte de Bourgogne, one of the medieval gateways that has stood at the entrance to Moret-sur-Loing since the 12th century. The stone arch with its corbelled towers marks the original boundary of the fortified town and provides a framing view back along the main street toward the church. It is one of the best-preserved medieval town gates in the Île-de-France region.

## Church of Notre-Dame, Moret-sur-Loing
The group visits the Church of Notre-Dame, a medieval parish church with a notable organ loft donated by King Louis XIV — a mark of royal favour that reflects the town's historical importance as a fortified crossing on the Loing. Alfred Sisley painted the church repeatedly across different seasons and light conditions during his years living here, and the building retains much of the character that drew him back to it time and again.

## Loing River Water-Mills
The group walks along the Loing riverbank past the historic water-mills that have operated on this stretch of the river for centuries. The scene — stone mills, weirs breaking the flow of the river, medieval bridge in the middle distance, and willows leaning over the water — is virtually unchanged from the Impressionist canvases that brought Moret-sur-Loing to wider attention. It provides a quiet and memorable final image for the tour.

## Transfer to Paris
The coach completes the seven-day grand circuit with a drive of approximately 80 kilometres back to Paris. The group is dropped at the agreed central Paris point or airport, marking the conclusion of a journey that has taken them through France, Belgium, the Netherlands, Germany, and Luxembourg.

---
**Hotel:** — (departure day) · **Transport:** Luxury coach Moret-sur-Loing → Paris (~80km, ~1.5hr)

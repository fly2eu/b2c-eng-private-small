# Day 4 — Amsterdam → Zaanse Schans → Giethoorn → Cologne

The group leaves Amsterdam for a day of Dutch countryside before crossing into Germany. Windmills and craft workshops at Zaanse Schans give way to a boat journey through the waterways of Giethoorn, and the day ends in Cologne with the first sight of one of the world's most famous Gothic cathedrals.

## Zaanse Schans
The group visits Zaanse Schans, a living open-air museum of working 18th-century windmills alongside the Zaan River. The site was the world's first industrial area, where hundreds of mills processed timber, spices, paint, and dyes for trade across Europe and beyond. Craft workshops within the village demonstrate traditional clog-making and Dutch cheese production, and the green wooden mill silhouettes reflected in the river are among the most recognisable images in the country.

## Giethoorn — Village by Boat *(included)*
The group boards flat-bottomed boats to explore Giethoorn, a village with no roads in its historic core. The only ways to move through the settlement are by water or on foot across the 176 wooden bridges that connect the thatched-roof farmhouses built on peat islands. The group glides through the waterways in near silence, passing gardens that reach down to the canal and open meadows beyond.

## Cologne Cathedral (Kölner Dom)
The coach crosses into Germany and arrives in Cologne for an evening encounter with the Kölner Dom, Germany's most visited monument and a UNESCO World Heritage Site. Construction began in 1248 and continued for 632 years before the twin spires reached their full height of 157 metres in 1880, making the cathedral briefly the tallest structure on earth. The building sustained 14 direct aerial bomb hits during the Second World War and survived them all.

---
**Hotel:** Cologne · **Transport:** Luxury coach Amsterdam → Zaanse Schans → Giethoorn → Cologne (~300km total)

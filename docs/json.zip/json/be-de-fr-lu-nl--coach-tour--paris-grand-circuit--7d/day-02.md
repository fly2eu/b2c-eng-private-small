# Day 2 — Paris → Brussels → Bruges

The coach departs Paris and heads north into Belgium for a mid-morning stop at the heart of Brussels before continuing to Bruges. A focused tour of the Belgian capital's two most famous landmarks is followed by a leisurely evening in the perfectly preserved medieval streets of Bruges.

## Grand Place, Brussels
The group visits the Grand Place, Brussels' central square and a UNESCO World Heritage Site that ranks among the finest civic spaces in Europe. The surrounding guild houses are decorated with exceptional gilded ornament — some façades retain their original 24-karat gold leaf — while the Gothic Town Hall provides the square's dominant 96-metre spire. The group walks the cobblestoned perimeter and has time to appreciate the architecture at close range.

## Manneken Pis
The group stops at the Manneken Pis, the 61-centimetre bronze fountain figure that has stood as an unofficial emblem of Brussels since 1619. The statue has accumulated an official wardrobe of over 1,000 themed costumes donated by organisations and cities worldwide, and it is frequently found dressed for the occasion. The stop provides a moment of levity before the onward drive to Bruges.

## Bruges Old Town & Canal Walk
The coach continues to Bruges, a UNESCO World Heritage city known as the Venice of the North for its interconnected network of medieval canals and its extraordinarily preserved Gothic skyline. The historic centre conveys the atmosphere of a city that the 19th century left largely untouched, with step-gabled stone houses and slender church towers rising above tree-lined waterways. An evening canal walk gives the group a first unhurried taste of one of Belgium's most beautiful cities.

---
**Hotel:** Bruges · **Transport:** Luxury coach Paris → Brussels (~320km, ~3.5hr), Brussels → Bruges (~100km, ~1hr)

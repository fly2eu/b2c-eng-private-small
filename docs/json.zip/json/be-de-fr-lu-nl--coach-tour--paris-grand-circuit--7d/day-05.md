# Day 5 — Cologne → Dinant → Luxembourg

The coach heads south from Germany back into Belgium for a riverside stop in Dinant, a town of remarkable cliff-top drama and historical curiosity, before continuing into Luxembourg for the overnight. An optional interior visit to Cologne Cathedral begins the day for those who wish to experience the building from inside.

## Cologne Cathedral Interior *(optional)*
An optional morning visit to the interior of Cologne Cathedral allows the group to stand inside one of the grandest Gothic spaces in Europe. The nave rises 43 metres to the vaulted ceiling, and light filters through medieval stained glass that has survived centuries of European history. The Shrine of the Three Kings behind the high altar is one of the finest examples of medieval goldsmithing on the continent.

## Collegiate Church of Notre-Dame, Dinant
The group stops in Dinant for a riverside visit to the Collegiate Church of Notre-Dame, whose unusual pear-shaped lead-covered bell tower has been a landmark on the Meuse since the 16th century. The church was constructed directly against the cliff face below the citadel, wedged between rock and river in a setting unlike almost any other church in Belgium.

## Citadel of Dinant
The group takes the cable car up to the Citadel of Dinant, a fortress perched 100 metres above the Meuse on sheer limestone cliffs. The views from the top extend along the river valley and into the forested Ardennes hills. Dinant is also celebrated as the birthplace of Adolphe Sax, the 19th-century Belgian inventor who gave the saxophone its name.

## Drive to Luxembourg Outskirts
The coach continues south through the Ardennes and into the Grand Duchy of Luxembourg. The group checks into a hotel on the outskirts of Luxembourg City, ready for a morning of exploration in one of Europe's smallest but most dramatically situated capitals.

---
**Hotel:** Luxembourg (outskirts) · **Transport:** Luxury coach Cologne → Dinant (~180km, ~2hr), Dinant → Luxembourg (~100km, ~1.5hr)

# Day 2 — Zurich, Lucerne & Bern

The morning begins with a guided walking tour through Zurich's old town, tracing centuries of merchant history along its winding lanes. Your vehicle then carries you south-west to Lucerne, where a lakeside cityscape of covered bridges and baroque churches awaits. After exploring Lucerne's highlights on foot with a local guide, a comfortable afternoon drive brings you to the Swiss capital, Bern, where you settle into your hotel for the evening.

## Zurich Old Town Guided Walking Tour
A local guide leads you through the atmospheric streets of Zurich's Altstadt, recounting tales of the medieval guilds and the Reformation. You pass Romanesque and Gothic church facades, hidden courtyards, and the Lindenhof terrace with its panoramic view over the rooftops and river below.

## Chapel Bridge (Kapellbrucke)
Dating to 1333, this covered wooden footbridge spans the Reuss River diagonally and ranks among Europe's oldest surviving timber bridges. Its interior gable paintings illustrate key moments from Lucerne's history, while the octagonal Water Tower at its bend once served as a prison, treasury, and archive.

## Lion Monument (Lowendenkmal)
Carved directly into a sandstone cliff face in 1821, this ten-metre sculpture depicts a dying lion and commemorates the Swiss Guards who fell during the French Revolution. Mark Twain once described it as the most mournful and moving piece of stone in the world. The small park surrounding it provides a quiet moment of reflection.

## Jesuit Church (Jesuitenkirche)
Completed in 1677, this is Switzerland's first large baroque church. Its twin onion-domed towers rise above the Reuss riverbank, and the interior features ornate stucco work, ceiling frescoes, and a pink marble high altar that together create a striking contrast with the city's otherwise medieval architecture.

## Lucerne Old Town
Compact and walkable, the old town occupies both banks of the Reuss River and is characterised by painted facades, cobbled squares, and covered bridges. Guided commentary brings to life the frescoes adorning the buildings and the centuries of trade that shaped the city's identity at the crossroads of Alpine passes.

## Transfer to Bern
Your driver navigates the scenic route from Lucerne to Bern, passing rolling green hills and farmland. The journey takes approximately ninety minutes, giving you time to relax and enjoy the Swiss countryside from the comfort of your private vehicle.

---
**Hotel:** Bern · **Transport:** Private vehicle Zurich → Lucerne → Bern · **Meals:** Breakfast

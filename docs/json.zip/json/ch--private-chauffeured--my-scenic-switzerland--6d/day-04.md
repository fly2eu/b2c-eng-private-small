# Day 4 — Schilthorn Summit & the Lauterbrunnen Valley

Today delivers some of Switzerland's most dramatic scenery. A cable car ascends to the Schilthorn summit at nearly three thousand metres, where the revolving Piz Gloria restaurant offers an unbroken panorama of the Eiger, Monch, and Jungfrau. Back at valley level, the car-free village of Murren perches on a clifftop shelf, and the Lauterbrunnen valley funnels dozens of waterfalls down sheer rock walls. The day concludes in Interlaken, positioned on a narrow strip of land between two glittering Alpine lakes.

## Schilthorn / Piz Gloria
A series of cable cars lifts you to 2,970 metres, where a revolving observation platform reveals a full 360-degree sweep of over two hundred Alpine peaks. The summit gained fame as a Bond film location, and the Piz Gloria restaurant rotates a complete turn every forty-five minutes while you take in views stretching from the Black Forest to Mont Blanc.

## Murren Village
Reachable only by cable car or mountain railway, Murren sits on a narrow terrace 1,650 metres above the valley floor. No cars are permitted, leaving only the sound of cowbells and birdsong. Traditional wooden chalets line its single main street, and the unobstructed views across to the Jungfrau massif are among the finest in the Alps.

## Lauterbrunnen Valley
Flanked by near-vertical cliffs rising over 300 metres, this glacially carved valley channels seventy-two waterfalls that cascade in ribbons of white from the plateau above. Staubbach Falls, the most prominent, drops freely for nearly 300 metres just steps from the village centre. The valley is said to have inspired Tolkien's depiction of Rivendell.

## Interlaken
Nestled on a flat alluvial plain between Lake Thun and Lake Brienz, Interlaken has served as the gateway to the Bernese Oberland since the nineteenth century. The Hoheweg promenade offers a celebrated view of the Jungfrau, and the compact town centre mixes Belle Epoque grand hotels with independent shops and alpine outfitters.

---
**Hotel:** Interlaken · **Transport:** Private vehicle to Schilthorn cable car station, then to Interlaken · **Meals:** Breakfast

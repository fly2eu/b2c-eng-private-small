# Day 3 — Bern's UNESCO Old Town & the Flavours of Gruyeres

A guided walking tour reveals why Bern's medieval old town earned UNESCO World Heritage status. Sandstone arcades stretch for kilometres, fountains decorated with Renaissance figures punctuate every square, and the astronomical Clock Tower performs its centuries-old mechanical show. After lunch your vehicle heads south-west into the pre-Alpine countryside, where the village of Gruyeres delivers a trio of unmissable experiences: artisan cheese-making, a hilltop castle, and world-renowned Swiss chocolate.

## Bern Old Town Guided Walking Tour
A knowledgeable local guide walks you through the UNESCO-listed heart of Bern, where six kilometres of covered stone arcades shelter shops and cafes. The route weaves past eleven allegorical fountains, each topped with a colourful Renaissance sculpture, offering snapshots of civic pride and medieval storytelling.

## Zytglogge (Clock Tower)
Standing at the western gate of the original city walls, the Zytglogge has kept time since 1530. Four minutes before each hour, a mechanical parade of bears, a crowing rooster, and a turning jester spring to life. The astronomical dial on its eastern face tracks the position of the sun, moon, and zodiac constellations.

## La Maison du Gruyere
This modern cheese dairy at the foot of Gruyeres village demonstrates every stage of Gruyere AOP production, from fresh Alpine milk to the temperature-controlled cellars where wheels age for months. Interactive displays explain the science behind the cheese's nutty flavour, and tastings let you compare wheels of different maturity.

## Gruyeres Castle
Perched on a hilltop since the thirteenth century, this castle surveys the Saane valley and the Molesons peaks beyond. Eight centuries of architecture layer Savoyard, Burgundian, and Renaissance influences under one roof. Inside, period rooms display tapestries, armour, and painted ceilings that chart the rise and fall of the Counts of Gruyeres.

## Maison Cailler Chocolate Factory
Switzerland's oldest chocolate brand opens its doors for an immersive journey through cacao's history, from Mesoamerican origins to nineteenth-century Swiss innovation. The tour follows the production line where roasted beans become silky couverture, and concludes with a generous tasting session of Cailler's signature creations.

---
**Hotel:** Gruyeres area · **Transport:** Private vehicle Bern → Gruyeres · **Meals:** Breakfast

## Day 1 — Arrival in Paris

Your European family road trip begins at Charles de Gaulle Airport, where you collect your rental car and take the wheel for the first time.

**CDG Airport Arrival & Car Collection**
You land at Charles de Gaulle Airport and collect your rental vehicle. The drive south into Paris takes around forty-five minutes, weaving through the northern suburbs before the city centre reveals itself.

**Hotel Check-In (Charenton-le-Pont Area)**
You check in to your hotel in the Charenton-le-Pont area, just southeast of central Paris. The location gives you easy access to the périphérique ring road for the days ahead while staying close to the city centre.

**Notre-Dame Cathedral**
You drive into the heart of Paris and park near the Île de la Cité to visit Notre-Dame Cathedral. The Gothic masterpiece, with its flying buttresses and rose windows, has anchored the spiritual centre of Paris since the twelfth century. Recently restored, it gleams under evening light.

**Eiffel Tower**
You make your way to the Champ de Mars to see the Eiffel Tower up close. Rising three hundred and thirty metres above the park, the iron lattice structure is mesmerising at sunset when warm light catches the metalwork before the sparkling light display begins on the hour.

**Seine River Cruise**
You round off the evening with a cruise along the Seine. The boat glides past illuminated bridges and landmarks on both banks — the Musée d'Orsay, the Louvre, and Notre-Dame — offering a tranquil first encounter with the city from the water.

*You collect your rental car at CDG Airport and drive to your hotel near Charenton-le-Pont (approximately 45 minutes). Evening sightseeing in central Paris by car and on foot.*
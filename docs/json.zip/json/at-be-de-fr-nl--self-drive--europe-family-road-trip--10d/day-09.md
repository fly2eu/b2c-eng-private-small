## Day 9 — Hannover to Munich

South through the German heartland to Bavaria.

**Hannover Area** *(optional)*
You have the morning to explore the Hannover area. The Herrenhausen Gardens, among Europe's most important baroque gardens, are a worthwhile stop if time permits before the long drive south.

**Drive to Munich**
You take the wheel for the roughly six-hundred-kilometre drive south on the Autobahn. The route passes through Göttingen, Kassel, and Nuremberg before the Bavarian capital appears against its alpine backdrop. Allow approximately five to six hours for the drive with stops.

*Approximately 600 km from Hannover to Munich (5-6 hours). A long driving day — plan rest stops along the Autobahn. Overnight in the Munich area.*
## Day 3 — Disneyland Paris & Drive to Belgium Border

A day of theme-park magic followed by an evening drive north.

**Disneyland Paris**
You spend a full day at Disneyland Paris, Europe's most-visited theme park. The resort comprises two parks — Disneyland Park and Walt Disney Studios — each packed with attractions, live shows, and themed lands. From classic rides to spectacular parades, the day is a celebration of storytelling and imagination for the whole family.

**Drive to Lille / Ardennes Region**
After the parks close, you take the wheel for the roughly two-hundred-and-fifty-kilometre drive north. The motorway carries you through the flat farmlands of northern France toward the Belgian border, where you check in for the night in the Lille or Ardennes area.

*You drive approximately 40 km east to Disneyland Paris, then 250 km north to the Lille/Ardennes area in the evening (around 2.5 hours).*
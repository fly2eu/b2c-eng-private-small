## Day 8 — Amsterdam to Hannover

Morning in Amsterdam, then east into Germany.

**Amsterdam Exploration**
You spend the morning in Amsterdam's canal ring, a UNESCO World Heritage Site of concentric waterways lined with narrow gabled houses. Dam Square, the Royal Palace, and the flower market on the Singel are all within easy walking distance of one another.

**Drive to Hannover**
You take the wheel for the roughly four-hundred-kilometre drive east from Amsterdam into Germany. The route crosses the Dutch-German border near Enschede and continues through the Lower Saxony countryside to Hannover, taking approximately four hours on the Autobahn.

*Morning in Amsterdam on foot, then approximately 400 km drive east to Hannover (around 4 hours). Overnight in the Hannover area.*
# Day 6 — Grindelwald, Jungfraujoch & Lauterbrunnen

## Morning: Grindelwald & Eiger Express

Travel to the mountain village of Grindelwald, nestled at the foot of the mighty Eiger. Board the Eiger Express gondola — a striking feat of Swiss engineering — for the swift ascent to Eiger Glacier station, where you connect to the Jungfrau Railway.

## Midday: Jungfraujoch — Top of Europe

Arrive at Jungfraujoch, the highest railway station in Europe at 3,454 metres above sea level. Step out onto the Sphinx Observation Deck for awe-inspiring views of the Aletsch Glacier, the longest glacier in the Alps. Explore the magical Ice Palace, carved deep within the glacier, and visit the Lindt Swiss Chocolate Shop for a taste of Switzerland's finest.

## Afternoon: Lauterbrunnen

Descend via Wengen to the Lauterbrunnen valley, one of the deepest U-shaped valleys in Switzerland, famous for its 72 waterfalls cascading from sheer cliff faces. The dramatic scenery here is said to have inspired Tolkien's vision of Rivendell.

**Overnight:** Interlaken

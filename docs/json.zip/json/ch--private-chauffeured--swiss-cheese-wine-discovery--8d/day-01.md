# Day 1 — Arrival in Zurich

Your private driver meets you at Zurich Airport and transfers you directly to your hotel in the city centre.

The remainder of the day is at leisure, giving you time to settle in and begin exploring Zurich at your own pace. Stroll along the Limmat River, browse the shops of the Niederdorf quarter, or simply relax after your journey.

**Overnight:** Zurich

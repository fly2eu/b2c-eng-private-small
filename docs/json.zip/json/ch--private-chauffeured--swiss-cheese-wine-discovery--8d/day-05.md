# Day 5 — GoldenPass Express to Interlaken

## Morning: GoldenPass Express

Board the GoldenPass Express for a panoramic train journey of approximately two hours from Montreux to Interlaken. This celebrated route winds through the Pre-Alps, passing lush meadows, traditional chalets, and dramatic mountain scenery. The large panoramic windows ensure uninterrupted views throughout the journey.

## Afternoon: Harder Kulm

On arrival in Interlaken, take the Harder Kulm funicular to the panoramic viewpoint high above the town. From the observation platform, you are rewarded with a breathtaking 360-degree panorama over Lake Thun, Lake Brienz, and the snow-capped peaks of the Bernese Alps — including the Eiger, Mönch, and Jungfrau.

Spend the rest of the afternoon exploring Interlaken at leisure, set in one of the most spectacular locations in the Swiss Alps.

**Overnight:** Interlaken

# Day 7 — Lucerne & Return to Zurich

## Morning: Brünig Pass

Depart Interlaken and travel the scenic route over the Brünig Pass, winding through Alpine valleys and past crystal-clear lakes. The drive itself is a highlight of the day, with constantly changing mountain scenery.

## Midday & Afternoon: Lucerne

Arrive in the charming lakeside city of Lucerne for a guided tour of its most celebrated landmarks. Cross the iconic Chapel Bridge, Europe's oldest covered wooden bridge, adorned with 17th-century paintings. Visit the Jesuit Church, one of the finest Baroque churches in Switzerland, and stroll along the Reuss River promenade. Pay your respects at the Lion Monument, Mark Twain's "most mournful and moving piece of stone in the world," carved into the rock face in memory of the Swiss Guards who fell during the French Revolution.

## Evening: Zurich

Your driver returns you to Zurich for your final evening in Switzerland. Enjoy a farewell stroll through the old town or along the lake promenade.

**Overnight:** Zurich

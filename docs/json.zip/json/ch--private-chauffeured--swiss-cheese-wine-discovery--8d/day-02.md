# Day 2 — Zurich Old Town & Rhine Falls

## Morning: Zurich Old Town

Your day begins with a two-hour guided walking tour of Zurich's atmospheric old town. Your guide leads you through centuries of history as you visit the twin-towered Grossmünster, the elegant Bahnhofstrasse — one of the world's most renowned shopping streets — and the grand Paradeplatz. Continue to the Fraumünster, celebrated for its stunning stained-glass windows, before walking along the Limmat riverside with its charming guild houses.

## Afternoon: Rhine Falls & Stein am Rhein

Your private driver takes you north to Rhine Falls, the largest waterfall in Europe, straddling the Swiss-German border. Feel the thundering power of the water up close on an exhilarating boat ride at the base of the falls.

On the return journey, stop in the medieval town of Stein am Rhein, where beautifully frescoed half-timbered houses line the cobblestone streets — a picture-perfect Swiss gem.

**Overnight:** Zurich

# Day 8 — Departure from Zurich

Your private driver transfers you from your hotel to Zurich Airport in good time for your departure flight.

End of services. We hope you enjoyed your Swiss Cheese Discovery tour with flyEurope.

**End of tour**

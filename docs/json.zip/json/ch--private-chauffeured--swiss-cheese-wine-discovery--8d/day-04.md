# Day 4 — Château de Chillon, Lavaux & Geneva

## Morning: Château de Chillon

Just minutes along the shoreline from Montreux, Château de Chillon rises directly from the waters of Lake Geneva — one of the best-preserved medieval castles in Europe and Switzerland's most visited historic monument. Your private transfer delivers you to the entrance, where you explore over a thousand years of history across 25 buildings: vaulted Gothic dungeons, grand halls, towers with lakeside terraces, and a collection of medieval armour and furnishings. The setting — water on three sides, the Alps behind — is extraordinary.

## Late Morning: Lavaux UNESCO Vineyard Terraces

Continue along the lake to the Lavaux terraced hillsides, a UNESCO World Heritage Site. These ancient stone-walled terraces cascade steeply from the village rooftops down to the water's edge, covering eight kilometres of south-facing slopes. A walking tour through the terraces reveals the extraordinary scale of the landscape — rows of vines framing an unbroken panorama of Lake Geneva, the Savoy Alps, and on clear days, Mont Blanc.

## Midday: Lausanne

Continue to the vibrant university city of Lausanne for a leisurely lunch. Perched on the hills above Lake Geneva, Lausanne offers wonderful views and a lively café culture.

## Afternoon: Geneva

Your driver brings you to Geneva for a guided walk through the old town, with its narrow streets, historic squares, and views over the city. See the iconic Jet d'Eau fountain — one of the tallest in the world — shooting 140 metres into the sky. Stroll through the international district and take in views of the United Nations headquarters, a reminder of Geneva's role as a global hub for diplomacy and humanitarian work.

**Overnight:** Geneva / Montreux

# Day 3 — Bern, Gruyères & Montreux

## Morning: Bern

Depart Zurich and travel to the Swiss capital, Bern. A guided walk through the UNESCO-listed old town takes you past the Holy Ghost Church, along Spitalgasse to Bärenplatz, and on to the imposing Federal Palace. The highlight is the famous Zytglogge Clock Tower, with its astronomical clock and animated figures — a masterpiece of medieval engineering.

## Afternoon: Gruyères & Broc

Continue into the rolling hills of canton Fribourg to the enchanting hilltop village of Gruyères. Visit La Maison du Gruyère, where you discover the art of traditional Swiss cheesemaking from fresh milk to aged wheel. Afterwards, explore the medieval Gruyères Castle, perched above the village with sweeping views of the surrounding countryside. Two kilometres away in Broc, the Maison Cailler leads you through an immersive journey tracing 200 years of Swiss chocolate heritage, from the Cailler family's earliest recipes to today's craft, finishing with a tasting room generous with samples.

## Evening: Montreux

Your driver brings you to Montreux, the jewel of the Swiss Riviera, beautifully set on the shores of Lake Geneva. Settle into your lakeside hotel and enjoy the palm-lined promenade as the sun sets over the water.

**Overnight:** Montreux

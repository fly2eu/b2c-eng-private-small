# Day 4 — Cologne, Dinant & Brussels Airport

The final day opens with an optional early visit inside the Cologne Cathedral before the coach heads south-west into Belgium. The riverside town of Dinant delivers a dramatic closing chapter — a pear-towered collegiate church, a clifftop citadel high above the Meuse, and a musical landmark — before the group transfers to Brussels Airport.

## Cologne Cathedral Interior *(optional)*
An optional visit to the interior of Cologne Cathedral takes place between 08:30 and 09:30 for those who wish to experience the building from within. The soaring Gothic nave rises 43 metres above the floor, and the Shrine of the Three Kings — the largest reliquary in the Western world — glitters in gold behind the high altar. Entry to the nave is free of charge.

## Transfer Cologne to Dinant *(included)*
The coach departs Cologne and crosses the border back into Belgium, heading south to Dinant on the Meuse River — a drive of approximately two hours covering around 175 kilometres. The landscape shifts from the Rhine lowlands to the forested hills and river valleys of the Belgian Ardennes.

## Collegiate Church of Notre-Dame, Dinant
The group visits the Collegiate Church of Notre-Dame, whose distinctive pear-shaped bell tower and pale stone façade sit dramatically at the foot of sheer Meuse riverbank cliffs. The church dates from the 16th century and its unusual bulbous spire is one of the most recognisable silhouettes in all of Belgium.

## Citadel of Dinant
Perched 100 metres above the Meuse River on a sheer limestone cliff, the Citadel of Dinant can be reached by a climb of 408 steps or by cable car. The fortification offers commanding views over the river valley below and the terracotta rooftops of the town clustered at the foot of the rock face.

## Birthplace of Adolphe Sax
The group passes the birthplace of Adolphe Sax, the Belgian instrument-maker born in Dinant in 1814 who went on to invent the saxophone. The town celebrates its most famous son with a series of saxophone sculptures lining the main bridge over the Meuse, each one painted in a different design.

## Transfer to Brussels Airport *(included)*
The coach departs Dinant for Brussels Airport, a drive of approximately one and a half hours covering around 100 kilometres. The tour manager assists the group with luggage and departure formalities, bringing the four-day tour to a close.

---
**Hotel:** — · **Transport:** AC coach Cologne → Dinant (175km, ~2hr), Dinant → Brussels Airport (100km, ~1.5hr)

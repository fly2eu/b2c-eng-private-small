# Day 2 — Bruges to Amsterdam & Zaanse Schans

The coach departs Bruges and makes the journey north into the Netherlands. Amsterdam's iconic canals, narrow gabled houses, and Dam Square are explored during the afternoon, followed by a visit to the open-air heritage village of Zaanse Schans where working windmills and traditional craft workshops line the banks of the Zaan River.

## Transfer Bruges to Amsterdam *(included)*
The group boards the coach in Bruges for the drive north to Amsterdam, a journey of approximately three hours covering around 270 kilometres through Belgium and into the Netherlands. The tour leader provides commentary on the changing landscape as the flat polders of the Dutch lowlands come into view.

## Amsterdam Canal Walk & Dam Square
The group explores central Amsterdam on foot, taking in the UNESCO-listed ring of 17th-century canals lined with the characteristic narrow houses whose facades tilt gently forward over the water below. Dam Square, the historic heart of the city, is home to the Royal Palace and the National Monument, and provides a natural focal point from which the group fans out to admire the surrounding streets and canal bridges.

## Zaanse Schans
The group visits Zaanse Schans, a living heritage village where working windmills turn above the green banks of the Zaan River just north of Amsterdam. Traditional wooden houses painted in the characteristic deep green and demonstrations in the craft workshops — including clog-making and Dutch cheese production — bring rural life from previous centuries vividly back to life. The group has approximately ninety minutes to explore the site and visit the workshops.

---
**Hotel:** Zaandam · **Transport:** AC coach Bruges → Amsterdam (270km, ~3hr), local coach within Amsterdam area

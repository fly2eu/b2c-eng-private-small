# Day 1 — Brussels Highlights & Medieval Bruges

The group arrives early in Brussels for a swift tour of the city's most celebrated landmarks before the coach continues to the UNESCO-listed medieval city of Bruges. The afternoon and evening are spent exploring Bruges at a leisurely pace — its canal-laced old town, cobbled lanes, and Gothic architecture providing a memorable first night.

## Grand Place
The group visits the Grand Place, Brussels' magnificent central square and a UNESCO World Heritage Site. Gilded guild houses with ornate façades surround the cobblestoned plaza on all sides, and the soaring Gothic Town Hall anchors the composition at one end. The square is widely regarded as one of the most beautiful in Europe, and the group has time to walk the perimeter and take in the detail of each guild house façade.

## Manneken Pis
A short walk from the Grand Place brings the group to the Manneken Pis, the small bronze fountain sculpture that has become an unofficial emblem of Brussels. Despite its modest scale, the statue draws visitors from around the world and is often dressed in a themed costume reflecting a local celebration or anniversary. The surrounding streets are lined with Belgian chocolate shops and lace boutiques.

## Transfer to Bruges *(included)*
The coach departs Brussels and heads west to Bruges, a journey of approximately one hour covering around 100 kilometres through the Flemish countryside. The tour leader provides an introduction to Bruges and outlines the afternoon's programme.

## Bruges Old Town Walk
The group takes a relaxed guided walk through the old town of Bruges, a UNESCO World Heritage Site preserved almost entirely intact from the Middle Ages. Narrow brick lanes lead past the Markt square with its commanding Belfort belfry tower, the tranquil Groenerei canal, and a series of arched bridges spanning the inner waterways. The reflected image of stepped-gable townhouses shimmering in the canals is one of the defining sights of the entire tour. The evening is free for the group to continue exploring the atmospheric streets at their own pace.

---
**Hotel:** Bruges · **Transport:** AC coach Brussels → Bruges (100km, ~1hr)

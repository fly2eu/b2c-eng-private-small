# Day 3 — Giethoorn by Boat & Cologne Cathedral

The group departs early for Giethoorn, the car-free Dutch village famous for its canal network, 176 wooden bridges, and thatched-roof farmhouses built on peat islands. After a midday lunch stop, the coach continues south-east into Germany for a late-afternoon arrival in Cologne, where the colossal medieval cathedral towers above the Rhine.

## Giethoorn — Village Canal Boat Ride *(included)*
The group boards whisper-quiet electric boats to glide through the waterways of Giethoorn, a village with no roads in its historic centre. More than 176 wooden footbridges arc over the canals that connect the peat islands, and thatched-roof farmhouses with neatly tended garden plots line every stretch of water. The boat tour lasts approximately one hour and passes through the most picturesque sections of the village, with the only sounds being birdsong and the soft lapping of water.

## Lunch Stop
The group stops for lunch at a local restaurant in the Giethoorn area. The setting among the Dutch waterways provides a peaceful backdrop for a midday break before the afternoon drive south into Germany.

## Transfer to Cologne *(included)*
The coach crosses from the Netherlands into north-west Germany for the drive to Cologne, a journey of approximately two and a half hours covering around 230 kilometres through flat lowland terrain. As the coach enters the city, the twin spires of the cathedral appear on the skyline long before arrival.

## Cologne Cathedral Photo Stop
The group stops at the Cologne Cathedral, Germany's most visited landmark and a UNESCO World Heritage Site. Construction began in the Middle Ages and was finally completed in the 1880s, producing twin spires that rise 157 metres above the Rhine. Remarkably, the cathedral survived fourteen direct bomb hits during the Second World War and still stands intact as a testament to Gothic engineering. The plaza in front of the cathedral provides excellent framing for photographs at any time of day.

---
**Hotel:** Cologne · **Transport:** AC coach Zaandam → Giethoorn (130km, ~1.5hr), Giethoorn → Cologne (230km, ~2.5hr)

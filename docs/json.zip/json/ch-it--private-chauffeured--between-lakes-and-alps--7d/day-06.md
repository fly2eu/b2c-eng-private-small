## Day 6 — Vaduz & Return to Zürich

You travel north through the Rhine Valley, stopping in the Liechtenstein capital for a guided walk, before continuing to Zürich.

**Rhine Valley Drive**
Your vehicle follows the Rhine Valley northward from the Engadin, passing through a landscape of vineyards, orchards, and small towns backed by forested mountain slopes.

**Vaduz Guided Walking Tour**
A guided walk takes you through the centre of Liechtenstein's capital. You see the pedestrian high street, the parliament building, and the main cultural institutions of this compact micro-state. A souvenir passport stamp is available at the tourist office.

**Vaduz Castle**
The official residence of the Prince of Liechtenstein overlooks the town from a wooded ridge. The castle interior is closed to visitors, but the exterior and the path leading up to it provide sweeping views over the Rhine Valley.

*Your private vehicle departs St. Moritz in the morning, stops in Vaduz for a guided tour, then continues to Zürich for the evening.*

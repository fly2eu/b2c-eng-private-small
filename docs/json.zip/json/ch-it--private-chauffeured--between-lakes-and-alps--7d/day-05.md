## Day 5 — St. Moritz

A full day at leisure in the Engadin valley, with a thermal spa visit included and optional walks and museums.

**Ovaverva Thermal Spa (included)**
Your day includes access to the Ovaverva spa and sports centre. The thermal pools draw mineral-rich water from local springs, with indoor and outdoor bathing areas offering views across the Engadin valley and surrounding peaks.

**St. Moritz Lake Walk (optional)**
A flat path follows the shore of Lake St. Moritz, with mountain reflections in the water and connections to longer trails through the Engadin valley. The walk is accessible year-round and takes roughly forty-five minutes to complete.

**Engadine Museum (optional)**
Original Engadin room interiors — panelled walls, carved furniture, and domestic artefacts — are reconstructed inside this museum to illustrate five centuries of life in the high Alpine valleys.

**Segantini Museum (optional)**
A domed gallery built specifically to house the works of Giovanni Segantini, the painter who captured the luminous quality of Engadin light. The centrepiece is his monumental Alpine Triptych depicting life, nature, and death in the mountains.

*No scheduled transfers today. You are free to explore St. Moritz and the Engadin valley independently.*

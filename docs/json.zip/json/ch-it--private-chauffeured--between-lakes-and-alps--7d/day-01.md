## Day 1 — Zürich

Your journey begins with a smooth arrival into Switzerland's largest city.

**Zürich Airport Transfer**
Your private driver meets you at arrivals and brings you directly to your centrally located hotel. The transfer takes approximately thirty minutes depending on traffic.

*A private transfer brings you from Zürich Airport to your hotel in the city centre. The evening is at leisure.*

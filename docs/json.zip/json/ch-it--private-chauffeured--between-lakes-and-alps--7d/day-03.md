## Day 3 — Lugano

You discover the Italianate charm of Lugano on a guided walking tour, then choose between a miniature-Switzerland park or a factory outlet village in the afternoon.

**Lugano Guided Walking Tour**
A two-hour walk leads you through the Italianate piazzas and shaded arcades of Lugano's compact centre. You pass the Cattedrale di San Lorenzo with its Renaissance facade, stroll the lakeside promenade, browse the covered market lanes, and end in the lush Parco Ciani at the water's edge.

**Cattedrale di San Lorenzo**
Lugano's cathedral stands on a raised terrace above the old town. Its Renaissance-era facade and Baroque interior frescoes reflect the cultural crossroads of Italian and Swiss traditions that define the Ticino region.

**Parco Ciani**
This lakeside park stretches along the shore of Lake Lugano, with mature trees, flower beds, and open lawns. Walking paths lead to viewpoints over the lake and the surrounding mountains of the Ticino pre-Alps.

**Swissminiatur Melide (optional)**
This open-air museum in Melide displays over 120 scale models of Switzerland's most famous buildings, castles, and landmarks, set in landscaped grounds on the shore of Lake Lugano. Model trains and cable cars run between the exhibits.

**FoxTown Factory Stores Mendrisio (optional)**
Located in nearby Mendrisio, FoxTown is one of the largest factory outlet centres in southern Switzerland. Over 160 brand stores offer year-round discounts on fashion, accessories, and homeware.

*No long-distance transfers today. Local transport or a short drive is needed if you choose the afternoon excursion to Melide or Mendrisio.*

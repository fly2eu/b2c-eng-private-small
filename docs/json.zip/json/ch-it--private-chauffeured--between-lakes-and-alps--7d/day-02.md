## Day 2 — Lucerne & Gotthard Panorama Express to Lugano

You explore Lucerne with a local guide in the morning, then board a paddle steamer and panoramic train on the Gotthard Panorama Express route, arriving in Italian-speaking Ticino by evening.

**Lucerne Guided Tour**
A two-hour guided walk takes you through the highlights of lakeside Lucerne. You cross the fourteenth-century Chapel Bridge, pause at the Lion Monument carved into sandstone cliff, visit the Picasso Museum, and follow the Reuss River through the medieval old town.

**Chapel Bridge**
Europe's oldest covered wooden bridge spans the Reuss River diagonally, connecting the old town to the newer quarters. Its interior panels depict seventeenth-century scenes from Lucerne's history, and the octagonal Water Tower at its midpoint is one of Switzerland's most photographed landmarks.

**Lion Monument**
This sculpture of a dying lion is hewn directly from a natural rock face in a quiet park. It commemorates the Swiss Guards who died defending the Tuileries during the French Revolution and is one of the most visited monuments in Switzerland.

**Picasso Museum**
Housed in a historic building near the old town, the collection includes photographs and works relating to Picasso's later years, offering an intimate look at the artist's life and creative process.

**Gotthard Panorama Express — Lake Section**
You board a historic paddle steamer at Lucerne and cruise the length of Lake Lucerne to Flüelen. The roughly two-and-a-half-hour voyage passes beneath dramatic mountain walls, through narrow lake arms, and past the Rütli meadow — the legendary birthplace of the Swiss Confederation.

**Gotthard Panorama Express — Rail Section**
At Flüelen you transfer to the panoramic train for the roughly two-and-a-half-hour rail section. The train climbs through the Gotthard tunnel and descends into the Italian-speaking canton of Ticino, where palm trees and Mediterranean architecture replace Alpine pastures.

*Your private vehicle transfers you from Zürich to Lucerne in the morning. From Lucerne, you travel independently on the Gotthard Panorama Express to Lugano. A local transfer brings you to your hotel on arrival.*

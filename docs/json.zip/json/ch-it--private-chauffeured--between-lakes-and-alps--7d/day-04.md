## Day 4 — Tirano & Bernina Express to St. Moritz

You cross into Italy for a morning in Tirano, then board the first-class Bernina Express for a UNESCO Heritage railway journey climbing from the valley floor to the high Engadin.

**Transfer to Tirano**
Your private vehicle crosses the Swiss-Italian border and brings you to Tirano in approximately ninety minutes. The route follows the shore of Lake Lugano before climbing into the Valtellina valley.

**Tirano Old Town**
You have free time to explore the compact Italian town of Tirano. Narrow lanes open onto small piazzas, and the architecture reflects centuries of trade between the Lombardy plains and the Alpine passes above.

**Basilica di Madonna di Tirano**
This Renaissance basilica on the outskirts of town is the most important pilgrimage site in the Valtellina. Its richly decorated interior features elaborate carved woodwork, gilded altarpieces, and seventeenth-century frescoes covering the vaulted ceiling.

**Bernina Express (1st class)**
You board the Bernina Express in first class for the roughly two-and-a-half-hour journey from Tirano at 429 metres to St. Moritz at 1,775 metres. The UNESCO World Heritage railway crosses the Brusio circular viaduct, climbs past Alpine lakes to the Bernina Pass at 2,253 metres, and descends through the Landwasser Viaduct — a six-arched stone bridge curving into a mountain tunnel.

*Your private vehicle transfers you from Lugano to Tirano, Italy, in the morning. You board the Bernina Express at Tirano station and arrive at St. Moritz in the late afternoon.*

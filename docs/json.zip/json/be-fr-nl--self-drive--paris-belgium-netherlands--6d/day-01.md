## Day 1 — Paris

Your journey begins with an evening arrival in the French capital.

**Paris Orly Airport Arrival**
You land at Orly Airport in the evening and collect your rental vehicle. The drive into central Paris takes roughly forty minutes, giving you a first taste of the city's illuminated boulevards.

**Hotel Check-In**
You check in to your centrally located hotel and have the rest of the evening at leisure. An early night sets the tone for a full day of exploration ahead.

*You collect your rental car at Orly Airport and drive to your hotel in central Paris.*

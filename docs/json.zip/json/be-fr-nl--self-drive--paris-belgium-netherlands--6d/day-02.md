## Day 2 — Paris

A full day devoted to the French capital's most iconic landmarks. You navigate from the bohemian hilltop of Montmartre down through the grand avenues to the banks of the Seine.

**Montmartre**
You begin on the cobbled lanes of Montmartre, the hilltop village that still carries the spirit of the artists who once lived here. Winding staircases lead past portrait painters and tiny cafés tucked into limestone facades.

**Sacré-Cœur Basilica**
Crowning the summit of Montmartre, this Romano-Byzantine basilica gleams white against the Paris skyline. You step inside to find a vast golden mosaic overhead and, from the terrace outside, a panorama stretching across the entire city.

**Arc de Triomphe**
You drive down to the Place Charles de Gaulle where the Arc de Triomphe commands the junction of twelve radiating avenues. Commissioned by Napoleon in 1806, the monument honours those who fought for France, with intricate relief sculptures covering its pillars.

**Champs-Élysées**
From the Arc you stroll down the Champs-Élysées, one of the world's most celebrated avenues. Tree-lined and nearly two kilometres long, it stretches toward the Place de la Concorde, flanked by flagship stores and grand terraces.

**Notre-Dame Cathedral**
You cross to the Île de la Cité to stand before Notre-Dame, the Gothic masterpiece that has anchored the heart of Paris since the twelfth century. Its flying buttresses, rose windows, and sculptural portals represent the height of medieval craftsmanship.

**Louvre Museum**
You enter through the glass pyramid into the world's largest art museum. Home to the Mona Lisa, the Winged Victory of Samothrace, and roughly thirty-five thousand works on display, even a focused visit reveals centuries of artistic achievement.

**Eiffel Tower**
The day culminates at the Eiffel Tower, rising three hundred and thirty metres above the Champ de Mars. You take in the iron lattice structure up close, and as evening approaches the tower begins its sparkling light display across the Seine.

**Seine Canal Cruise (optional)**
You may choose to end the day with a cruise along the Seine. The boat glides past illuminated landmarks on both banks, offering a tranquil perspective on the city after a full day on foot.

*Paris is best explored on foot and by metro today. Consider parking your rental car at the hotel.*

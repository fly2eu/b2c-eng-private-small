## Day 3 — Brussels & Antwerp

You take the wheel and head north into Belgium, crossing the border within a few hours. Brussels reveals its ornate squares and curious monuments before you continue onward to Antwerp for the night.

**Paris to Brussels Drive**
Today's route takes you roughly three hundred kilometres north from Paris into Belgium. The motorway passes through the flat farmlands of northern France and Wallonia before the Brussels skyline appears on the horizon.

**Grand Place**
You step into one of Europe's most beautiful squares, surrounded by opulent guild halls with gilded facades. A UNESCO World Heritage Site since 1998, the Grand Place dazzles with Baroque ornamentation and the Gothic spire of the Town Hall.

**Manneken Pis**
A short walk from the Grand Place brings you to this small bronze fountain sculpture that has become one of Brussels' most enduring symbols. Dating to the early seventeenth century, the statue is frequently dressed in miniature costumes for special occasions.

**Atomium**
You drive to the Heysel plateau to see the Atomium, a one-hundred-and-two-metre structure built for the 1958 World Expo. Its nine interconnected spheres represent an iron crystal magnified one hundred and sixty-five billion times, and the top sphere offers a sweeping city panorama.

**European Parliament**
You pass through the European Quarter to see the glass-fronted seat of the European Parliament. The building complex anchors the institutional heart of the European Union, and its visitor centre offers insight into EU decision-making.

**Bruges (optional)**
If time allows, you detour west to Bruges, a medieval gem threaded with canals. The Markt square, the Belfry tower, and the lace-trimmed streets feel preserved in amber, making it one of the best-kept medieval townscapes in Europe.

**Ghent (optional)**
Another optional stop en route, Ghent straddles multiple waterways and blends medieval architecture with a lively student-city atmosphere. The Graslei waterfront and Saint Bavo's Cathedral with its famous Ghent Altarpiece are the main draws.

**Antwerp Overnight**
You continue north to Antwerp and check in to your hotel for the night. Belgium's diamond capital and fashion hub, Antwerp rewards an evening stroll through its cathedral square and along the Scheldt riverfront.

*You drive approximately 300 km from Paris to Brussels (around 3.5 hours), then continue 50 km north to Antwerp for overnight.*

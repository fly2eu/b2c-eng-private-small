## Day 6 — Paris

Your final morning in Paris allows time for some last-minute shopping before you make your way to the airport for your onward journey.

**La Vallée Village**
You visit a designer outlet village on the outskirts of Paris, where open-air lanes connect boutiques from European and international fashion houses. The relaxed setting and landscaped walkways make for a pleasant final morning activity.

**Transfer to CDG Airport**
You return your rental car and transfer to Charles de Gaulle Airport for your departure flight. Allow at least two hours before your scheduled departure for check-in and security.

*You drop off the rental car at CDG Airport and catch your departure flight.*

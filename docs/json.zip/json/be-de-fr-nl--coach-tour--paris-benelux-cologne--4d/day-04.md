# Day 4 — Zaanse Schans → Giethoorn → Cologne

The final day is the tour's most varied, moving from the 18th-century windmills of Zaanse Schans to the car-free waterways of Giethoorn before crossing into Germany for an evening arrival in Cologne. The tour ends beneath the twin spires of one of the world's great Gothic cathedrals.

## Zaanse Schans
The group visits Zaanse Schans, a living open-air museum of working windmills beside the Zaan River. The site was the world's first industrial area, where hundreds of mills once processed timber, spices, paint, and paper for trade across Europe. Traditional craft workshops demonstrate clog-making and Dutch cheese production, and the distinctive green mill silhouettes reflected in the river offer some of the most recognisable views in the Netherlands.

## Giethoorn — Village by Boat *(included)*
The group boards flat-bottomed boats to explore Giethoorn, a village with no roads in its historic centre. Movement here has always been by water or on foot across the 176 wooden bridges connecting the thatched-roof farmhouses built on peat islands. The group glides quietly through the waterways, passing well-tended gardens and fields stretching back from the canal edge on either side.

## Cologne Cathedral (Kölner Dom)
The coach crosses into Germany for an evening arrival at the Kölner Dom, Germany's most visited landmark and a UNESCO World Heritage Site. Construction began in 1248 and took 632 years to complete; the twin spires rise 157 metres and were the tallest man-made structures in the world when finished in 1880. Despite sustaining 14 direct aerial bomb hits during the Second World War, the cathedral survived and continues to stand as a testament to centuries of craftsmanship above the Rhine.

---
**Hotel:** — (departure day) · **Transport:** Luxury coach Amsterdam → Zaanse Schans → Giethoorn → Cologne (~300km total)

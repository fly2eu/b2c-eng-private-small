# Day 1 — Arrival in Paris

The group arrives in Paris and sets out to discover the French capital's most celebrated landmarks. The day takes in the iconic Eiffel Tower, the bookstall-lined banks of the Seine, and the hilltop neighbourhood of Montmartre before an overnight rest in the city.

## Eiffel Tower
The group visits the Eiffel Tower, the iron lattice landmark that has defined the Paris skyline since 1889. Rising 324 metres above the Champ de Mars, it is the most visited paid monument in the world. The group admires the structure from the esplanade and takes time to photograph it from multiple angles, including from the Trocadéro gardens across the river.

## Seine River Quays
The group strolls along the banks of the Seine, where the characteristic green wooden stalls of the bouquinistes — dealers in second-hand books and vintage prints — line the riverside walkways for several kilometres. This stretch of the riverbank forms part of a UNESCO World Heritage corridor and gives the group a gentler, unhurried introduction to Parisian life.

## Montmartre
The group ascends to Montmartre, a hilltop quarter with a distinct village atmosphere that sets it apart from the busier boulevards below. Narrow streets, the artists' square at Place du Tertre, and sweeping panoramic views over the city have long made this neighbourhood one of the most memorable parts of any Paris visit. The white dome of the Sacré-Cœur Basilica crowns the summit and provides a striking backdrop for photographs.

---
**Hotel:** Paris · **Transport:** Arrival transfer; luxury coach for city touring

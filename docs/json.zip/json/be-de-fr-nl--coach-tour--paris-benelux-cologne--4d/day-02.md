# Day 2 — Paris → Brussels → Bruges

The coach departs Paris and heads north into Belgium for a morning stop at the grand heart of Brussels before continuing to the medieval city of Bruges. An evening canal walk allows the group to experience the old town's fairy-tale atmosphere at its most atmospheric.

## Grand Place, Brussels
The group visits the Grand Place, Brussels' magnificent central square and a UNESCO World Heritage Site. The surrounding guild houses are decorated with some of the finest civic ornament in Europe — some façades retain their original 24-karat gold leaf — and the Gothic Town Hall anchors the composition with its 96-metre spire. The square was rebuilt with even greater splendour after the French bombardment of 1695, and it remains the most striking public square in Belgium.

## Manneken Pis
The group stops at the Manneken Pis, the small bronze fountain sculpture that has served as an unofficial emblem of Brussels since 1619. Standing just 61 centimetres tall, it is one of the most photographed objects in the city despite its modest dimensions. The figure maintains an official wardrobe of over 1,000 donated costumes, and the group may find it dressed in one of its many themed outfits.

## Bruges Old Town & Canals
The group arrives in Bruges, widely known as the Venice of the North for its interlocking canal network and its remarkably well-preserved medieval skyline. Gothic spires, step-gabled stone houses, and cobbled lanes give the old town the atmosphere of a city that time has barely touched since the 19th century. An evening walk along the canal banks offers reflections of illuminated façades on the still water.

---
**Hotel:** Bruges · **Transport:** Luxury coach Paris → Brussels (~320km, ~3.5hr), Brussels → Bruges (~100km, ~1hr)

# Day 3 — Bruges to Amsterdam

The coach drives north from Bruges into the Netherlands, delivering the group to Amsterdam for an afternoon and evening in one of Europe's most distinctive cities. The day focuses on the 17th-century canal ring and the extraordinary engineering that underpins the historic centre.

## Amsterdam Old Centre & Canal Ring
The group explores Amsterdam's historic centre, where the Grachtengordel — the 17th-century concentric ring of canals — is inscribed as a UNESCO World Heritage Site. Narrow gabled canal houses lean forward and tilt sideways on their timber piles, a deliberate feature that allowed goods to be hoisted to upper floors without striking the façades below. The entire city rests on millions of wooden piles driven deep into the marshy ground: the Royal Palace on Dam Square alone stands on 13,659 of them.

## Dam Square & Royal Palace
The group visits Dam Square, the historical heart of Amsterdam and the point from which the city grew outward in every direction. The Royal Palace on the square was originally constructed as the City Hall in the 17th century and is considered one of the finest examples of Dutch Classicist architecture. The surrounding square provides an open vantage point from which the group can take in the scale and character of the city centre.

## Amsterdam Evening Walk
The group takes a relaxed evening walk through the main squares, along the Prinsengracht canal, and through the city's bustling shopping streets. The illuminated canal bridges and their reflections on the water create a memorable atmosphere after dark, and the group has free time to explore at their own pace.

---
**Hotel:** Amsterdam · **Transport:** Luxury coach Bruges → Amsterdam (~250km, ~3hr)

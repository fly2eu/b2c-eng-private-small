# Day 7 — Madrid

A full day in the Spanish capital takes you through its principal landmarks, grand avenues, and shopping districts at a relaxed pace.

## Royal Palace of Madrid
Your vehicle brings you to the Royal Palace, the official residence of the Spanish monarchy. The Italianate facade overlooks the Plaza de Oriente and the Sabatini Gardens. The sheer scale of the building — over 3,000 rooms — is evident from the exterior.

## Santiago Bernabeu Stadium
Your vehicle passes the Santiago Bernabeu, home of Real Madrid. The exterior of the recently renovated stadium is visible from the road as your driver slows for photographs.

## Panoramic Madrid Drive
Your vehicle traces a route through the capital, passing Plaza Espana, Puerta de Alcala, El Prado Avenue, and the Cibeles Fountain. The drive provides an overview of Madrid's monumental character and tree-lined boulevards.

## Puerta del Sol Shopping *(optional)*
Free time at Puerta del Sol allows you to browse the shops along Gran Via and the surrounding pedestrian streets. The area is the commercial heart of the capital, with Spanish and international retailers lining every block.

---
**Hotel:** Madrid · **Transport:** Private vehicle within Madrid

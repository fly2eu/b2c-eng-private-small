# Day 6 — Alhambra, La Mancha & Toledo

The morning is devoted to the Alhambra before your vehicle heads north through the Don Quixote windmill landscape to Toledo, where you visit the Mosque of Bab al-Mardum and the damascene workshops. The day ends in Madrid.

## Alhambra *(included ticket)*
You spend the morning inside the Alhambra, walking through the Nasrid Palaces where Arabic inscriptions — prayers, Qur'anic verses, and poetry — cover every wall and ceiling in carved plaster and tile. The Court of the Lions, the Hall of the Ambassadors, and the Generalife gardens each reveal a distinct facet of Nasrid artistic mastery.

## Don Quixote Windmill Landscape
Your vehicle crosses the open plateau of La Mancha on the road north to Toledo. Whitewashed windmills stand on the ridges, silhouetted against the wide sky. The terrain is the same that Cervantes immortalised, and the sense of open space is striking after the hills of Andalusia.

## Mosque of Bab al-Mardum
You enter the Mosque of Bab al-Mardum, a 10th-century place of worship and one of Toledo's oldest surviving structures. Nine small domes, each crowned with a distinct geometric vault pattern, demonstrate the refinement of Umayyad architecture in central Iberia.

## Damascene Workshops & Zocodover Square
You visit a damascene workshop where artisans inlay gold and silver wire into blackened steel, a technique brought to Toledo during the Islamic period. The walk continues through Zocodover Square, the historic centre of the city's public life.

---
**Hotel:** Madrid · **Transport:** Private transfer from Granada to Toledo (4hr); Toledo to Madrid (1hr)

# Day 5 — Cordoba & Granada

Your vehicle takes you to Cordoba for the Great Mosque and the Roman Bridge before continuing east to Granada, where the evening is spent in the Albaicin quarter with panoramic views of the Alhambra.

## Great Mosque of Cordoba *(included ticket)*
Your guide leads you into the Great Mosque of Cordoba, the spiritual centre of Al-Andalus for over three centuries. A forest of columns and double arches in alternating red and white stone extends in every direction. The visit traces the mosque's expansion through successive Umayyad building campaigns.

## Bridge of Musa ibn Nusayr & Calahorra Tower
You cross the Roman Bridge over the Guadalquivir, pausing at the Calahorra Tower on the far bank. The bridge and tower together frame the most iconic view of Cordoba, with the Great Mosque rising behind the city walls.

## Andalusi House
You visit the Andalusi House, a museum recreating daily life in Islamic Cordoba. Exhibits include calligraphy, astronomy instruments, and domestic artefacts that illustrate the intellectual culture of the caliphal period.

## Albaicin Quarter
You explore the Albaicin, Granada's old Muslim quarter perched on a hillside opposite the Alhambra. Winding cobbled streets lead past carmen houses with hidden gardens and viewpoints that frame the palace against the snow-capped Sierra Nevada.

## Grand Mosque of Granada
The Grand Mosque of Granada sits at the top of the Albaicin. Its garden terrace provides one of the finest panoramic views of the Alhambra in the city, with the palace complex spread across the opposite ridge.

---
**Hotel:** Granada · **Transport:** Private transfer Seville to Cordoba (1.5hr); Cordoba to Granada (2.5hr)

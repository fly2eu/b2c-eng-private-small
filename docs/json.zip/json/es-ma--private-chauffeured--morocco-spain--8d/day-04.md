# Day 4 — Ferry to Spain & Seville

A ferry crossing brings you from Morocco to Spain. Your vehicle continues to Seville for the Royal Alcazar, the Giralda Tower, and an evening stroll along the Guadalquivir River.

## Ferry Across the Strait of Gibraltar *(included ticket)*
You board the ferry at Tangier port for the crossing to Tarifa on the Spanish coast. The Strait of Gibraltar narrows to just 14 kilometres at its closest point, and the coastlines of two continents are visible simultaneously from the deck.

## Royal Alcazar of Seville *(included ticket)*
You visit the Royal Alcazar, where Christian kings commissioned Muslim craftsmen to build a palace in the Mudejar tradition. Intricate stucco, carved ceilings, and geometric tilework cover every surface. The formal gardens extend beyond the palace walls with fountains and shaded pavilions.

## Giralda Tower
The Giralda Tower, originally the minaret of Seville's main mosque, rises above the city skyline. Its Almohad-era brickwork and geometric decoration remain clearly visible on the exterior. You pause here for photographs.

## Muslim Quarters & Plaza Espana
You walk through the former Muslim quarters of Seville, where narrow lanes open onto hidden plazas shaded by orange trees. The route continues to Plaza Espana, a sweeping semicircular plaza decorated with ceramic tilework representing each Spanish province.

## Guadalquivir River *(optional)*
An evening stroll along the banks of the Guadalquivir River takes you past the Torre del Oro and the illuminated bridges. The promenade is a popular gathering spot as the city cools in the evening air.

---
**Hotel:** Seville · **Transport:** Ferry from Tangier to Tarifa; private transfer Tarifa to Seville (2hr)

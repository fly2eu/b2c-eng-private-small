# Day 1 — Casablanca & Marrakesh

Your driver meets you at Casablanca Airport for a visit to the Mosque of Hassan II before the three-hour transfer south to Marrakesh.

## Casablanca Airport Arrival
Your driver greets you at Casablanca Mohammed V International Airport and escorts you to your private vehicle. The city's Atlantic coast is visible within minutes of departing the terminal.

## Mosque of Hassan II
You visit the Mosque of Hassan II, one of the largest mosques in the world, set on a promontory overlooking the Atlantic Ocean. The 210-metre minaret dominates Casablanca's skyline. The interior features hand-carved plaster, zellige tilework, and a retractable roof that opens to the sky.

## Transfer to Marrakesh
Your vehicle heads south through the agricultural plains toward Marrakesh. The three-hour transfer follows the motorway through flat farmland before the red walls of the medina and the Atlas Mountains appear on the horizon.

---
**Hotel:** Marrakesh · **Transport:** Private transfer from Casablanca Airport; Casablanca to Marrakesh (3hr)

# Day 3 — Rabat & Transfer to Tangier

The morning explores Rabat's medina, kasbah, and royal monuments before the three-hour transfer north to Tangier on the Strait of Gibraltar.

## Old Medina of Rabat
You walk through the old medina of Rabat, a compact quarter enclosed by Almohad-era walls. The lanes are quieter than those of Marrakesh, with shops selling embroidered textiles, brass lanterns, and leather slippers.

## Kasbah of the Udayas
You enter the Kasbah of the Udayas through its monumental Almohad gateway. Inside, blue-and-white painted lanes lead to a clifftop garden overlooking the mouth of the Bou Regreg River and the Atlantic Ocean beyond. The Andalusian garden within the kasbah walls is planted with orange trees and bougainvillea.

## Hassan Tower & Mausoleum of Muhammad V
You visit the Hassan Tower, the unfinished minaret of a 12th-century Almohad mosque that was intended to be the largest in the Islamic world. Rows of broken columns mark the outline of the original prayer hall. Adjacent stands the Mausoleum of Muhammad V, clad in white marble and green-tiled roofing, guarded by a mounted royal honour guard.

## Rabat Bazaar *(optional)*
Free time allows you to browse the bazaar in the medina. Stalls sell handwoven carpets, pottery from Fez and Safi, and aromatic spices. The relaxed pace of Rabat's souks provides a contrast to larger Moroccan cities.

## Transfer to Tangier
Your vehicle heads north from Rabat to Tangier, a three-hour drive through the green hills of northern Morocco. Tangier sits at the meeting point of the Atlantic and the Mediterranean, with the Spanish coast visible across the strait.

---
**Hotel:** Tangier · **Transport:** Private vehicle within Rabat; Rabat to Tangier (3hr)

# Day 2 — Marrakesh & Transfer to Rabat

A full morning in Marrakesh takes you through the Bahia Palace, Menara Gardens, and the bustling medina before the four-hour transfer north to the capital Rabat.

## Bahia Palace
You visit the Bahia Palace, a 19th-century masterpiece of Moroccan decorative arts. The name means 'palace of the beautiful' and every surface is covered in carved stucco, painted cedarwood, and zellige tilework. Courtyards open onto gardens planted with citrus and jasmine.

## Menara Gardens
You walk through the Menara Gardens, an Almohad-era olive grove surrounding a large reflecting pool. On clear days the snow-capped peaks of the High Atlas are mirrored in the water, creating one of Marrakesh's most photographed scenes.

## Saadian Tombs (Banu Saad Mausoleum)
You enter the Saadian Tombs, the mausoleum of the Banu Saad dynasty. The chamber ceilings are covered in carved cedarwood and gilded muqarnas, while Italian Carrara marble columns frame the central burial hall. The site lay hidden for centuries before its rediscovery.

## Marrakesh Medina & Bazaar
You walk through the souks of the medina, where lanes are organised by craft — leather, metal, textiles, spices. The colours, sounds, and aromas intensify as you move deeper into the market. Artisans work in open workshops along the narrow passages.

## Koutoubia Mosque & Jemaa el-Fnaa
You pass the Koutoubia Mosque, Marrakesh's principal mosque and the model for the Giralda in Seville. The 77-metre minaret is the tallest structure in the medina. Nearby, Jemaa el-Fnaa square fills with storytellers, musicians, and food stalls as the afternoon progresses.

## Transfer to Rabat
Your vehicle departs Marrakesh for the four-hour transfer north to Rabat, the administrative capital of Morocco. The route follows the motorway through the plains of central Morocco.

---
**Hotel:** Rabat · **Transport:** Private vehicle within Marrakesh; Marrakesh to Rabat (4hr)

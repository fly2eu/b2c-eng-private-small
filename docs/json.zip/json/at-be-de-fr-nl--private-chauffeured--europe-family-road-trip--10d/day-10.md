## Day 10 — Salzburg Day Trip & Onward

A cross-border finale — Mozart's birthplace and back, with your chauffeur handling the alpine drive.

**Transfer to Salzburg**
Your vehicle departs for the one-hundred-and-fifty-kilometre drive southeast from Munich across the Austrian border to Salzburg. The route hugs the foothills of the Alps, and the journey takes roughly ninety minutes of comfortable riding.

**Salzburg Old Town**
You explore Salzburg's UNESCO-listed old town, a Baroque jewel set between the Salzach River and the Mönchsberg hill. Getreidegasse, the narrow shopping street where Mozart was born, leads you past wrought-iron guild signs to the Residenzplatz and the imposing Hohensalzburg Fortress perched above.

**Return to Munich**
Your chauffeur drives you the one hundred and fifty kilometres back to Munich in the afternoon. The return journey retraces the alpine motorway, bringing the ten-day European family journey full circle in the Bavarian capital.

*Your chauffeur handles the approximately 150 km each way between Munich and Salzburg (1.5 hours). Return to Munich for onward travel or continuation of the trip.*
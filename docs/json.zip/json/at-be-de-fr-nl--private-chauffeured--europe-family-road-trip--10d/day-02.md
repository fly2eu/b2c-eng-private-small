## Day 2 — Paris Highlights

A full day devoted to the French capital's most iconic landmarks, with your chauffeur navigating between stops.

**Louvre Museum (Exterior)**
Your vehicle departs for the Louvre, the world's largest art museum. Even from the exterior, the glass pyramid set against the classical Cour Napoléon facade makes for a striking tableau. The surrounding Tuileries Garden offers a pleasant morning walk.

**Arc de Triomphe**
Your chauffeur brings you to the Place Charles de Gaulle where the Arc de Triomphe commands the junction of twelve radiating avenues. Commissioned by Napoleon in 1806, the monument honours those who fought for France, with intricate relief sculptures covering its pillars.

**Champs-Élysées**
From the Arc you stroll down the Champs-Élysées, one of the world's most celebrated avenues. Tree-lined and nearly two kilometres long, it stretches toward the Place de la Concorde, flanked by flagship stores, grand cafés, and terraces perfect for a family lunch stop.

**Montmartre & Sacré-Cœur Basilica**
Your vehicle drops you at the foot of Montmartre. You climb the winding lanes past portrait painters and tiny cafés. At the summit, the Romano-Byzantine Sacré-Cœur Basilica gleams white against the sky, and from its terrace a panorama stretches across the entire city — a fitting close to your Paris explorations. Your chauffeur waits at the base.

*Your chauffeur drives you between landmarks. Walking sections at the Louvre, Champs-Élysées, and Montmartre.*
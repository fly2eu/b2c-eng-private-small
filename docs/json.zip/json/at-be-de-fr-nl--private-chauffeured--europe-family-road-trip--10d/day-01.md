## Day 1 — Arrival in Paris

Your European family journey begins at Charles de Gaulle Airport, where your private chauffeur meets you at arrivals.

**CDG Airport Arrival & Chauffeur Transfer**
Your private vehicle meets you at arrivals. Your chauffeur loads the luggage and drives south into Paris — roughly forty-five minutes through the northern suburbs before the city centre reveals itself. You settle into the comfort of the back seat after a long flight.

**Hotel Check-In (Charenton-le-Pont Area)**
You check in to your hotel in the Charenton-le-Pont area, just southeast of central Paris. Your chauffeur will be on standby for the evening programme whenever you are ready.

**Notre-Dame Cathedral**
Your vehicle departs for the Île de la Cité, where Notre-Dame Cathedral stands. The Gothic masterpiece, with its flying buttresses and rose windows, has anchored the spiritual centre of Paris since the twelfth century. Recently restored, it gleams under evening light while your chauffeur waits nearby.

**Eiffel Tower**
Your chauffeur drives you to the Champ de Mars for the Eiffel Tower. Rising three hundred and thirty metres above the park, the iron lattice structure is mesmerising at sunset when warm light catches the metalwork before the sparkling light display begins on the hour.

**Seine River Cruise**
You round off the evening with a cruise along the Seine. The boat glides past illuminated bridges and landmarks on both banks — the Musée d'Orsay, the Louvre, and Notre-Dame — offering a tranquil first encounter with the city from the water. Your chauffeur collects you at the dock afterward.

*Your private chauffeur meets you at CDG Airport and transfers you to your hotel near Charenton-le-Pont (approximately 45 minutes). Evening sightseeing with chauffeur and on foot.*
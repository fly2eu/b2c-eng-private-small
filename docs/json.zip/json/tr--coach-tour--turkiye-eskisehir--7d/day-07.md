# Day 7 — Departure

**Overnight:** —
**Meals:** Breakfast (included)

---

## Transfer to Airport & Domestic Flight to Istanbul
*transport · NOT included · approx. EUR 55–60 per person*

After breakfast, the group transfers to the local airport in the Cappadocia region for the domestic flight back to Istanbul. Please note that this domestic flight is not included in the tour price and costs approximately EUR 55–60 per person — passengers should arrange and confirm their booking in advance with the tour guide or travel agent. Onward international departures proceed from Istanbul, bringing the Türkiye Civilisations Tour to a close after seven days of discovery across four of the country's most captivating destinations.

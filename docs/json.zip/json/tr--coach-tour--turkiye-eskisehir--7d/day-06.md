# Day 6 — Cappadocia Full Day

**Overnight:** Cappadocia — Mustafa Hotel (5★)
**Meals:** Breakfast · Lunch · Dinner (all included)

---

## Hot Air Balloon *(Optional)*
*activity · not included · approx. USD 150–200 per person*

Groups with an appetite for adventure can arrange an optional hot air balloon flight over the Cappadocian valleys at dawn. Drifting silently above the fairy chimneys and rippled rock formations as the sun rises is widely regarded as one of the most extraordinary experiences in all of Türkiye. Bookings are subject to weather conditions and should be arranged in advance through the tour guide.

---

## Uçhisar Fortress
*monument · included*

The group climbs to Uçhisar Fortress, the highest natural point in Cappadocia, where a massive volcanic rock cone has been carved over centuries into a multi-level fortified complex. The panoramic views from the summit take in a vast sweep of fairy chimneys, vine-covered valleys, and distant volcanic peaks that define the region's extraordinary character. The fortress itself tells the story of the communities who shaped and sheltered within this remarkable landscape.

---

## Love Valley
*landscape · included*

The group walks through Love Valley, where centuries of volcanic eruption, wind, and water erosion have sculpted the soft tuff rock into a dense forest of tall columnar formations. The scale and surreal geometry of the valley floor make it one of Cappadocia's most visually striking geological spectacles. The group moves through at a comfortable pace, with ample time for photographs and appreciation of the landscape.

---

## Avanos Pottery Town
*neighbourhood · included*

The group visits Avanos, a town whose pottery tradition stretches back to Hittite times and is sustained to this day by the rich red clay deposits found along the banks of the Kızılırmak River. Local master potters still throw and glaze vessels using techniques passed down through generations, and the group has the opportunity to watch the craft in practice and browse the workshops. Avanos is also known for its hand-woven textiles and copper-worked goods.

---

## Kaymaklı Underground City
*archaeological_site · included*

The group descends into Kaymaklı Underground City, one of Cappadocia's most remarkable ancient sites, carved deep into the volcanic rock to create a multi-level subterranean refuge capable of sheltering thousands of inhabitants. Winding tunnels connect stables, storage chambers, ventilation shafts, and communal spaces across at least eight underground floors, revealing the extraordinary ingenuity of the communities who sought safety here during times of conflict. The guided descent brings this hidden world to life in vivid and memorable detail.

---

## Evening Walk and Shopping
*shopping · included*

The group enjoys a relaxed evening walk through Cappadocia's quiet village lanes, with time set aside for browsing the local shops stocked with hand-painted ceramics, woven kilims, onyx carvings, and regional food products. The cool evening air and the amber glow of the stone streets make for a peaceful and unhurried close to the day.

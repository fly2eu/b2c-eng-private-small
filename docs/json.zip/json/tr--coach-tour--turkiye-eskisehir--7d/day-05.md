# Day 5 — Eskişehir → Cappadocia

**Overnight:** Cappadocia — Mustafa Hotel (5★)
**Meals:** Breakfast · Lunch · Dinner (all included)

---

## Sazova Park & Fairy Tale Castle
*garden · included*

The group visits Sazova Science, Culture and Art Park, a vast green space that brings together a science centre, planetarium, and zoo within beautifully landscaped grounds on the edge of Eskişehir. The park's centrepiece is its Fairy Tale Castle, designed in the style of a European storybook fortress and now one of the city's most recognisable landmarks. It is a joyful, imaginative space that reflects Eskişehir's well-earned reputation for creative civic investment.

---

## Tuz Gölü (Salt Lake)
*landscape · included*

The group stops at Tuz Gölü, one of the largest salt lakes in the world, whose vast white flats stretch to the horizon and create a shimmering, mirror-like surface under open skies. The lake sits at the geographic heart of the Anatolian plateau and serves as a remarkable natural waypoint on the journey south to Cappadocia. During the right seasons, thousands of flamingos wade through its shallow saline shallows, adding a vivid and unexpected burst of life to the pale white expanse.

---

## Turkish Night Show with Dinner
*activity · included · dinner served during show*

The group attends a Turkish Night Show, an evening performance celebrating traditional music, folk dance, and regional costume from across Türkiye's diverse cultural landscape. Dinner is served throughout the show, with a spread of Anatolian dishes accompanying the performances. It is an entertaining and flavourful welcome to the Cappadocia leg of the journey.

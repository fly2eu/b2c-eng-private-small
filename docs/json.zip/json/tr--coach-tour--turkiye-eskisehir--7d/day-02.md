# Day 2 — Istanbul City Tour

**Overnight:** Istanbul — Innpera Hotel (4★)
**Meals:** Breakfast · Lunch · Dinner (all included)

---

## Hippodrome
*archaeological_site · included*

The group visits the Hippodrome, the ancient chariot-racing track that once stood at the heart of Byzantine Constantinople. Centuries of empire-building are written into this open square, whose ancient monuments — the Obelisk of Theodosius, the Serpent Column, and the Walled Obelisk — still stand exactly where they were placed. It is one of the oldest continuously occupied public spaces in the world, and a vivid reminder of the city's layered past.

---

## Sultanahmet Square
*neighbourhood · included*

The group explores Sultanahmet Square, the historic crossroads where Byzantine and Ottoman civilisations left their deepest marks side by side. Grand mosques, ancient palaces, and millennia-old monuments cluster together here in a concentration found nowhere else on earth. The square rewards slow walking and careful looking, with stories embedded in every stone.

---

## Hagia Sophia
*religious_site · included*

The group visits the Hagia Sophia, a site of profound historical and spiritual significance that has stood for nearly fifteen centuries. Built as a cathedral in 537 AD and later converted to a mosque, it represents one of humanity's greatest architectural and religious achievements. Its soaring central dome, shimmering mosaics, and monumental scale have drawn reverence from visitors of every faith across the ages. The group takes time to appreciate both the grandeur of the space and the weight of its history.

---

## Egyptian Market (Spice Bazaar)
*market · included*

The group wanders through the Egyptian Market, one of Istanbul's oldest and most aromatic trading halls. Dating to the Ottoman era, the vaulted L-shaped corridors overflow with spices, dried fruits, Turkish delight, nuts, and local specialities that have been traded here for centuries. The colours, scents, and sounds make for an immersive and lively experience at the edge of the old city.

---

## Bosphorus Cruise with Dinner
*activity · included · dinner served on board*

The group boards a vessel for a scenic Bosphorus Cruise, gliding between the European and Asian shores as the city's famous skyline unfolds on both sides. Dinner is served on board, with views of illuminated waterfront palaces, historic mosques, and the great suspension bridges spanning the strait. It is a fitting end to a full day in one of the world's most remarkable cities.

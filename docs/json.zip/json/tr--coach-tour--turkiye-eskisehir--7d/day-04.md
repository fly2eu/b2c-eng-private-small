# Day 4 — Bursa → Eskişehir

**Overnight:** Eskişehir — Rota Business Hotel (4★)
**Meals:** Breakfast · Lunch · Dinner (all included)

---

## Koza Han (Silk Market)
*market · included*

The group visits Koza Han, the Ottoman silk market built in 1491 by Sultan Bayezid II as a key node on the ancient Silk Road trade network. Its two-storey arcaded courtyard, centred on a small Ottoman fountain mosque, has been in continuous use for over five centuries and still operates as a market for silk goods, jewellery, and local crafts. The building stands as one of the finest surviving examples of Ottoman commercial architecture anywhere in Türkiye.

---

## Ulu Cami (Grand Mosque)
*religious_site · included*

The group enters Ulu Cami, the Grand Mosque of Bursa, an early Ottoman masterpiece completed between 1396 and 1399 under Sultan Bayezid I. Twenty domes of varying sizes cover the interior, and monumental Qur'anic calligraphy inscribed in large panels across the walls creates an atmosphere of profound stillness and reverence. It is among the most important mosques in Turkish history and a cornerstone of Ottoman religious architecture.

---

## Bursa Panorama Museum
*museum · included*

The group explores the Bursa Panorama Museum, where immersive 360-degree paintings and three-dimensional displays bring the founding years of the Ottoman Empire vividly to life. The museum presents the story of early Bursa — its conquest, its court culture, and its commercial flowering — in an engaging format that connects visitors directly to the city's extraordinary heritage.

---

## Uludağ Mountain Cable Car
*activity · included*

The group ascends Uludağ by cable car, rising above the city rooftops into forested mountain slopes and alpine scenery. At the summit, sweeping views reach across the Bursa plain and, on clear days, extend to the distant Sea of Marmara. The cable car journey itself, passing over dense green canopy and rocky ridgelines, is a highlight in its own right.

---

## Transfer to Eskişehir
*transport · included*

The group travels by coach to Eskişehir, a progressive university city known for its colourful Ottoman heritage district and relaxed riverside atmosphere. The transfer marks the move from Bursa's historic gravity into a livelier, more contemporary Anatolian city.

---

## Odunpazarı Historical Houses
*neighbourhood · included*

The group walks through the Odunpazarı district, where beautifully restored Ottoman houses from the 16th to the 19th century line cobblestone streets in a vivid palette of terracotta, ochre, and cream. The neighbourhood is one of the best-preserved examples of traditional Anatolian urban architecture in the country, its timber-framed upper storeys and carved wooden details reflecting centuries of local craftsmanship.

---

## Porsuk River Waterfront
*neighbourhood · included*

The group enjoys a guided city tour along the banks of the Porsuk River, Eskişehir's lively central promenade. Bridges, open plazas, and a sociable, European-flavoured atmosphere make this stretch one of the city's most cherished public spaces, and a pleasant place for the group to wind down after a full day of sightseeing.

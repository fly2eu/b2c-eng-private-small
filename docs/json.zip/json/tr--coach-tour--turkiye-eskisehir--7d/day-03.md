# Day 3 — Istanbul → Bursa

**Overnight:** Bursa — Bursa Palas Hotel (4★)
**Meals:** Breakfast · Lunch · Dinner (all included)

---

## Galata Tower
*monument · included*

The group visits the Galata Tower, a medieval stone landmark that has overlooked Istanbul's waterfront since the 14th century. Built by the Genoese as a watchtower at the northern edge of their colony, it remains one of the city's most distinctive silhouettes. From the observation gallery near the top, the group takes in sweeping panoramic views across the Golden Horn, the historic peninsula, and the Bosphorus beyond.

---

## Taksim Square
*neighbourhood · included*

The group passes through Taksim Square, the modern civic heart of Istanbul and its principal gathering point. This broad, open plaza marks the centre of the Beyoğlu district and acts as the departure point for much of the city's contemporary cultural and commercial life.

---

## İstiklal Street
*neighbourhood · included*

The group strolls along İstiklal Street, Istanbul's celebrated pedestrian boulevard stretching over a kilometre through the Beyoğlu district. Art galleries, independent bookshops, historic arcades, and the iconic red nostalgic tram all line this lively thoroughfare. The street's layered architecture — neoclassical, art nouveau, and modernist buildings standing side by side — makes every block worth a closer look.

---

## Ortaköy Waterfront at Sunset
*viewpoint · included*

The group pauses at Ortaköy at sunset to take in one of Istanbul's most beloved waterfront scenes. The ornate Ortaköy Mosque sits right at the water's edge, with the great Bosphorus bridge arching dramatically overhead — a composition that perfectly captures Istanbul's marriage of the historic and the monumental. The timing at dusk adds warmth and atmosphere to the visit.

---

## Transfer to Bursa
*transport · included*

The group boards the coach for the transfer to Bursa, the first Ottoman capital nestled at the foot of Uludağ Mountain. The journey marks the transition from cosmopolitan Istanbul into the heartland of early Ottoman history, where tomorrow's sights carry an even deeper historical significance.

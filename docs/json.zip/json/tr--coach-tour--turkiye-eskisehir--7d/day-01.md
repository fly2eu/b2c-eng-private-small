# Day 1 — Arrival in Istanbul

**Overnight:** Istanbul — Innpera Hotel (4★)
**Meals:** —

---

## Airport Arrival & Transfer
*transport · included*

The group arrives at Istanbul Airport and is met by the tour guide for a smooth, organised transfer to the hotel. This first leg sets the tone for a well-managed journey through Türkiye's most celebrated destinations, with the guide on hand to welcome everyone and answer any questions before the tour begins in earnest the following morning.

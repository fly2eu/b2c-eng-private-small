# Day 2 — Paris Cultural Day

A full day devoted to deeper exploration of the French capital. The morning visits the Panthéon in the Latin Quarter, followed by a choice of optional excursions — the world-renowned Louvre Museum, the opulent Palace of Versailles, or a day out at Disneyland Paris.

## Panthéon
The group visits the Panthéon in the heart of the Latin Quarter, a neoclassical monument modelled on the Roman original. The vast interior, crowned by a painted dome, houses the tombs of many of France's most celebrated figures. Foucault's pendulum, suspended from the dome, demonstrates the rotation of the earth in real time.

## Louvre Museum *(optional)*
An optional visit to the Louvre Museum, the largest art museum in the world. The collection spans thousands of years, from Egyptian antiquities to Renaissance masterpieces. A guided tour highlights key works and navigates the museum's vast galleries efficiently.

## Palace of Versailles *(optional)*
An optional excursion takes the group to the Palace of Versailles, approximately 80 kilometres from central Paris. The Hall of Mirrors, the grand state apartments, and the immaculately landscaped formal gardens make this one of France's most visited monuments.

## Disneyland Paris *(optional)*
An optional full-day excursion to Disneyland Paris is available for those who prefer a theme-park experience. The park is located approximately 40 kilometres east of central Paris.

---
**Hotel:** Paris · **Transport:** AC coach, local driving (~80km depending on optional excursion)

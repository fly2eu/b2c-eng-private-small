# Day 10 — Vatican and Departure

The final morning brings the group to the Vatican, the smallest independent state in the world and the spiritual centre of the Catholic faith. After visiting St. Peter's Basilica and the surrounding piazza, the coach transfers the group to Fiumicino Airport for departing flights.

## St. Peter's Basilica & Square
The group visits St. Peter's Square, designed by Bernini with its sweeping colonnades embracing the piazza, and enters St. Peter's Basilica, the largest church in the world. Inside, the vast nave leads past Michelangelo's Pietà to the baldachin over the papal altar and the soaring dome above. A guided tour explains the history and art within.

## Optional Vatican Museums *(optional)*
An optional visit to the Vatican Museums takes the group through galleries of classical sculpture, Renaissance painting, and tapestries, culminating in the Sistine Chapel with Michelangelo's ceiling frescoes and the Last Judgement on the altar wall.

## Transfer to Fiumicino Airport *(included)*
The coach transfers the group from central Rome to Leonardo da Vinci-Fiumicino Airport for departing flights. The journey takes approximately forty-five minutes depending on traffic.

---
**Hotel:** — · **Transport:** AC coach to Fiumicino Airport

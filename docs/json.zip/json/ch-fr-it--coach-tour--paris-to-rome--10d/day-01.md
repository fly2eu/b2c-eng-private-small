# Day 1 — Arrival in Paris

The group arrives at Charles de Gaulle Airport and boards the coach for an introductory circuit of central Paris. The route threads past the city's most famous landmarks, giving everyone an overview before deeper exploration begins the following day.

## CDG Airport Pickup *(included)*
The group meets at Charles de Gaulle Airport and boards the air-conditioned coach. A tour leader welcomes the group and provides an overview of the ten-day itinerary as the coach heads into central Paris.

## Montmartre & Sacré-Cœur Basilica
The group ascends to the hilltop neighbourhood of Montmartre, where the white-domed Sacré-Cœur Basilica offers one of the finest panoramic views across Paris. A guided walk passes the artists' square at Place du Tertre and the narrow lanes that once drew painters and poets to the quarter.

## Arc de Triomphe & Champs-Élysées
The coach passes the Arc de Triomphe at the western end of the Champs-Élysées. The group stops for photographs of the arch and a short stroll along the famous boulevard, lined with grand terraces and chestnut trees.

## Notre-Dame Cathedral
On the Île de la Cité, the group visits Notre-Dame Cathedral, a landmark of French Gothic architecture. The carved stone façade, twin bell towers, and flying buttresses are viewed from the plaza, with time to admire the detail of the western portals.

## Eiffel Tower Photo Stop
The group stops at the Trocadéro esplanade for the best unobstructed view of the Eiffel Tower. The iron lattice structure is framed by the fountains and terraced gardens of the Palais de Chaillot, providing an ideal photo opportunity.

## Galeries Lafayette
The group visits Galeries Lafayette, the legendary Parisian department store on Boulevard Haussmann. The ornate Art Nouveau dome and sweeping interior balconies are worth seeing in their own right, and free time is available for browsing the many designer and artisan boutiques inside.

---
**Hotel:** Paris · **Transport:** AC coach, local Paris driving (~50km)

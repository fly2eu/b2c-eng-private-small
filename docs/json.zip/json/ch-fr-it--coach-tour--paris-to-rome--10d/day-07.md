# Day 7 — Milan Highlights and Venice

The morning showcases Milan's architectural crown jewels before the coach heads east across the Lombardy plain to Venice. By afternoon, the group is walking the atmospheric lanes and waterways of one of the world's most extraordinary cities.

## Milan Cathedral (Duomo)
The group visits Milan's Duomo, the largest Gothic cathedral in Italy and one of the largest churches in the world. The exterior bristles with over 3,400 statues, 135 spires, and a gilded Madonnina crowning the highest point. The group views the marble façade from the piazza, with time to appreciate the scale and intricacy of the stonework.

## Galleria Vittorio Emanuele II
Adjacent to the Duomo, the group enters the Galleria Vittorio Emanuele II, a 19th-century glass-vaulted shopping arcade often called the drawing room of Milan. The mosaic floors, iron-and-glass roof, and high-end boutiques create one of Europe's most elegant retail spaces. Free time is available for browsing or refreshments at one of the historic cafés.

## Transfer to Venice *(included)*
The coach departs Milan and heads east across the Lombardy plain, a journey of approximately 270 kilometres taking three to three and a half hours. The group arrives on the Venetian mainland in the early afternoon.

## St. Mark's Square
The group crosses to the island by water taxi or vaporetto and arrives at St. Mark's Square, the ceremonial heart of Venice. The piazza is enclosed by the ornate façade of St. Mark's Basilica, the Campanile bell tower, and the arcaded Procuratie buildings. A guided tour explains the square's role as the centre of the Venetian Republic for over a thousand years.

## Doge's Palace
The group views the Doge's Palace from the waterfront, its pink-and-white marble façade a masterpiece of Venetian Gothic architecture. The palace served as the seat of government and the private residence of the Doge for centuries.

## Rialto Bridge
The walking route leads through narrow calli and across small bridges to the Rialto Bridge, the oldest and most famous of the four bridges spanning the Grand Canal. The group pauses on the bridge for views along the canal in both directions, lined with palazzi and busy with water traffic.

## Optional Gondola Ride *(optional)*
An optional shared gondola ride takes a small group along the quieter back canals of Venice, passing beneath low stone bridges and alongside the foundations of centuries-old palazzi. The ride lasts approximately thirty minutes.

---
**Hotel:** Venice/Mestre · **Transport:** AC coach from Milan to Venice (270km, 3-3.5hr); water taxi/vaporetto in Venice

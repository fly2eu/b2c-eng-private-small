# Day 4 — Into the Swiss Alps

The group crosses into Switzerland and enters the Bernese Oberland, one of the most dramatic Alpine landscapes in Europe. The morning is spent in the Lauterbrunnen Valley, a glacial trough flanked by sheer cliffs and cascading waterfalls, before the coach climbs to the mountain village of Grindelwald.

## Transfer to Lauterbrunnen *(included)*
The coach departs Colmar and crosses the Swiss border, covering approximately 231 kilometres in three and a half hours. The road climbs steadily through the Jura foothills and into the heart of the Bernese Alps.

## Lauterbrunnen Valley
The group arrives in the Lauterbrunnen Valley, a deep glacial U-shaped trough walled by 300-metre vertical cliffs on either side. Seventy-two waterfalls cascade from the rock faces above, including the Staubbach Falls that plunge freely beside the village. A walking tour follows the valley floor, with views of snow-capped peaks and alpine meadows.

## Optional Jungfraujoch Excursion *(optional)*
An optional excursion by cogwheel railway ascends to Jungfraujoch, the highest railway station in Europe at 3,454 metres. The summit offers views across the Aletsch Glacier, the longest in the Alps, and on clear days the panorama extends to the Black Forest and the Vosges mountains. An ice palace carved inside the glacier and a viewing platform are included at the top.

## Transfer to Grindelwald *(included)*
The coach covers the short 16-kilometre journey from Lauterbrunnen to Grindelwald in approximately thirty minutes, climbing through alpine pastures beneath the north face of the Eiger.

---
**Hotel:** Grindelwald · **Transport:** AC coach from Colmar to Lauterbrunnen (231km, 3.5hr), Lauterbrunnen to Grindelwald (16km, 30min)

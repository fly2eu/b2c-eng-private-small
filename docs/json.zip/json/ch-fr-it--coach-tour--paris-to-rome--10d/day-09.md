# Day 9 — Florence to Rome via Pisa

The group heads south from Florence towards Rome, with an optional detour to Pisa and its famous leaning tower. The afternoon arrives in the Eternal City, where the ancient and the modern sit side by side across the seven hills.

## Optional Leaning Tower of Pisa *(optional)*
An optional stop in Pisa brings the group to the Piazza dei Miracoli, where the Leaning Tower tilts at its famous angle alongside the Cathedral and Baptistery. The group has time for the classic photo opportunity and to admire the white marble ensemble on the manicured green lawn.

## Transfer to Rome *(included)*
The coach continues south from Florence (or Pisa) to Rome, a journey of approximately 280 kilometres taking three to three and a half hours through the rolling Tuscan and Umbrian countryside.

## Colosseum
The group visits the Colosseum, the largest amphitheatre ever built. The massive travertine and concrete structure once held 50,000 spectators. A guided tour from the exterior explains the engineering and history of the arena, with views through the archways to the underground chambers below.

## Roman Forum
Adjacent to the Colosseum, the group views the Roman Forum from the elevated walkway. The ruined temples, triumphal arches, and basilicas spread across the valley floor trace the political and religious heart of ancient Rome.

## Trevi Fountain
The walking route leads through the narrow streets of central Rome to the Trevi Fountain, the largest Baroque fountain in the city. The sculptural composition of Neptune flanked by sea horses and tritons fills the entire width of the Palazzo Poli behind it. The group pauses to take in the spectacle and toss a coin into the water.

## Spanish Steps
The group continues to the Spanish Steps, the monumental 135-step stairway connecting the Piazza di Spagna below to the Trinità dei Monti church above. The steps and surrounding area are one of Rome's most popular gathering spots, offering views across the rooftops of the historic centre.

---
**Hotel:** Rome · **Transport:** AC coach from Florence to Rome (280km, 3-3.5hr; via Pisa adds ~80km)

# Day 8 — Venice to Florence

The group departs the Venetian lagoon and travels south to Florence, the cradle of the Renaissance. An afternoon walking tour covers the city's most celebrated landmarks, from the terracotta dome of the cathedral to the medieval shop-lined Ponte Vecchio.

## Transfer to Florence *(included)*
The coach departs Venice and heads south through the Emilia-Romagna region and over the Apennine passes into Tuscany. The journey covers approximately 260 kilometres and takes three to three and a half hours.

## Piazzale Michelangelo
The coach climbs to Piazzale Michelangelo on the south bank of the Arno for the definitive panoramic view of Florence. The terracotta dome of the cathedral, the tower of the Palazzo Vecchio, and the bridges of the Arno spread out below, framed by the Tuscan hills beyond. The group has time for photographs from multiple vantage points.

## Ponte Vecchio
The group walks across the Ponte Vecchio, the medieval stone bridge lined with jewellers' and goldsmiths' shops that has spanned the Arno since 1345. Views from the bridge take in the river and the surrounding palaces on either bank.

## Florence Cathedral (Duomo)
The group visits the Piazza del Duomo, where the Cathedral of Santa Maria del Fiore dominates the skyline with its vast terracotta dome engineered by Brunelleschi. The exterior is clad in panels of white, green, and pink marble. Adjacent stand the Baptistery, with its gilded bronze doors, and Giotto's Campanile.

## Optional Uffizi Gallery *(optional)*
An optional visit to the Uffizi Gallery, one of the world's foremost art museums. The collection includes masterpieces by Botticelli, Leonardo da Vinci, Raphael, and Caravaggio, housed in a 16th-century palace overlooking the Arno.

---
**Hotel:** Florence · **Transport:** AC coach from Venice to Florence (260km, 3-3.5hr)

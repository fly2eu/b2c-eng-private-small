# Day 5 — Rhine Falls and Zurich

The group descends from the mountains and heads northeast to the Rhine Falls, the largest waterfall in Europe by volume. After taking in the thundering cascade, the coach continues to the lakeside city of Zurich, with an optional stop at the Lindt chocolate experience along the way.

## Transfer to Rhine Falls *(included)*
The coach departs Grindelwald and heads north, covering approximately 173 kilometres in two and a half hours. The landscape transitions from high alpine valleys to the rolling green hills of northern Switzerland.

## Rhine Falls
The group visits the Rhine Falls, where the full width of the Rhine River plunges 23 metres over a limestone ledge in a wall of white spray. Viewing platforms on both sides of the river bring visitors close to the cascade, and the roar of the water is audible from a considerable distance. Approximately one hour is allocated for the visit.

## Optional Lindt Home of Chocolate *(optional)*
An optional visit to the Lindt Home of Chocolate in Kilchberg, on the shores of Lake Zurich. The interactive museum traces the history of chocolate from cacao bean to finished product, and features the world's tallest chocolate fountain at over nine metres. Tastings are included.

## Transfer to Zurich *(included)*
The coach continues approximately 46 kilometres south to Zurich, arriving at the hotel in the late afternoon.

---
**Hotel:** Zurich · **Transport:** AC coach from Grindelwald to Rhine Falls (173km, 2.5hr), Rhine Falls to Zurich (46km, 1hr)

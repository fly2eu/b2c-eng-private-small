# Day 3 — Eastward to Alsace

The group leaves Paris behind and heads east across France to the Alsace region. After a five-and-a-half-hour drive through the rolling countryside, the charming half-timbered town of Colmar awaits, with its flower-lined canals and colourful façades.

## Transfer to Colmar *(included)*
The coach departs Paris for the long drive east to Colmar, covering approximately 437 kilometres in five and a half hours. The route passes through the Champagne and Lorraine regions before descending into the Rhine Valley and the vineyards of Alsace.

## Colmar Old Town
The group explores Colmar on foot, wandering through the Petite Venise quarter where half-timbered houses in pastel shades lean over narrow canals. The cobbled streets of the old town pass the Maison des Têtes, the Koïfhus, and the Collegiate Church of Saint Martin. Free time is available to browse the local shops selling Alsatian pottery, gingerbread, and regional produce.

---
**Hotel:** Colmar · **Transport:** AC coach from Paris to Colmar (437km, 5.5hr)

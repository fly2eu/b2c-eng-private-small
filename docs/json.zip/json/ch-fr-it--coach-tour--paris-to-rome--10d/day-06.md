# Day 6 — Lucerne and Onward to Milan

The morning is spent in Lucerne, one of Switzerland's most picturesque cities, set on the shores of Lake Lucerne beneath snow-dusted peaks. After exploring the old town and its famous covered bridge, the coach crosses the Gotthard Pass into Italy and arrives in Milan by evening.

## Transfer to Lucerne *(included)*
The coach departs Zurich for the short drive southwest to Lucerne, a journey of approximately fifty kilometres along the northern shore of Lake Zurich.

## Chapel Bridge & Old Town
The group crosses the Chapel Bridge, Europe's oldest covered wooden bridge, dating from the 14th century. Triangular paintings beneath the roof depict scenes from Swiss history. On the far side, the old town's cobbled squares, painted façades, and fountain-lined plazas are explored on a guided walking tour. The Lion Monument, carved into a rockface to commemorate Swiss Guards, is included in the route.

## Transfer to Milan *(included)*
The coach departs Lucerne and heads south, crossing the Swiss-Italian border via the Gotthard route. The journey covers approximately 230 kilometres and takes three to three and a half hours, descending from the alpine passes into the flat plains of Lombardy.

---
**Hotel:** Milan · **Transport:** AC coach from Zurich to Lucerne (~50km), Lucerne to Milan (~230km, 3-3.5hr)

# Day 4 — Mountain Air at Uludağ & Colour in Eskişehir

Your vehicle departs Istanbul and heads south toward Uludağ, where panoramic views await at elevation — with a real chance of early snowfall in November. The afternoon continues to Eskişehir for a relaxed exploration of its Porsuk River promenade and charming Ottoman heritage quarter.

## Drive Istanbul to Uludağ
Your vehicle departs Istanbul and drives south toward Bursa, arriving at the Uludağ mountain area in approximately three hours. The road descends from the Marmara plateau into the greener valleys of the Bursa region, with Uludağ's snow-capped profile growing steadily on the horizon.

## Uludağ Mountain
Your family reaches the upper slopes of Uludağ, northwestern Türkiye's highest peak at 2,543 metres. Panoramic views sweep across the Bursa plain and the distant Sea of Marmara, and in November there is a strong chance of fresh snowfall dusting the pine forests on the upper ridges — a memorable moment for the family.

## Drive to Eskişehir
Your vehicle continues from Uludağ toward Eskişehir, approximately two and a half hours further east. The guide provides background on the city's history as a university town and its long tradition of Meerschaum pipe craftsmanship during the drive.

## Odunpazarı Historical Houses
Your family explores Odunpazarı, Eskişehir's lovingly restored historic district of Ottoman timber houses painted in vivid reds, blues, and ochres. Narrow cobblestone streets wind between 16th-to-19th-century facades, with artisan workshops and small cafés occupying the ground floors at a pleasant walking pace.

## Porsuk River & City Exploration
Your guide takes the family along the Porsuk River promenade, where pedestrian bridges, riverside gardens, and open-air seating create an unhurried atmosphere ideal for an afternoon stroll. The city's large student population gives it a creative and welcoming energy.

---
**Hotel:** Eskişehir · **Transport:** Private vehicle Istanbul → Uludağ (~3hr) → Eskişehir (~2.5hr) · **Meals:** Breakfast

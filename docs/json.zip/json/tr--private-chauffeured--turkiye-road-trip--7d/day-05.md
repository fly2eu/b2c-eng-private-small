# Day 5 — Drive to Cappadocia: Fairy Chimneys & Underground Cities

Your vehicle departs Eskişehir for the scenic drive south into the volcanic heart of Cappadocia. The afternoon explores the iconic Göreme landscape and the commanding Uçhisar Castle before a descent into the remarkable multi-level tunnels of Derinkuyu Underground City.

## Drive to Cappadocia
Your vehicle departs Eskişehir on the five-hour drive southeast to Cappadocia, or approximately seven hours if the route passes through Konya. The landscape transitions gradually from flat Anatolian steppe to pale volcanic valleys and sculpted rock formations as Cappadocia comes into view.

## Göreme — Fairy Chimney Landscape
Your family arrives in Göreme, the village at the heart of Cappadocia's celebrated landscape of fairy chimneys and rock-cut churches. The soft volcanic tuff has been carved over centuries into homes, chapels, and entire monasteries, many decorated with Byzantine frescoes. The setting is unlike anywhere else in the world.

## Uçhisar Castle
Your guide leads the family to Uçhisar Castle, the highest point in Cappadocia and a natural rock fortress honeycombed with carved rooms and passageways. The summit delivers a panoramic view stretching across the valleys, fairy chimneys, and distant volcanic peaks of the region.

## Derinkuyu Underground City
Your family descends into Derinkuyu Underground City, the deepest of Cappadocia's ancient subterranean refuges, with levels reaching approximately 85 metres below the surface. Narrow tunnels connect chambers that served as living quarters, stables, kitchens, communal halls, and places of worship for thousands of inhabitants who sheltered here from invasion across the centuries.

---
**Hotel:** Cappadocia · **Transport:** Private vehicle Eskişehir → Cappadocia (~5hr direct or ~7hr via Konya) · **Meals:** Breakfast

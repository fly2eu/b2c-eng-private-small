# Day 2 — Istanbul: Old City & the Grand Bazaar

Your vehicle takes the family through the historic Sultanahmet district at a comfortable pace, with time to linger at each landmark without the constraints of a group timetable. The day moves from the soaring nave of Hagia Sophia to the layered Ottoman rooms of Topkapı Palace and the labyrinthine lanes of the Grand Bazaar.

## Hagia Sophia
Your guide leads the family into Hagia Sophia, a masterpiece of world architecture and one of the most revered sacred spaces on earth. The immense dome spans over 31 metres and rests on a ring of arched windows that flood the interior with shifting light, while ancient marble columns and sweeping calligraphy panels fill every surface with centuries of craftsmanship. The building has served as a place of worship for nearly 1,500 years and continues to do so today.

## Blue Mosque (Sultan Ahmed Mosque)
Your family visits the Sultan Ahmed Mosque, known as the Blue Mosque for the 20,000 hand-painted İznik tiles that cover its interior walls and ceiling in deep cobalt and white. Six slender minarets rise above the courtyard, and the prayer hall — open to respectful visitors outside prayer times — impresses with its cascading half-domes and softly filtered light.

## Basilica Cistern
Your guide leads the family down into the Basilica Cistern, a 6th-century underground water reservoir built during the reign of Emperor Justinian. Three hundred and thirty-six marble columns rise from the still water in long atmospheric rows, their reflections shimmering below, while two ancient Medusa heads support columns at the far end.

## Grand Bazaar
Your vehicle drops the family at the Grand Bazaar, one of the largest covered markets in the world with over 4,000 shops spread across 61 vaulted streets. Jewellers, carpet sellers, ceramicists, and textile merchants fill the arcaded passages, and your guide helps navigate the most interesting sections at an unhurried pace.

## Topkapı Palace
Your family explores Topkapı Palace, the sprawling hilltop residence of Ottoman sultans for nearly four centuries. The complex encompasses courtyards, throne rooms, a Harem quarter, and an imperial treasury displaying jewels, weapons, and sacred relics. Terraced gardens at the tip of the promontory offer sweeping views over the Bosphorus and the Golden Horn.

---
**Hotel:** Istanbul · **Transport:** Private vehicle for city transfers · **Meals:** Breakfast

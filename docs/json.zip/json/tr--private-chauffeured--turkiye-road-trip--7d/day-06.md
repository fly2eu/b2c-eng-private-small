# Day 6 — Drive to Ankara: Atatürk's Mausoleum & Anatolian Civilisations

Your vehicle departs Cappadocia on the three-hour drive northwest to the Turkish capital. The afternoon visits the monumental Anıtkabir before time allowing an exploration of the Museum of Anatolian Civilisations — one of the finest archaeological collections in the Middle East.

## Drive Cappadocia to Ankara
Your vehicle departs the cave hotel and heads northwest on the three-hour drive to Ankara across the open Anatolian plateau. The guide provides an overview of the capital and the afternoon's programme during the journey.

## Anıtkabir — Mausoleum of Atatürk
Your family visits Anıtkabir, the monumental hilltop mausoleum of Mustafa Kemal Atatürk, founder of the Turkish Republic, completed in 1953. The ceremonial Lion Road lined with stone statues leads to the colonnaded Hall of Honour, and the adjacent museum tells the story of the Turkish War of Independence through extensive artefacts and personal memorabilia.

## Museum of Anatolian Civilisations *(subject to available time)*
Subject to available time, your guide leads the family through the Museum of Anatolian Civilisations, housed in a beautifully restored Ottoman bedesten and caravanserai in Ankara's old citadel district. The collection spans the Palaeolithic to the Roman era and includes extraordinary Hittite reliefs, Bronze Age figurines, and Phrygian metalwork rarely seen outside Türkiye.

---
**Hotel:** Ankara · **Transport:** Private vehicle Cappadocia → Ankara (~3hr) · **Meals:** Breakfast

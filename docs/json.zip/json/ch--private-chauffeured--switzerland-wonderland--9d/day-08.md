## Day 8 — Heidiland, Vaduz & Zürich

You leave the Engadin and travel north through the Rhine Valley, stopping in the storybook village of Maienfeld and the micro-state capital of Vaduz before returning to Zürich.

**Heididorf Maienfeld**
The original Heidi House in Maienfeld recreates the Alpine setting of Johanna Spyri's famous novel. You walk through the reconstructed rooms and the surrounding meadow paths that inspired the story, with views over the vineyards of the Rhine Valley.

**Vaduz Town Centre**
A guided walking tour takes you through the compact centre of Liechtenstein's capital. You pass the main pedestrian street, the Liechtenstein National Museum, the parliament building, and the postage stamp museum — all within easy walking distance.

**Vaduz Castle**
The official residence of the Prince of Liechtenstein sits on a forested ridge above the town. The castle is not open to the public, but the exterior and the hillside path leading up to it provide excellent views over Vaduz and the Rhine Valley.

*Your private vehicle departs St. Moritz in the morning, stops at Maienfeld and Vaduz, then continues to Zürich for the evening.*

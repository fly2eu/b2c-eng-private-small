## Day 4 — Schilthorn, Lauterbrunnen & Zermatt

A day of soaring Alpine scenery — you ride a cable car to nearly three thousand metres, walk through a car-free mountain village, enter the valley of seventy-two waterfalls, and arrive in Zermatt by evening.

**Schilthorn / Piz Gloria**
A cable car carries you to the summit of the Schilthorn at 2,970 metres, where the revolving Piz Gloria restaurant offers a full 360-degree panorama of over two hundred Alpine peaks. The viewing platform is one of the most dramatic in the Bernese Oberland, with the Eiger, Mönch, and Jungfrau directly across the valley.

**Mürren**
This car-free village clings to a cliff ledge high above the Lauterbrunnen valley. Traditional wooden chalets line quiet lanes with uninterrupted views of the three iconic peaks opposite. You explore on foot at your own pace.

**Lauterbrunnen Valley & Staubbach Falls**
The glacial valley of Lauterbrunnen is fed by seventy-two waterfalls that cascade from sheer rock walls on both sides. The most prominent is Staubbach Falls, a single ribbon of water dropping nearly three hundred metres into the valley floor — visible from the village centre.

**Transfer to Zermatt**
Zermatt is car-free, so your private vehicle brings you to the valley station at Täsch. From there, a short electric taxi ride takes you into the village, where the Matterhorn dominates the skyline at the end of the main street.

*Your vehicle transfers you from the Bernese Oberland through the Valais to the Täsch valley station, where an electric taxi completes the journey into car-free Zermatt.*

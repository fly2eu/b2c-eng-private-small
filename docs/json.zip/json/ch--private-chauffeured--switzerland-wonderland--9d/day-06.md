## Day 6 — Glacier Express: Zermatt to St. Moritz

You board the Glacier Express for one of the world's great rail journeys — roughly eight hours crossing the Swiss Alps from Zermatt to St. Moritz.

**Glacier Express**
The Glacier Express covers 291 bridges and 91 tunnels across the full breadth of the Swiss Alps. Your second-class panoramic seat provides floor-to-ceiling windows as the train climbs through the Goms valley, crosses the Oberalp Pass at 2,033 metres, descends through the Rhine Gorge, and enters the Engadin valley approaching St. Moritz. The journey takes approximately eight hours.

**Andermatt & Oberalp Pass**
The train pauses at Andermatt, a garrison town at the junction of several Alpine passes, before ascending to the Oberalp Pass — the highest point of the Glacier Express route. Snow-capped peaks and high-altitude meadows stretch in every direction from the panoramic carriage.

*You board the Glacier Express at Zermatt station in the morning and arrive at St. Moritz station in the late afternoon. A local transfer brings you to your hotel.*

## Day 5 — Zermatt

A full day at leisure in the car-free Alpine resort beneath the Matterhorn, with optional high-altitude excursions available.

**Zermatt Village**
You spend the day exploring Zermatt at your own rhythm. The traffic-free village centre is lined with traditional Valais timber houses, boutiques, and cafes — all framed by the iconic pyramid of the Matterhorn rising 4,478 metres above sea level.

**Gornergrat Railway (optional)**
This open-air cogwheel railway climbs to 3,089 metres in roughly thirty-three minutes. At the summit, a viewing terrace places you face-to-face with the Matterhorn and the Monte Rosa massif, with the Gorner Glacier sweeping below.

**Matterhorn Glacier Paradise (optional)**
Europe's highest cable car station sits at 3,883 metres. The ride up passes over glaciers and crevasse fields, and the summit platform offers views stretching across the Swiss, Italian, and French Alps on clear days.

*No scheduled transfers today. You are free to explore Zermatt independently. Optional excursions are available at your own expense.*

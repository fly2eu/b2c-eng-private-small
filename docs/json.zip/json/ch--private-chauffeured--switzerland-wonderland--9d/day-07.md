## Day 7 — St. Moritz

A day at leisure in the Engadin valley resort, with a thermal spa visit included and a choice of lakeside walks and museums.

**Ovaverva Thermal Baths (included)**
Your day includes access to the Ovaverva spa and sports centre. The thermal pools draw mineral-rich water from local springs, and the complex features indoor and outdoor bathing areas with views across the Engadin valley.

**St. Moritz Lakeside (optional)**
A flat path traces the shore of Lake St. Moritz, offering reflections of the surrounding mountains and access to the town's elegant waterfront. The walk connects to a broader network of trails through the Engadin valley.

**Engadine Museum (optional)**
This museum reconstructs original Engadin interiors — panelled living rooms, carved furniture, and domestic artefacts — to show how life was lived in the high Alpine valleys over the past five centuries.

**Segantini Museum (optional)**
A purpose-built domed gallery houses the largest collection of works by Giovanni Segantini, the Italian-born painter who spent his final years capturing the Engadin light. The centrepiece is his monumental Alpine Triptych.

*No scheduled transfers today. You are free to explore St. Moritz and the Engadin valley independently.*

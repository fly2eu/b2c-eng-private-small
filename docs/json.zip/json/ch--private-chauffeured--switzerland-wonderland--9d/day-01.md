## Day 1 — Zürich

Your journey begins with a smooth arrival into Switzerland's largest city.

**Zürich Airport Transfer**
Your private driver meets you at arrivals and brings you directly to your centrally located hotel. The transfer takes approximately thirty minutes depending on traffic conditions.

**Zürich Old Town (at leisure)**
The remainder of the day is yours to explore at your own pace. Wander through the cobbled lanes of the old town, stroll along the lake promenade, or climb to the Lindenhügel viewpoint for a sweeping panorama over the rooftops and the Limmat River.

*A private transfer brings you from Zürich Airport to your hotel in the city centre.*

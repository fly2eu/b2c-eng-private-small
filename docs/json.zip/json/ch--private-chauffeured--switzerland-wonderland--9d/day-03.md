## Day 3 — Bern & Gruyères

You explore the UNESCO-listed Swiss capital on foot in the morning, then head into the pastoral Pre-Alps for cheese, chocolate, and a medieval hilltop castle.

**Bern Old Town UNESCO Walk**
A guided walk takes you through Bern's UNESCO World Heritage old town. You pass beneath the famous Zytglogge clock tower, stroll under the Lauben arcades — six kilometres of covered walkways — and pause at the rose garden for a panoramic view over the Aare River loop.

**Zytglogge**
Bern's medieval clock tower has marked the hours since the thirteenth century. Its astronomical dial and mechanical figurines perform a brief show just before each hour, drawing crowds to the narrow street below.

**Federal Palace**
The seat of the Swiss federal government occupies an imposing Renaissance Revival building overlooking the Aare valley. You view it from the Bundesplatz, the large square in front that transforms into a fountain display in summer.

**La Maison du Gruyère**
At this working cheese dairy you follow the production of Gruyère AOP from fresh milk to finished wheel. Interactive exhibits explain the ageing process, and the scent of warm curd fills the demonstration hall.

**Gruyères Castle**
Perched on a hilltop above the village, this thirteenth-century castle offers eight centuries of architectural layers — from medieval ramparts to Baroque interiors and nineteenth-century Romantic landscape paintings. The terrace provides an unobstructed view of the Moléson massif.

**Maison Cailler Chocolate Factory**
Switzerland's oldest chocolate brand opens its doors for a sensory tour through the history of cacao and the art of Swiss chocolate making. The visit ends with a generous tasting session in the sampling room.

*A private transfer brings you from Bern to Gruyères in approximately one hour, with return to your hotel in the evening.*

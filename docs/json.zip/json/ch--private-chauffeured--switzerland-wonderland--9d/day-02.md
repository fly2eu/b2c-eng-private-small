## Day 2 — Zürich, Lucerne & Bern

A full day across three of Switzerland's most storied cities, beginning with a guided walk in Zürich, continuing to lakeside Lucerne, and ending in the federal capital Bern.

**Zürich Guided Walking Tour**
A local guide leads you through Zürich's historic core. You pass the twin towers of the Grossmünster, cross to the Fraumünster with its celebrated Chagall windows, walk the length of Bahnhofstrasse, and follow the Limmat riverbanks through the old town.

**Grossmünster**
This Romanesque church dominates the Zürich skyline with its distinctive twin towers. It dates to the twelfth century and is closely tied to the Protestant Reformation in Switzerland.

**Fraumünster**
Standing on the opposite bank of the Limmat from the Grossmünster, the Fraumünster is renowned for its five stained-glass windows by Marc Chagall and its slender green spire.

**Bahnhofstrasse**
One of the world's most exclusive shopping boulevards stretches roughly 1.4 kilometres from the main train station to Lake Zürich. Lined with luxury boutiques and grand nineteenth-century facades, it serves as the commercial spine of the city.

**Chapel Bridge**
Your guided tour of Lucerne begins at the Chapel Bridge, a fourteenth-century covered wooden footbridge that spans the Reuss River diagonally. Its interior features a series of seventeenth-century paintings depicting scenes from Swiss history.

**Lion Monument**
Carved directly into a sandstone cliff face, this sculpture of a dying lion commemorates the Swiss Guards who fell during the French Revolution. Mark Twain called it the most mournful piece of stone in the world.

**Jesuit Church**
Situated on the banks of the Reuss, the Jesuit Church is the first large Baroque church built in Switzerland. Its ornate interior of pink and white stuccowork contrasts with the restrained stone exterior.

**Lucerne Old Town**
Your guide walks you through the car-free lanes of the medieval old town, past painted facades and small squares that open onto views of the surrounding mountain peaks and Lake Lucerne.

*Your vehicle departs Zürich after the morning walking tour, transferring you to Lucerne for a guided visit before continuing to Bern for the evening.*
